"use strict";
(() => {
  // src/app-profile.ts
  function record(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function string(value) {
    return typeof value === "string" ? value : "";
  }
  function safeValue(value, depth = 0) {
    if (typeof value === "string") return value.slice(0, 3e4);
    if (typeof value === "boolean" || value === null || typeof value === "number" && Number.isFinite(value))
      return value;
    if (depth >= 4) return void 0;
    if (Array.isArray(value))
      return value.slice(0, 100).map((item) => safeValue(item, depth + 1)).filter((item) => item !== void 0);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.entries(record(value)).slice(0, 80).filter(([key]) => !["__proto__", "constructor", "prototype"].includes(key)).map(([key, item]) => [key, safeValue(item, depth + 1)]).filter(([, item]) => item !== void 0)
      );
    return void 0;
  }
  function fields(value) {
    return record(safeValue(record(value)));
  }
  function normalizeProfile(input) {
    const raw = record(input);
    const profile = {
      profileName: string(raw.profileName).slice(0, 100) || "My profile",
      nameData: fields(raw.nameData),
      contactData: fields(raw.contactData),
      addressData: fields(raw.addressData),
      websiteData: fields(raw.websiteData),
      employmentData: fields(raw.employmentData),
      resumeData: {},
      jobData: [],
      educationData: [],
      languageData: [],
      skillsData: []
    };
    for (const key of ["jobData", "educationData", "languageData"]) {
      const values = raw[key];
      if (values !== void 0 && !Array.isArray(values))
        throw new Error("Profile history must be a list.");
      if (Array.isArray(values)) {
        if (values.length > 100)
          throw new Error("A profile can contain up to 100 entries in each history section.");
        profile[key] = values.map(fields);
      }
    }
    profile.skillsData = Array.isArray(raw.skillsData) ? [
      ...new Set(
        raw.skillsData.filter((v) => typeof v === "string").map((v) => v.trim().slice(0, 200)).filter(Boolean)
      )
    ].slice(0, 300) : [];
    const resume = record(raw.resumeData), bytes = string(resume.resumeBase64);
    if (bytes.length > 28e6) throw new Error("Choose a resume smaller than 20 MB.");
    if (bytes && !/^(?:data:[\w.+/-]+;base64,)?[A-Za-z0-9+/]*={0,2}$/.test(bytes))
      throw new Error("The resume data is not a valid file.");
    if (bytes && !/\.(pdf|doc|docx|txt|rtf|odt)$/i.test(string(resume.fileName)))
      throw new Error("Choose a PDF, DOC, DOCX, text, RTF or ODT resume.");
    profile.resumeData = {
      fileName: string(resume.fileName).replace(/[\u0000-\u001f/\\]/g, "").slice(0, 240),
      resumeBase64: bytes,
      fileSize: typeof resume.fileSize === "number" && Number.isFinite(resume.fileSize) ? Math.max(0, resume.fileSize) : 0,
      dateUploaded: string(resume.dateUploaded).slice(0, 100)
    };
    return profile;
  }
  function parseProfileImport(text) {
    if (text.length > 32e6) throw new Error("Choose a profile export smaller than 32 MB.");
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("Choose a valid JSON profile export.");
    }
    const container = record(parsed), raw = record(container.profile || container.profileData || container);
    if (!raw.nameData && !raw.contactData && !raw.educationData)
      throw new Error(
        "This is not an applicant profile export. Import reusable answers from Your fields instead."
      );
    return normalizeProfile(raw);
  }

  // src/types.ts
  var STORAGE_KEY = "eze.customFields.v1";
  var PANEL_RESTORE_KEY = "eze.showFloatingRestore";
  var LINKEDIN_NOFOLLOW_KEY = "eze.linkedin.disableAutoFollow";
  var APPLICATION_COUNTS_KEY = "eze.applicationCountAdjustments.v1";

  // src/profile-fields.ts
  var OTHER_PERSON = [
    "referrer",
    "referral",
    "referred by",
    "reference",
    "recruiter",
    "emergency",
    "manager",
    "supervisor",
    "parent",
    "guardian"
  ];
  var OTHER_ADDRESS = [
    ...OTHER_PERSON,
    "company",
    "employer",
    "office",
    "school",
    "university",
    "institution",
    "billing",
    "shipping",
    "previous",
    "former",
    "preferred",
    "desired",
    "job location"
  ];

  // src/storage.ts
  var emptyProfile = () => ({ fields: [], autoFill: true });
  var SHORTCUT_IDS = new Set(
    [
      "first",
      "middle",
      "middle-initial",
      "last",
      "full",
      "phone-local",
      "phone-international",
      "dial-code",
      "phone-formatted"
    ].map((id) => `builtin:${id}`)
  );
  function object(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function string2(value) {
    return typeof value === "string" ? value : "";
  }
  function contextFrom(data) {
    const profile = object(data.profile);
    const names = object(profile.nameData);
    const contact = object(profile.contactData);
    const synced = object(data.lastSyncProfile);
    return {
      id: string2(synced.id) || "local",
      name: [names.firstName, names.lastName].filter(Boolean).join(" ") || "Your profile",
      personal: { ...names, ...contact, country: object(profile.addressData).country }
    };
  }
  function validateProfile(input) {
    const data = object(input);
    if (!Array.isArray(data.fields) || data.fields.length > 2e3 || typeof data.autoFill !== "boolean") {
      throw new Error(
        "Choose a custom-fields export with a fields list and an automatic-fill setting (up to 2,000 fields)."
      );
    }
    const validateFields = (values, shortcuts = false) => {
      const seen = /* @__PURE__ */ new Set();
      return values.map((raw) => {
        const field = object(raw);
        const id = string2(field.id);
        const label = string2(field.label).trim();
        const value = string2(field.value);
        if (!id || (shortcuts ? !SHORTCUT_IDS.has(id) : id.startsWith("builtin:")) || seen.has(id) || !label || label.length > 200 || value.length > 3e4) {
          throw new Error(
            "Every field needs a unique ID, a label (up to 200 characters), and an answer under 30,000 characters."
          );
        }
        seen.add(id);
        const list = (key) => {
          if (!Array.isArray(field[key]) || field[key].length > 100 || field[key].some((v) => typeof v !== "string" || v.length > 300)) {
            throw new Error(
              "Matching phrases and exclusions must be text lists (up to 100 phrases, 300 characters each)."
            );
          }
          return [...new Set(field[key].map((s) => s.trim()).filter(Boolean))];
        };
        let scope = string2(field.scope).trim().toLowerCase();
        if (scope) {
          try {
            const parsed = new URL(scope.includes("://") ? scope : `https://${scope}`);
            if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash || parsed.port)
              throw new Error();
            scope = parsed.hostname;
          } catch {
            throw new Error(
              "Site scope must be a hostname, such as linkedin.com. Leave it empty for every site."
            );
          }
        }
        if (!["exact", "phrase"].includes(string2(field.matchMode)) || typeof field.enabled !== "boolean") {
          throw new Error("Each field needs an exact/phrase match mode and an enabled setting.");
        }
        return {
          id,
          label,
          value,
          aliases: list("aliases"),
          exclude: list("exclude"),
          category: string2(field.category).trim().slice(0, 100) || "Personal questions",
          enabled: field.enabled,
          matchMode: field.matchMode,
          scope
        };
      });
    };
    const fields2 = validateFields(data.fields);
    if (data.profileOverrides !== void 0 && (!Array.isArray(data.profileOverrides) || data.profileOverrides.length > SHORTCUT_IDS.size))
      throw new Error("Profile edits must be a list of valid profile shortcuts.");
    const profileOverrides = data.profileOverrides === void 0 ? void 0 : validateFields(data.profileOverrides, true);
    const hidden = data.hiddenBuiltIns;
    if (hidden !== void 0 && (!Array.isArray(hidden) || hidden.length > 100 || hidden.some((id) => typeof id !== "string" || !/^builtin:[a-z-]{1,80}$/.test(id)))) {
      throw new Error("Hidden profile shortcuts must be a list of valid shortcut IDs.");
    }
    const order = data.fieldOrder;
    if (order !== void 0 && (!Array.isArray(order) || order.length > 2200 || order.some((id) => typeof id !== "string" || !id.trim() || id.length > 200))) {
      throw new Error(
        "Field order must be a list of up to 2,200 nonempty field IDs, each at most 200 characters."
      );
    }
    return {
      fields: fields2,
      autoFill: data.autoFill,
      ...hidden === void 0 ? {} : { hiddenBuiltIns: [...new Set(hidden)] },
      ...order === void 0 ? {} : { fieldOrder: [...new Set(order)] },
      ...profileOverrides === void 0 ? {} : { profileOverrides }
    };
  }
  async function getAutoFillPreference() {
    const data = await chrome.storage.local.get(["profile", "lastSyncProfile", STORAGE_KEY]);
    const { id } = contextFrom(data);
    const store = data[STORAGE_KEY];
    const saved = store?.version === 1 && store.profiles?.[id] ? validateProfile(store.profiles[id]) : emptyProfile();
    return { profileId: id, enabled: saved.autoFill };
  }
  async function setAutoFillPreference(enabled, expectedProfileId) {
    const result = await chrome.runtime.sendMessage({
      type: "eze-custom:auto-fill",
      profileId: expectedProfileId,
      enabled
    });
    if (!result?.ok)
      throw new Error(result?.error || "Automatic filling could not be saved. Please try again.");
  }

  // src/popup-controls.ts
  function savedAnswersSwitch() {
    let disposed = false, ready = false, saving = false, revision = 0;
    let preference = { profileId: "", enabled: false };
    const row = document.createElement("label");
    row.className = "eze-popup-option eze-popup-auto-fill";
    row.title = "Fill empty job application fields from your saved answers when pages and new form steps load. Synced with Auto fill in the side panel. Your edits are kept.";
    const toggle = document.createElement("input");
    toggle.type = "checkbox";
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", "Auto-fill saved answers");
    const text = document.createElement("span");
    text.textContent = "Auto-fill saved answers";
    row.append(toggle, text);
    const status = document.createElement("div");
    status.className = "eze-popup-preference-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      toggle.checked = preference.enabled;
      toggle.disabled = !ready || saving;
    }
    async function refresh() {
      const request = ++revision;
      ready = false;
      render();
      try {
        const current = await getAutoFillPreference();
        if (disposed || request !== revision) return;
        preference = current;
        ready = true;
        status.hidden = true;
      } catch {
        if (!disposed && request === revision) {
          status.textContent = "Could not load automatic filling. Reopen this popup to retry.";
          status.hidden = false;
        }
      } finally {
        if (!disposed && request === revision) render();
      }
    }
    const changed = (changes, area) => {
      if (!disposed && area === "local" && (changes[STORAGE_KEY] || changes.profile || changes.lastSyncProfile))
        void refresh();
    };
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked, profileId = preference.profileId;
      saving = true;
      status.hidden = true;
      render();
      try {
        await setAutoFillPreference(desired, profileId);
        if (!disposed) await refresh();
      } catch (error) {
        if (!disposed) {
          status.textContent = error instanceof Error ? error.message : "Could not save automatic filling. Try again.";
          status.hidden = false;
        }
      } finally {
        saving = false;
        if (!disposed) render();
      }
    });
    chrome.storage.onChanged.addListener(changed);
    void refresh();
    return {
      row,
      status,
      dispose() {
        disposed = true;
        chrome.storage.onChanged.removeListener(changed);
        row.remove();
        status.remove();
      }
    };
  }
  function savedSwitch(key, label, accessibleLabel, title, cls, settingName) {
    let disposed = false;
    let enabled = false;
    let ready = false;
    let saving = false;
    let revision = 0;
    const row = document.createElement("label");
    row.className = `eze-popup-option ${cls}`;
    row.title = title;
    const toggle = document.createElement("input");
    toggle.type = "checkbox";
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", accessibleLabel);
    const text = document.createElement("span");
    text.textContent = label;
    row.append(toggle, text);
    const status = document.createElement("div");
    status.className = "eze-popup-preference-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      toggle.checked = enabled;
      toggle.disabled = !ready || saving;
    }
    function error(message) {
      status.textContent = message;
      status.hidden = false;
    }
    const changed = (changes, area) => {
      if (disposed || area !== "local" || !changes[key]) return;
      revision++;
      enabled = changes[key].newValue === true;
      render();
    };
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked;
      const writeRevision = ++revision;
      saving = true;
      status.hidden = true;
      render();
      try {
        await chrome.storage.local.set({ [key]: desired });
        if (revision === writeRevision) enabled = desired;
      } catch {
        if (!disposed) error(`Could not save the ${settingName} setting. Try again.`);
      } finally {
        saving = false;
        if (!disposed) render();
      }
    });
    chrome.storage.onChanged.addListener(changed);
    const initialRevision = revision;
    chrome.storage.local.get(key).then((data) => {
      if (!disposed && revision === initialRevision) enabled = data[key] === true;
      ready = true;
    }).catch(() => {
      if (!disposed)
        error(`Could not load the ${settingName} setting. Reopen this popup to retry.`);
    }).finally(() => {
      if (!disposed) render();
    });
    render();
    return {
      row,
      status,
      dispose() {
        disposed = true;
        chrome.storage.onChanged.removeListener(changed);
        row.remove();
        status.remove();
      }
    };
  }
  function mountPopupControls() {
    let disposed = false;
    const controls = [
      savedAnswersSwitch(),
      savedSwitch(
        PANEL_RESTORE_KEY,
        "Closed panel floating button",
        "Show closed panel floating button",
        "Show a small EZEapply button on webpages when the side panel is closed.",
        "eze-popup-floating",
        "floating button"
      ),
      savedSwitch(
        LINKEDIN_NOFOLLOW_KEY,
        "Turn off LinkedIn auto-follow",
        "Turn off LinkedIn auto-follow",
        "Automatically untick company-follow boxes in LinkedIn application dialogs. Existing follows and other checkboxes are unchanged.",
        "eze-popup-linkedin-follow",
        "LinkedIn auto-follow"
      )
    ];
    function decorate() {
      if (disposed) return;
      let previous = [...document.querySelectorAll("#root label")].find(
        (label) => /^Autofill (?:Enabled|Disabled)$/.test(label.textContent?.trim() || "")
      );
      if (!previous) return;
      for (const control of controls) {
        if (previous.nextElementSibling !== control.row) previous.after(control.row, control.status);
        previous = control.status;
      }
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        controls.forEach((control) => control.dispose());
      }
    };
  }

  // src/navigation-icon.ts
  function navigationIcon(kind) {
    const image = document.createElement("img");
    image.className = "navigation-icon";
    image.src = chrome.runtime.getURL(`custom/navigation/${kind}.png`);
    image.alt = "";
    image.setAttribute("aria-hidden", "true");
    image.width = image.height = 34;
    image.draggable = false;
    return image;
  }

  // src/appearance-config.ts
  var COLOR_THEMES = [
    {
      id: "midnight",
      label: "Midnight Teal",
      colors: {
        bg: "#151c20",
        panel: "#1c272c",
        raised: "#27343a",
        input: "#111b20",
        border: "#35464d",
        text: "#dce5e8",
        muted: "#a2b0b8",
        accent: "#86b6a8",
        fill: "#285b4f",
        hover: "#326d5f",
        edge: "#427e6e"
      }
    },
    {
      id: "graphite",
      label: "Graphite",
      colors: {
        bg: "#191b20",
        panel: "#23262d",
        raised: "#2d3139",
        input: "#15171c",
        border: "#3d424d",
        text: "#e1e4eb",
        muted: "#a7afbd",
        accent: "#aab4c5",
        fill: "#414b5d",
        hover: "#4b586e",
        edge: "#657289"
      }
    },
    {
      id: "blue",
      label: "Dusk Blue",
      colors: {
        bg: "#151c29",
        panel: "#1e2939",
        raised: "#29374a",
        input: "#111a28",
        border: "#394b64",
        text: "#e1e8f2",
        muted: "#a3b2c7",
        accent: "#9db7de",
        fill: "#344f76",
        hover: "#405f8a",
        edge: "#5e7caa"
      }
    },
    {
      id: "violet",
      label: "Violet",
      colors: {
        bg: "#201a29",
        panel: "#2a2235",
        raised: "#372d43",
        input: "#1b1524",
        border: "#4c3d5b",
        text: "#e9e2ef",
        muted: "#b7a8c5",
        accent: "#bbabd2",
        fill: "#58456d",
        hover: "#66517d",
        edge: "#7c6497"
      }
    },
    {
      id: "pine",
      label: "Pine",
      colors: {
        bg: "#172219",
        panel: "#212e23",
        raised: "#2c3b2d",
        input: "#131e15",
        border: "#3c5140",
        text: "#e2e9df",
        muted: "#aab8a5",
        accent: "#a3c09c",
        fill: "#3f5c3b",
        hover: "#4b6c46",
        edge: "#688962"
      }
    },
    {
      id: "rosewood",
      label: "Rosewood",
      colors: {
        bg: "#261b1e",
        panel: "#322529",
        raised: "#423136",
        input: "#20161a",
        border: "#574146",
        text: "#eee3e6",
        muted: "#c3adb5",
        accent: "#d0a4af",
        fill: "#704752",
        hover: "#805460",
        edge: "#9b6876"
      }
    },
    {
      id: "sandstone",
      label: "Sandstone",
      colors: {
        bg: "#231f19",
        panel: "#302a22",
        raised: "#3f372c",
        input: "#1e1a14",
        border: "#554a39",
        text: "#eae4d9",
        muted: "#bdb09c",
        accent: "#c9b48b",
        fill: "#655336",
        hover: "#756141",
        edge: "#8f7950"
      }
    },
    {
      id: "magenta",
      label: "Magenta Gray",
      colors: {
        bg: "#29292c",
        panel: "#303033",
        raised: "#3c383e",
        input: "#242326",
        border: "#51454f",
        text: "#f2e9ef",
        muted: "#c6b4c1",
        accent: "#d7a3c5",
        fill: "#6f2c50",
        hover: "#80375f",
        edge: "#a36185"
      }
    }
  ];
  function colorTheme(value) {
    return COLOR_THEMES.find((theme) => theme.id === value) || COLOR_THEMES[0];
  }

  // src/appearance.ts
  var APPEARANCE_EVENT = "eze-appearance-changed";
  function applyAppearance(document2, value) {
    const theme = colorTheme(value), root = document2.documentElement;
    for (const [name, color] of Object.entries(theme.colors))
      root.style.setProperty(`--ui-${name}`, color);
    root.dataset.ezeTheme = theme.id;
    document2.dispatchEvent(new Event(APPEARANCE_EVENT));
  }
  function mountThemePicker(document2 = window.document) {
    const trigger = document2.createElement("button");
    trigger.type = "button";
    trigger.className = "eze-appearance-trigger";
    trigger.setAttribute("aria-label", "Choose color theme");
    trigger.setAttribute("aria-haspopup", "dialog");
    const ns = "http://www.w3.org/2000/svg", icon3 = document2.createElementNS(ns, "svg");
    icon3.setAttribute("viewBox", "0 0 24 24");
    icon3.setAttribute("aria-hidden", "true");
    const outline = document2.createElementNS(ns, "path");
    outline.setAttribute(
      "d",
      "M12 3a9 9 0 1 0 0 18h1.4a2.5 2.5 0 0 0 1.6-4.4c-.7-.6-.3-1.6.6-1.6H17a4 4 0 0 0 4-4c0-4.4-4-8-9-8Z"
    );
    icon3.append(outline);
    for (const [cx, cy] of [
      [7, 10],
      [10, 6.8],
      [14.3, 7],
      [17, 10.2]
    ]) {
      const dot = document2.createElementNS(ns, "circle");
      dot.setAttribute("cx", String(cx));
      dot.setAttribute("cy", String(cy));
      dot.setAttribute("r", "1");
      icon3.append(dot);
    }
    trigger.append(icon3);
    const dialog = document2.createElement("dialog");
    dialog.className = "eze-appearance-dialog";
    dialog.setAttribute("aria-label", "Color theme");
    const heading = document2.createElement("div");
    heading.className = "eze-appearance-heading";
    const title = document2.createElement("h2");
    title.textContent = "Color theme";
    const close = document2.createElement("button");
    close.type = "button";
    close.className = "eze-appearance-close";
    close.textContent = "\xD7";
    close.setAttribute("aria-label", "Close color themes");
    heading.append(title, close);
    const hint = document2.createElement("p");
    hint.className = "eze-appearance-hint";
    hint.textContent = "Muted colors. A quieter workspace.";
    const choices = document2.createElement("fieldset");
    choices.className = "eze-theme-choices";
    const legend = document2.createElement("legend");
    legend.textContent = "Choose an appearance";
    choices.append(legend);
    for (const theme of COLOR_THEMES) {
      const label = document2.createElement("label");
      label.className = "eze-theme-choice";
      const input = document2.createElement("input");
      input.type = "radio";
      input.name = "eze-color-theme";
      input.value = theme.id;
      const preview = document2.createElement("span");
      preview.className = "eze-theme-preview";
      preview.setAttribute("aria-hidden", "true");
      preview.style.setProperty("--swatch-bg", theme.colors.bg);
      preview.style.setProperty("--swatch-panel", theme.colors.panel);
      preview.style.setProperty("--swatch-accent", theme.colors.accent);
      const caption = document2.createElement("span");
      caption.textContent = theme.label;
      label.append(input, preview, caption);
      choices.append(label);
      input.addEventListener("change", () => {
        if (input.checked) void save(theme.id);
      });
    }
    const status = document2.createElement("p");
    status.className = "eze-appearance-status";
    status.setAttribute("role", "status");
    status.textContent = "Saved on this device \xB7 applies to all panels";
    dialog.append(heading, hint, choices, status);
    let disposed = false;
    function sync() {
      if (disposed) return;
      const selected = colorTheme(document2.documentElement.dataset.ezeTheme);
      trigger.title = `Color theme \xB7 ${selected.label}`;
      for (const input of choices.querySelectorAll("input"))
        input.checked = input.value === selected.id;
    }
    async function save(id) {
      const previous = document2.documentElement.dataset.ezeTheme;
      const focused = document2.activeElement;
      applyAppearance(document2, id);
      choices.disabled = true;
      status.textContent = "Saving theme\u2026";
      status.classList.remove("is-error");
      try {
        const result = await chrome.runtime.sendMessage({ type: "eze-app:appearance", theme: id });
        if (!result?.ok) throw new Error(result?.error || "Could not save this theme. Try again.");
        if (!disposed) status.textContent = "Saved on this device \xB7 applies to all panels";
      } catch (error) {
        if (disposed) return;
        if (document2.documentElement.dataset.ezeTheme === id) applyAppearance(document2, previous);
        status.textContent = error instanceof Error ? error.message : "Could not save this theme. Try again.";
        status.classList.add("is-error");
      } finally {
        if (!disposed) {
          choices.disabled = false;
          if (dialog.open && document2.activeElement === document2.body && choices.contains(focused))
            focused.focus();
        }
      }
    }
    trigger.addEventListener("click", () => {
      if (!dialog.isConnected) document2.body.append(dialog);
      sync();
      if (!dialog.open) dialog.showModal();
      choices.querySelector("input:checked")?.focus();
    });
    close.addEventListener("click", () => dialog.close());
    dialog.addEventListener("click", (event) => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)
        dialog.close();
    });
    dialog.addEventListener("close", () => trigger.focus());
    document2.addEventListener(APPEARANCE_EVENT, sync);
    sync();
    return {
      button: trigger,
      dispose() {
        disposed = true;
        document2.removeEventListener(APPEARANCE_EVENT, sync);
        dialog.remove();
        trigger.remove();
      }
    };
  }

  // src/profile-view.ts
  var paths = {
    person: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM5 18a7 7 0 0 1 14 0M15 9a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
    work: "M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 11c5 4 13 4 18 0M12 11v4M5 7h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z",
    education: "m2 8 10-5 10 5-10 5L2 8Zm4 2v7c4 3 8 3 12 0v-7M22 8v8",
    portfolio: "M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5M14 3l6 6h-6V3ZM22 22l-3-3M21 16a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
    globe: "M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z",
    github: "M9 21v-4c-4 1-5-2-6-3M15 21v-4c0-1-.3-1.5-1-2 4-.5 6-2 6-6 0-1.5-.5-2.5-1.5-3.5.3-1 .2-2-.5-3-1.7 0-3 1-4 1.5a12 12 0 0 0-4 0C9 3.5 7.7 2.5 6 2.5c-.7 1-.8 2-.5 3C4.5 6.5 4 7.5 4 9c0 4 2 5.5 6 6-.7.5-1 1-1 2",
    linkedin: "M4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1ZM7 10v7M7 7v.1M11 17v-7m0 3a3 3 0 0 1 6 0v4",
    location: "M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0ZM15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",
    calendar: "M7 3v4m10-4v4M3 10h18M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2ZM7 14h2m4 0h2m-8 3h2",
    edit: "m15 5 4 4M4 20l5-1L20 8a2.8 2.8 0 0 0-4-4L5 15l-1 5Z",
    open: "M14 3h7v7m0-7L10 14M10 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5",
    download: "M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5",
    employment: "m3 8 4-4 5 2 5-2 4 4-9 11L3 8Zm5 6 4-4 4 4M6 16l3 3m6-12-3 3-3-2"
  };
  function icon(kind) {
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg"), path = document.createElementNS(ns, "path");
    for (const [key, value] of Object.entries({
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": "1.7",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "aria-hidden": "true"
    }))
      svg.setAttribute(key, value);
    path.setAttribute("d", paths[kind]);
    svg.append(path);
    return svg;
  }
  function el(tag, cls = "", text = "") {
    const node3 = document.createElement(tag);
    node3.className = cls;
    node3.textContent = text;
    return node3;
  }
  function button(cls, text = "") {
    const node3 = el("button", cls, text);
    node3.type = "button";
    return node3;
  }
  function prettyDate(value) {
    const data = record(value), raw = string(value), match = /^(\d{4})-(\d{1,2})(?:-\d{2})?$/.exec(raw), year = match?.[1] ?? data.year, month = Number(match?.[2] ?? data.month);
    if (/^\d{4}$/.test(String(year))) {
      return month >= 1 && month <= 12 ? `${["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][month - 1]} ${year}` : String(year);
    }
    return raw;
  }
  function websiteInfo(value, key) {
    try {
      const url = new URL(value);
      const host = url.hostname.replace(/^www\./, "");
      let label = key === "personal" ? "Website" : key;
      let kind = "globe";
      if (key === "github" || host === "github.com") {
        kind = "github";
        label = key === "github" ? "GitHub" : url.pathname.split("/").filter(Boolean).pop() || "GitHub";
      } else if (key === "linkedin" || host === "linkedin.com") {
        kind = "linkedin";
        label = "LinkedIn";
      } else if (key === "websites") {
        label = host === "leetcode.com" ? "LeetCode" : host === "codeforces.com" ? "Codeforces" : host.replace(/\.(?:workers\.dev|vercel\.app|netlify\.app|pages\.dev)$/, "");
      }
      const href = ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url.href : "";
      return { label: label || "Website", kind, href };
    } catch {
      return { label: key === "websites" ? "Website" : key, kind: "globe", href: "" };
    }
  }
  function mountProfileView(profile, downloadResume) {
    const stack = el("div", "profile-cards"), status = el("p", "profile-copy-status");
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const timers = /* @__PURE__ */ new Map(), previews = /* @__PURE__ */ new Map();
    let disposed = false;
    function copy(label, value, cls = "", display = value) {
      const answer = button(`copy-value ${cls}`, display || "Not set");
      answer.disabled = !value;
      answer.title = `Copy ${label}`;
      answer.setAttribute("aria-label", `Copy ${label}`);
      answer.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(value);
          if (disposed) return;
          status.textContent = `${label} copied`;
          answer.dataset.copied = "true";
          clearTimeout(timers.get(answer));
          timers.set(
            answer,
            setTimeout(() => {
              delete answer.dataset.copied;
              timers.delete(answer);
            }, 1200)
          );
        } catch {
          if (!disposed) status.textContent = `Could not copy ${label}. Try again.`;
        }
      });
      return answer;
    }
    function row(label, value) {
      const row2 = el("div", "profile-value");
      row2.append(el("span", "", label), copy(label, value));
      return row2;
    }
    function section(title, kind) {
      const card = el("section", "card"), header = el("div", "profile-section-heading"), heading = el("h2", "", title), edit = el("a", "profile-edit");
      heading.prepend(icon(kind));
      edit.href = chrome.runtime.getURL("options.html#/profile");
      edit.target = "_blank";
      edit.rel = "noopener";
      edit.title = `Edit ${title.toLowerCase()}`;
      edit.setAttribute("aria-label", edit.title);
      edit.append(icon("edit"));
      header.append(heading, edit);
      card.append(header);
      stack.append(card);
      return card;
    }
    function metadata(parent, label, value, kind) {
      if (!value) return;
      const item = copy(label, value, "history-meta-value");
      item.prepend(icon(kind));
      parent.append(item);
    }
    function measure(target, toggle) {
      if (toggle.getAttribute("aria-expanded") === "true") return;
      toggle.hidden = target.clientHeight > 0 ? target.scrollHeight <= target.clientHeight + 1 : (target.textContent || "").length < 240 && (target.textContent || "").split("\n").length <= 3;
    }
    const observer = typeof ResizeObserver === "undefined" ? void 0 : new ResizeObserver((entries) => {
      for (const entry of entries) {
        const toggle = previews.get(entry.target);
        if (toggle) measure(entry.target, toggle);
      }
    });
    function description(parent, label, text) {
      if (!text) return;
      const block = el("div", "history-description"), answer = copy(`${label} description`, text, "history-preview"), toggle = button("history-expand", "Show more");
      answer.id = `profile-description-${previews.size}`;
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-controls", answer.id);
      toggle.setAttribute("aria-label", `Show more about ${label}`);
      toggle.addEventListener("click", () => {
        const expanded = toggle.getAttribute("aria-expanded") !== "true";
        toggle.setAttribute("aria-expanded", String(expanded));
        toggle.setAttribute("aria-label", `${expanded ? "Show less" : "Show more"} about ${label}`);
        toggle.textContent = expanded ? "Show less" : "Show more";
        answer.classList.toggle("is-expanded", expanded);
        if (!expanded) measure(answer, toggle);
      });
      block.append(answer, toggle);
      parent.append(block);
      previews.set(answer, toggle);
      observer?.observe(answer);
      measure(answer, toggle);
    }
    const personal = section("Personal Details", "person"), names = profile.nameData, contact = profile.contactData, address = profile.addressData;
    const street = [address.line1, address.line2].map(string).filter(Boolean).join(", "), locality = [
      ...new Set(
        [address.city, address.state, address.postalCode, address.country].map(string).filter(Boolean)
      )
    ].join(" ");
    for (const [label, value] of [
      ["Legal Name", [names.firstName, names.middleName, names.lastName].filter(Boolean).join(" ")],
      ["Email", string(contact.email)],
      ["Phone", string(contact.phoneNumber)],
      ["Address", [street, locality].filter(Boolean).join("\n")]
    ])
      personal.append(row(label, value));
    if (profile.languageData.length)
      personal.append(
        row(
          "Languages",
          profile.languageData.map(
            (item) => [string(item.language), string(item.proficiency)].filter(Boolean).join(" \xB7 ")
          ).join("\n")
        )
      );
    for (const [title, items, kind, primary] of [
      ["Work History", profile.jobData, "work", "jobTitle"],
      ["Education", profile.educationData, "education", "school"]
    ]) {
      const card = section(title, kind);
      if (!items.length) card.append(el("p", "muted profile-empty", "Add this in your profile."));
      for (const item of items) {
        const entry = el("article", "history-summary"), heading = el("h3", "history-title"), label = string(item[primary]) || title, meta = el("div", "history-meta");
        heading.append(copy(label, string(item[primary]), "history-title-value", label));
        entry.append(heading);
        if (kind === "work") {
          metadata(meta, `${label} company`, string(item.company), "work");
          metadata(meta, `${label} location`, string(item.location), "location");
        } else {
          metadata(meta, `${label} degree`, string(item.degree), "education");
          metadata(meta, `${label} field of study`, string(item.fieldOfStudy), "portfolio");
        }
        const dates = [
          prettyDate(item.startDate),
          item.currentlyWorkHere === true ? "Present" : prettyDate(item.endDate)
        ].filter(Boolean).join(" \u2013 ");
        metadata(meta, `${label} dates`, dates, "calendar");
        entry.append(meta);
        description(entry, label, string(item.description));
        card.append(entry);
      }
    }
    const portfolio = section("Portfolio", "portfolio"), saved = profile.resumeData, fileName = string(saved.fileName);
    if (fileName) {
      const resume = el("div", "profile-resume"), name = el("strong", "profile-resume-name", fileName), details = el("p", "muted profile-resume-meta"), actions = el("div", "profile-resume-actions"), download = button("quiet-button", "Download"), replace = el("a", "quiet-button", "Replace");
      name.title = fileName;
      const size = typeof saved.fileSize === "number" && saved.fileSize > 0 ? `${Math.round(saved.fileSize)} KB` : "";
      details.textContent = [
        size,
        string(saved.dateUploaded) ? `Uploaded ${prettyDate(string(saved.dateUploaded).split("T")[0])}` : ""
      ].filter(Boolean).join(" \xB7 ");
      download.prepend(icon("download"));
      download.disabled = !string(saved.resumeBase64);
      download.addEventListener("click", () => downloadResume(saved));
      replace.href = chrome.runtime.getURL("options.html#/profile");
      replace.target = "_blank";
      replace.rel = "noopener";
      actions.append(download, replace);
      resume.append(name, details, actions);
      portfolio.append(resume);
    }
    const links = el("div", "portfolio-links"), seen = /* @__PURE__ */ new Set();
    const primaryLinks = ["linkedin", "github", "personal"];
    const websites = [
      ...primaryLinks.map((key) => [key, profile.websiteData[key]]),
      ...Object.entries(profile.websiteData).filter(([key]) => !primaryLinks.includes(key))
    ];
    for (const [key, values] of websites) {
      for (const value of Array.isArray(values) ? values : [values]) {
        if (typeof value !== "string" || !value.trim()) continue;
        const info = websiteInfo(value, key), identity = info.href || value;
        if (seen.has(identity)) continue;
        seen.add(identity);
        const item = el("div", "portfolio-link"), control = copy(`${info.label} URL`, value, "portfolio-link-copy", "");
        control.replaceChildren(icon(info.kind), el("span", "", info.label));
        control.title = `Copy ${info.label}: ${value}`;
        item.append(control);
        if (info.href) {
          const open = el("a", "portfolio-link-open");
          open.href = info.href;
          open.target = "_blank";
          open.rel = "noopener noreferrer";
          open.title = `Open ${info.label}`;
          open.setAttribute("aria-label", open.title);
          open.append(icon("open"));
          item.append(open);
        }
        links.append(item);
      }
    }
    if (links.childElementCount) portfolio.append(el("h3", "profile-subheading", "Links"), links);
    if (profile.skillsData.length) {
      const skills = el("div", "profile-skills");
      for (const skill of profile.skillsData) skills.append(copy(skill, skill, "profile-skill"));
      portfolio.append(el("h3", "profile-subheading", "Skills"), skills);
    }
    const employment = section("Employment Information", "employment");
    for (const [key, value] of Object.entries(profile.employmentData)) {
      if (!["string", "boolean", "number"].includes(typeof value)) continue;
      const label = key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/^./, (c) => c.toUpperCase());
      employment.append(
        row(label, typeof value === "boolean" ? value ? "Yes" : "No" : String(value))
      );
    }
    stack.append(status);
    return {
      element: stack,
      dispose() {
        disposed = true;
        observer?.disconnect();
        timers.forEach(clearTimeout);
        timers.clear();
      }
    };
  }

  // src/cv-tray-store.ts
  var MAX_PDFS = 4;
  var MAX_PDF_BYTES = 20 * 1024 * 1024;
  async function database() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("eze-cv-tray", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("files");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(new Error("Could not open your PDF tray."));
    });
  }
  async function readTray() {
    const db = await database();
    try {
      return await new Promise((resolve, reject) => {
        const request = db.transaction("files").objectStore("files").get("tray");
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(new Error("Could not read your PDFs."));
      });
    } finally {
      db.close();
    }
  }
  async function updateTray(change) {
    const db = await database();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction("files", "readwrite", { durability: "strict" });
        const store = tx.objectStore("files");
        let result;
        let failure;
        const request = store.get("tray");
        request.onsuccess = () => {
          try {
            result = change(request.result || []);
            if (result.length > MAX_PDFS)
              throw new Error("Your tray holds up to four PDFs. Remove one before adding another.");
            store.put(result, "tray");
          } catch (error) {
            failure = error;
            tx.abort();
          }
        };
        tx.oncomplete = () => resolve(result);
        tx.onabort = tx.onerror = () => reject(failure || new Error("Could not save your PDFs. Please try again."));
      });
    } finally {
      db.close();
    }
  }
  async function preparePDF(file) {
    if (!/\.pdf$/i.test(file.name) || !file.size || file.size > MAX_PDF_BYTES)
      throw new Error("Choose a PDF between 1 byte and 20 MB.");
    const bytes = new Uint8Array(await file.slice(0, 1024).arrayBuffer());
    if (!new TextDecoder().decode(bytes).includes("%PDF-"))
      throw new Error("This file does not contain a PDF header.");
    return {
      id: crypto.randomUUID(),
      name: file.name,
      blob: new Blob([file], { type: "application/pdf" }),
      modified: file.lastModified
    };
  }
  function movePDF(files, id, target) {
    const index = files.findIndex((file2) => file2.id === id);
    if (index < 0) return files;
    const next = [...files];
    const [file] = next.splice(index, 1);
    next.splice(Math.max(0, Math.min(target, next.length)), 0, file);
    return next;
  }
  function dragPDF(transfer, pdf) {
    transfer.effectAllowed = "copy";
    transfer.items.add(
      new File([pdf.blob], pdf.name, { type: "application/pdf", lastModified: pdf.modified })
    );
  }

  // src/cv-transfer.ts
  var CV_MIME = "application/x-eze-pdf";

  // src/cv-tray.ts
  function node(tag, cls, text = "") {
    const element = document.createElement(tag);
    element.className = cls;
    element.textContent = text;
    return element;
  }
  function button2(text, label = text) {
    const element = node("button", "cv-tool", text);
    element.type = "button";
    element.title = label;
    element.setAttribute("aria-label", label);
    return element;
  }
  function icon2(kind) {
    const element = node("span", `cv-action-icon cv-icon-${kind}`);
    element.setAttribute("aria-hidden", "true");
    return element;
  }
  function mountCVTray() {
    const element = node("section", "card cv-tray");
    const header = node("div", "cv-header"), title = node("h2", "", "Resume"), count = node("span", "cv-count", "0 / 4"), add = button2("+ Add PDF");
    const description = node("p", "cv-description", "Drag a PDF onto an upload area to drop it.");
    const grid = node("div", "cv-grid"), status = node("p", "cv-status");
    status.setAttribute("role", "status");
    const picker = node("input", "");
    picker.type = "file";
    picker.accept = ".pdf,application/pdf";
    picker.multiple = true;
    picker.hidden = true;
    header.append(title, count, description, add);
    element.append(header, grid, status, picker);
    let files = [], disposed = false, busy = false, dragged = "", revision = 0;
    const urls = [];
    const channel = typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("eze-cv-tray") : void 0;
    const revoke = () => {
      urls.splice(0).forEach((url) => URL.revokeObjectURL(url));
    };
    const errorText2 = (error) => error instanceof Error ? error.message : "Could not update your PDFs.";
    async function refresh() {
      const current = ++revision;
      try {
        const saved = await readTray();
        if (!disposed && current === revision) {
          files = saved;
          render();
        }
      } catch (error) {
        if (!disposed) status.textContent = errorText2(error);
      }
    }
    async function change(update, message) {
      if (busy) return;
      busy = true;
      add.disabled = true;
      try {
        await updateTray(update);
        channel?.postMessage("changed");
        if (!disposed) {
          await refresh();
          status.textContent = message;
        }
      } catch (error) {
        if (!disposed) status.textContent = errorText2(error);
      } finally {
        busy = false;
        if (!disposed) add.disabled = files.length >= MAX_PDFS;
      }
    }
    function render() {
      revoke();
      grid.replaceChildren();
      grid.style.setProperty("--cv-count", String(Math.max(1, files.length)));
      count.textContent = `${files.length} / 4`;
      add.disabled = busy || files.length >= MAX_PDFS;
      if (!files.length) {
        grid.append(node("div", "cv-empty", "Keep up to four application PDFs ready here."));
        return;
      }
      files.forEach((pdf, index) => {
        const tile = node("article", "cv-tile"), document2 = button2("", `Drag ${pdf.name} to upload`);
        document2.className = "cv-document";
        tile.draggable = true;
        document2.draggable = true;
        document2.append(node("span", "cv-paper", "PDF"));
        const name = node("span", "cv-name", pdf.name.replace(/\.pdf$/i, ""));
        name.title = pdf.name;
        const size = node("span", "cv-size", `${Math.max(1, Math.round(pdf.blob.size / 1024))} KB`);
        const grip = button2("", `Reorder ${pdf.name}. Use Left and Right arrow keys.`);
        grip.className = "cv-action cv-grip";
        grip.append(icon2("reorder"));
        const actions = node("div", "cv-actions"), download = node("a", "cv-action cv-download"), remove = button2("", `Delete ${pdf.name}`);
        remove.className = "cv-action cv-delete";
        download.title = `Download ${pdf.name}`;
        download.setAttribute("aria-label", download.title);
        download.draggable = false;
        download.append(icon2("download"));
        remove.append(icon2("delete"));
        const url = URL.createObjectURL(pdf.blob);
        urls.push(url);
        download.href = url;
        download.download = pdf.name;
        actions.append(grip, download, remove);
        actions.addEventListener("dragstart", (event) => {
          event.preventDefault();
          event.stopPropagation();
        });
        tile.addEventListener("dragstart", (event) => {
          if (event.dataTransfer) {
            dragPDF(event.dataTransfer, pdf);
            const token = crypto.randomUUID();
            event.dataTransfer.setData(CV_MIME, `eze-pdf:${token}`);
            event.dataTransfer.setData("text/plain", `eze-pdf:${token}`);
            void chrome.runtime.sendMessage({ type: "eze-cv:begin", token, id: pdf.id }).then((result) => {
              if (result?.error && !disposed) status.textContent = result.error;
            }).catch(() => {
              if (!disposed)
                status.textContent = "Refresh the extension and page, then drag again.";
            });
          }
        });
        document2.addEventListener("click", () => {
          status.textContent = "Drag the PDF icon onto the form\u2019s upload area. If a site rejects the drop, use the download button and its file picker.";
        });
        grip.draggable = true;
        grip.addEventListener("dragstart", (event) => {
          dragged = pdf.id;
          event.stopPropagation();
          if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = "move";
            event.dataTransfer.setData("application/x-eze-cv-order", pdf.id);
          }
        });
        grip.addEventListener("dragend", () => {
          dragged = "";
        });
        tile.addEventListener("dragover", (event) => {
          if (dragged) {
            event.preventDefault();
            if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
          }
        });
        tile.addEventListener("drop", (event) => {
          if (!dragged) return;
          event.preventDefault();
          const id = dragged;
          dragged = "";
          void change((saved) => movePDF(saved, id, index), "PDF order saved.");
        });
        grip.addEventListener("keydown", (event) => {
          if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
          event.preventDefault();
          const offset = event.key === "ArrowLeft" ? -1 : 1;
          void change(
            (saved) => movePDF(saved, pdf.id, saved.findIndex((file) => file.id === pdf.id) + offset),
            "PDF order saved."
          );
        });
        remove.addEventListener("click", () => {
          if (confirm(`Remove ${pdf.name} from your saved resumes? Your original file is kept.`))
            void change((saved) => saved.filter((file) => file.id !== pdf.id), "PDF removed.");
        });
        tile.append(document2, name, size, actions);
        grid.append(tile);
      });
    }
    add.addEventListener("click", () => picker.click());
    picker.addEventListener("change", async () => {
      const selected = Array.from(picker.files || []);
      picker.value = "";
      if (!selected.length || busy) return;
      try {
        if (selected.length + files.length > MAX_PDFS)
          throw new Error("Choose only enough PDFs to fill the four available slots.");
        const prepared = await Promise.all(selected.map(preparePDF));
        await change(
          (saved) => [...saved, ...prepared],
          `${prepared.length} PDF${prepared.length === 1 ? "" : "s"} added.`
        );
      } catch (error) {
        status.textContent = errorText2(error);
      }
    });
    if (channel)
      channel.onmessage = () => {
        void refresh();
      };
    void refresh();
    return {
      element,
      dispose() {
        disposed = true;
        revision++;
        revoke();
        channel?.close();
      }
    };
  }

  // src/application-day.ts
  var DAY_MS = 24 * 60 * 60 * 1e3;
  function utcDayKey(date = /* @__PURE__ */ new Date()) {
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
  }
  function utcDayStart(date = /* @__PURE__ */ new Date()) {
    return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
  }
  function utcDayOffset(date, offset) {
    return new Date(utcDayStart(date) + offset * DAY_MS);
  }
  function watchUtcDay(onChange, doc = document) {
    let day = utcDayKey(), disposed = false, timer;
    const view = doc.defaultView;
    function check() {
      if (disposed) return;
      const now = /* @__PURE__ */ new Date(), current = utcDayKey(now);
      clearTimeout(timer);
      timer = setTimeout(check, Math.max(1, utcDayStart(now) + DAY_MS - now.getTime()));
      if (current !== day) {
        day = current;
        onChange();
      }
    }
    doc.addEventListener("visibilitychange", check);
    view?.addEventListener("focus", check);
    check();
    return () => {
      disposed = true;
      clearTimeout(timer);
      doc.removeEventListener("visibilitychange", check);
      view?.removeEventListener("focus", check);
    };
  }

  // src/tracking-model.ts
  function validDay(day) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return false;
    const [year, month, date] = day.split("-").map(Number), parsed = new Date(Date.UTC(year, month - 1, date));
    return year >= 1970 && utcDayKey(parsed) === day;
  }

  // src/tracking-types.ts
  var TRACKING_CACHE_KEY = "eze.tracking.v1";
  var TRACKING_DAILY_TOTALS_KEY = "eze.tracking.dailyTotals.v1";

  // src/application-count.ts
  function countAdjustments(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    return Object.fromEntries(
      Object.entries(value).filter(
        ([day, amount]) => validDay(day) && Number.isSafeInteger(amount) && Math.abs(amount) <= 99999
      )
    );
  }
  function applicationCount(appliedList, adjustments, now = /* @__PURE__ */ new Date()) {
    const start = utcDayStart(now);
    const end = utcDayOffset(now, 1).getTime();
    const detected = Array.isArray(appliedList) ? appliedList.filter((item) => {
      if (!item || typeof item !== "object" || typeof item.date !== "string") return false;
      const date = new Date(item.date).getTime();
      return date >= start && date < end;
    }).length : 0;
    return Math.max(0, detected + (countAdjustments(adjustments)[utcDayKey(now)] || 0));
  }
  function mountApplicationCount() {
    let disposed = false, busy = false, ready = false, revision = 0, total = 0;
    const controls = document.createElement("span");
    controls.className = "eze-count-controls";
    controls.setAttribute("role", "group");
    controls.setAttribute("aria-label", "Adjust today\u2019s application count");
    const minus = document.createElement("button"), plus = document.createElement("button");
    for (const [button4, label, sign] of [
      [minus, "Decrease today\u2019s application count", "\u2212"],
      [plus, "Increase today\u2019s application count", "+"]
    ]) {
      button4.type = "button";
      button4.className = "eze-count-step";
      button4.textContent = sign;
      button4.setAttribute("aria-label", label);
      button4.title = label;
    }
    controls.append(minus, plus);
    const status = document.createElement("span");
    status.className = "eze-count-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      minus.disabled = !ready || busy || total === 0;
      plus.disabled = !ready || busy;
      controls.title = `Today: ${total}. Resets at 00:00 UTC (5:30 a.m. IST). Correct missed or extra counts manually.`;
    }
    async function refresh() {
      const request = ++revision;
      try {
        const data = await chrome.storage.local.get([
          "appliedList",
          APPLICATION_COUNTS_KEY,
          TRACKING_DAILY_TOTALS_KEY
        ]);
        if (disposed || request !== revision) return;
        const cached = data[TRACKING_DAILY_TOTALS_KEY]?.[utcDayKey()]?.total;
        total = typeof cached === "number" && Number.isSafeInteger(cached) && cached >= 0 ? cached : applicationCount(data.appliedList, data[APPLICATION_COUNTS_KEY]);
        ready = true;
        render();
      } catch {
        if (!disposed && request === revision) {
          ready = false;
          render();
          status.textContent = "Could not load the application count.";
          status.hidden = false;
        }
      }
    }
    async function adjust(delta) {
      busy = true;
      status.hidden = true;
      render();
      try {
        const result = await chrome.runtime.sendMessage({
          type: "eze-custom:adjust-count",
          delta,
          day: utcDayKey()
        });
        if (!result?.ok) throw new Error(result?.error || "Could not update the count. Try again.");
        if (!disposed) {
          await refresh();
          status.textContent = `Today\u2019s application count: ${result.count}`;
          status.hidden = false;
        }
      } catch (error) {
        if (!disposed) {
          status.textContent = error instanceof Error ? error.message : "Could not update the count.";
          status.hidden = false;
        }
      } finally {
        busy = false;
        if (!disposed) render();
      }
    }
    minus.addEventListener("click", () => void adjust(-1));
    plus.addEventListener("click", () => void adjust(1));
    const changed = (changes, area) => {
      if (!disposed && area === "local" && (changes.appliedList || changes[APPLICATION_COUNTS_KEY] || changes[TRACKING_DAILY_TOTALS_KEY]))
        void refresh();
    };
    chrome.storage.onChanged.addListener(changed);
    const stopRollover = watchUtcDay(() => void refresh());
    render();
    void refresh();
    function decorate() {
      if (disposed) return;
      const heading = [...document.querySelectorAll("#root h1")].find(
        (node3) => /\bapplications?\b.*\btoday\b/i.test(node3.textContent || "")
      );
      const chart = location.pathname.endsWith("/popup.html") ? document.querySelector("#root [data-chart]") : null;
      const anchor = heading || chart;
      if (!anchor) return;
      anchor.classList.add("eze-count-anchor");
      if (controls.parentElement !== anchor) anchor.append(controls);
      if (anchor.nextElementSibling !== status) anchor.after(status);
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        stopRollover();
        chrome.storage.onChanged.removeListener(changed);
        controls.remove();
        status.remove();
      }
    };
  }

  // src/activity-controls.ts
  function mountActivityControls() {
    let disposed = false, editor;
    const href = chrome.runtime.getURL("analytics.html");
    const shortcut = document.createElement("a");
    shortcut.href = href;
    shortcut.target = "_blank";
    shortcut.rel = "noopener";
    shortcut.title = "Analytics";
    shortcut.setAttribute("aria-label", "Open application analytics");
    shortcut.append(navigationIcon("analytics"));
    const nav = document.createElement("a");
    nav.href = href;
    nav.textContent = "Analytics";
    nav.dataset.ezeAnalytics = "true";
    const goal = document.createElement("button");
    goal.type = "button";
    goal.className = "eze-count-step eze-goal-edit";
    goal.title = "Edit daily goal";
    goal.setAttribute("aria-label", "Edit daily goal");
    const ns = "http://www.w3.org/2000/svg", pencil = document.createElementNS(ns, "svg"), path = document.createElementNS(ns, "path");
    pencil.setAttribute("viewBox", "0 0 24 24");
    pencil.setAttribute("fill", "none");
    pencil.setAttribute("stroke", "currentColor");
    pencil.setAttribute("stroke-width", "1.8");
    pencil.setAttribute("aria-hidden", "true");
    path.setAttribute("d", "m15 5 4 4M4 20l5-1L20 8a2.8 2.8 0 0 0-4-4L5 15l-1 5Z");
    pencil.append(path);
    goal.append(pencil);
    function openGoal() {
      if (editor) return;
      const dialog = document.createElement("dialog");
      editor = dialog;
      dialog.className = "eze-goal-dialog";
      dialog.setAttribute("aria-labelledby", "eze-goal-title");
      const form = document.createElement("form"), title = document.createElement("h2"), help = document.createElement("p");
      title.id = "eze-goal-title";
      title.textContent = "Your daily goal";
      help.textContent = "Set your target. Applications already counted stay counted.";
      const label = document.createElement("label");
      label.textContent = "Applications per day";
      const input = document.createElement("input");
      input.type = "number";
      input.min = "1";
      input.max = "10000";
      input.step = "1";
      input.required = true;
      input.value = "10";
      label.append(input);
      const error = document.createElement("p");
      error.className = "eze-goal-error";
      error.setAttribute("role", "alert");
      error.hidden = true;
      const actions = document.createElement("div");
      actions.className = "eze-goal-actions";
      const cancel = document.createElement("button"), save = document.createElement("button");
      cancel.type = "button";
      cancel.textContent = "Cancel";
      save.type = "submit";
      save.textContent = "Save goal";
      save.className = "eze-goal-save";
      actions.append(cancel, save);
      form.append(title, help, label, error, actions);
      dialog.append(form);
      document.body.append(dialog);
      let dirty = false;
      input.addEventListener("input", () => {
        dirty = true;
      });
      chrome.storage.local.get("dailyGoal").then((data) => {
        if (dialog.isConnected && !dirty && typeof data.dailyGoal === "number" && Number.isInteger(data.dailyGoal) && data.dailyGoal > 0)
          input.value = String(data.dailyGoal);
      }).catch(() => {
      });
      function close() {
        dialog.close?.();
        dialog.remove();
        editor = void 0;
        goal.focus();
      }
      cancel.addEventListener("click", close);
      dialog.addEventListener("cancel", (event) => {
        event.preventDefault();
        close();
      });
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const value = Number(input.value);
        error.hidden = true;
        if (!Number.isInteger(value) || value < 1 || value > 1e4) {
          error.textContent = "Choose a whole number from 1 to 10,000.";
          error.hidden = false;
          return;
        }
        save.disabled = true;
        try {
          const result = await chrome.runtime.sendMessage({
            type: "eze-tracking:set-goal",
            goal: value
          });
          if (!result?.ok) throw new Error(result?.error || "Could not save your goal. Try again.");
          if (dialog.isConnected) close();
        } catch (reason) {
          if (dialog.isConnected) {
            error.textContent = reason instanceof Error ? reason.message : "Could not save your goal.";
            error.hidden = false;
            save.disabled = false;
          }
        }
      });
      if (typeof dialog.showModal === "function") dialog.showModal();
      else dialog.setAttribute("open", "");
      input.focus();
      input.select();
    }
    goal.addEventListener("click", openGoal);
    function decorate() {
      if (disposed) return;
      const count = document.querySelector(".eze-count-controls");
      if (count && goal.parentElement !== count) count.append(goal);
      const applications = [...document.querySelectorAll("#root button")].find(
        (button4) => button4.title === "View Applications"
      );
      const shortcuts = applications?.parentElement;
      if (shortcuts && shortcut.parentElement !== shortcuts) {
        shortcut.className = `${applications.className} eze-analytics-shortcut`;
        shortcuts.append(shortcut);
      }
      const nativeNav = document.querySelector("#root .eze-native-nav-links");
      if (nativeNav && nav.parentElement !== nativeNav) nativeNav.append(nav);
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        editor?.remove();
        goal.remove();
        shortcut.remove();
        nav.remove();
      }
    };
  }

  // src/ai-entry.ts
  function node2(tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    if (text !== void 0) element.textContent = text;
    return element;
  }
  function aiPowerIcon() {
    const image = node2("img", "eze-ai-logo");
    image.src = chrome.runtime.getURL("custom/ai-logo.png");
    image.alt = "";
    image.setAttribute("aria-hidden", "true");
    image.width = 64;
    image.height = 64;
    image.decoding = "async";
    return image;
  }
  function aiSideEntry(url) {
    const link2 = node2("a", "eze-native-ai-link eze-native-ai-side");
    link2.href = url;
    link2.dataset.ezeAiLink = "true";
    const icon3 = node2("span", "eze-ai-side-icon");
    icon3.append(aiPowerIcon());
    const copy = node2("span", "eze-ai-side-copy");
    copy.append(
      node2("strong", "", "AI providers & keys"),
      node2("small", "", "Power up your applications")
    );
    link2.append(icon3, copy);
    return link2;
  }
  function aiSettingsHero(url) {
    const hero = node2("section", "eze-ai-hero");
    hero.dataset.ezeAiHero = "true";
    hero.setAttribute("aria-labelledby", "eze-ai-hero-title");
    const icon3 = node2("div", "eze-ai-power-icon");
    icon3.append(aiPowerIcon());
    const copy = node2("div", "eze-ai-hero-copy");
    const title = node2("h2", "", "Your application superpower");
    title.id = "eze-ai-hero-title";
    const providers = node2("div", "eze-ai-provider-list");
    providers.setAttribute("aria-label", "Supported AI providers");
    for (const name of ["OpenAI", "Claude", "Gemini", "+ more"])
      providers.append(node2("span", "", name));
    copy.append(
      node2("span", "eze-ai-eyebrow", "EZEapply AI"),
      title,
      node2("p", "", "Connect your AI provider. Choose your model. Draft answers in your own voice."),
      providers
    );
    const actions = node2("div", "eze-ai-hero-actions");
    const link2 = node2("a", "eze-ai-configure", "Configure AI");
    link2.href = url;
    const arrow = node2("span", "", "\u2197");
    arrow.setAttribute("aria-hidden", "true");
    link2.append(arrow);
    actions.append(link2, node2("span", "eze-ai-hero-hint", "Your keys. Your models."));
    hero.append(icon3, copy, actions);
    return hero;
  }

  // src/app-ui.ts
  function el2(tag, cls = "", text = "") {
    const node3 = document.createElement(tag);
    node3.className = cls;
    node3.textContent = text;
    return node3;
  }
  function button3(text, cls = "quiet-button") {
    const node3 = el2("button", cls, text);
    node3.type = "button";
    return node3;
  }
  function link(text, path, cls = "") {
    const node3 = el2("a", cls, text);
    node3.href = chrome.runtime.getURL(path);
    return node3;
  }
  function brand() {
    const img = el2("img", "wordmark");
    img.src = chrome.runtime.getURL("custom/wordmark.svg");
    img.alt = "EZEapply";
    img.width = 236;
    img.height = 40;
    return img;
  }
  async function rpc(type, extra = {}) {
    const result = await chrome.runtime.sendMessage({ type, ...extra });
    if (!result?.ok) throw new Error(result?.error || "Could not save this change. Try again.");
    return result;
  }
  function errorText(reason) {
    return reason instanceof Error ? reason.message : "This action could not be completed. Try again.";
  }
  function statusNode() {
    const node3 = el2("p", "app-status");
    node3.setAttribute("role", "status");
    node3.hidden = true;
    return node3;
  }
  function profileDate(value) {
    if (typeof value === "string") return value;
    const date = record(value), year = String(date.year ?? ""), month = String(date.month ?? "");
    return /^\d{4}$/.test(year) && /^(?:[1-9]|1[0-2])$/.test(month) ? `${year}-${month.padStart(2, "0")}` : "";
  }
  function showStatus(node3, text, error = false) {
    node3.textContent = text;
    node3.hidden = !text;
    node3.classList.toggle("error", error);
  }
  function safeWebsite(value) {
    try {
      const url = new URL(value);
      return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.href : "";
    } catch {
      return "";
    }
  }
  function downloadFile(name, blob) {
    const url = URL.createObjectURL(blob), anchor = el2("a");
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function resumeFromFile(file) {
    if (!file.size || file.size > 20 * 1024 * 1024)
      throw new Error("Choose a nonempty resume smaller than 20 MB.");
    if (!/\.(pdf|doc|docx|txt|rtf|odt)$/i.test(file.name))
      throw new Error("Choose a PDF, DOC, DOCX, text, RTF or ODT resume.");
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    for (let i = 0; i < bytes.length; i += 16384)
      binary += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return normalizeProfile({
      resumeData: {
        fileName: file.name,
        resumeBase64: btoa(binary),
        fileSize: file.size / 1024,
        dateUploaded: (/* @__PURE__ */ new Date()).toISOString()
      }
    }).resumeData;
  }
  function resumeDownload(saved) {
    const raw = string(saved.resumeBase64).replace(/^data:[^,]+,/, ""), bytes = Uint8Array.from(atob(raw), (c) => c.charCodeAt(0));
    downloadFile(string(saved.fileName), new Blob([bytes]));
  }
  function masterSwitch(initial) {
    const row = el2("label", "master-switch"), toggle = el2("input"), caption = el2("span", "", `Autofill ${initial ? "Enabled" : "Disabled"}`), status = statusNode();
    toggle.type = "checkbox";
    toggle.checked = initial;
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", "Enable autofill");
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked;
      toggle.disabled = true;
      try {
        await rpc("eze-app:autofill", { enabled: desired });
        caption.textContent = `Autofill ${desired ? "Enabled" : "Disabled"}`;
        showStatus(status, "");
      } catch (error) {
        toggle.checked = !desired;
        showStatus(status, errorText(error), true);
      } finally {
        toggle.disabled = false;
      }
    });
    row.append(toggle, caption);
    const block = el2("div", "master-control");
    block.append(row, status);
    return block;
  }
  function ring() {
    const chart = el2("div", "daily-ring");
    chart.dataset.chart = "today";
    chart.title = "Today resets at 00:00 UTC (5:30 a.m. IST).";
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 240 240");
    svg.setAttribute("aria-hidden", "true");
    for (const cls of ["ring-track", "ring-value"]) {
      const circle = document.createElementNS(ns, "circle");
      for (const [key, value] of Object.entries({
        cx: "120",
        cy: "120",
        r: "105",
        fill: "none",
        class: cls
      }))
        circle.setAttribute(key, value);
      svg.append(circle);
    }
    const text = el2("div", "ring-text");
    text.append(
      el2("strong", "daily-total", "0"),
      el2("span", "", "Applications Today"),
      el2("small", "daily-goal", "Goal: 10")
    );
    chart.append(svg, text);
    return chart;
  }
  async function mountApp(root) {
    let disposed = false, view = 0;
    const path = location.pathname, popup = path.endsWith("/popup.html"), side = path.endsWith("/sidepanel.html");
    const cleanup = [];
    let settings = await chrome.storage.local.get([
      "profile",
      "autofillEnabled",
      "dailyGoal",
      TRACKING_DAILY_TOTALS_KEY,
      "appliedList",
      APPLICATION_COUNTS_KEY
    ]);
    if (disposed) return () => {
    };
    const appearance = side ? void 0 : mountThemePicker(root.ownerDocument);
    if (appearance) cleanup.push(() => appearance.dispose());
    function counts() {
      const cached = record(record(settings[TRACKING_DAILY_TOTALS_KEY])[utcDayKey()]).total;
      return typeof cached === "number" && Number.isSafeInteger(cached) && cached >= 0 ? cached : applicationCount(settings.appliedList, settings[APPLICATION_COUNTS_KEY]);
    }
    function paintCount() {
      const total = counts(), goal = typeof settings.dailyGoal === "number" && settings.dailyGoal > 0 ? settings.dailyGoal : 10;
      for (const node3 of root.querySelectorAll(".daily-total")) node3.textContent = String(total);
      for (const node3 of root.querySelectorAll(".daily-goal")) node3.textContent = `Goal: ${goal}`;
      const circle = root.querySelector(".ring-value");
      if (circle instanceof SVGElement) {
        circle.style.strokeDasharray = `${Math.min(1, total / goal) * 660} 660`;
        circle.style.opacity = total > 0 ? "1" : "0";
      }
      const bar = root.querySelector(".daily-progress-value");
      if (bar) bar.style.width = `${Math.min(100, total / goal * 100)}%`;
    }
    if (popup) {
      const windowId = (await chrome.windows.getCurrent()).id;
      document.body.classList.add("popup-page");
      appearance.button.classList.add("popup-appearance");
      root.append(appearance.button);
      const extensions = button3("", "popup-extensions");
      extensions.title = "Open Chrome extensions";
      extensions.setAttribute("aria-label", "Open Chrome extensions");
      extensions.append(navigationIcon("extensions"));
      extensions.addEventListener("click", async () => {
        extensions.disabled = true;
        try {
          await chrome.tabs.create({ url: "chrome://extensions/" });
          showStatus(status, "");
        } catch (error) {
          showStatus(status, errorText(error), true);
        } finally {
          extensions.disabled = false;
        }
      });
      root.append(extensions, brand(), ring());
      const shortcuts = el2("div", "popup-shortcuts");
      for (const [title, target, kind] of [
        ["View Applications", "options.html#/", "applications"],
        ["Manage Profile", "options.html#/profile", "profile"],
        ["Manage Settings", "options.html#/settings/autofill", "settings"]
      ]) {
        const control = button3("", "popup-shortcut");
        control.title = title;
        control.setAttribute("aria-label", title);
        control.append(navigationIcon(kind));
        control.addEventListener("click", () => {
          void chrome.tabs.create({ url: chrome.runtime.getURL(target) });
        });
        shortcuts.append(control);
      }
      root.append(shortcuts);
      const quick = button3("Quick Access Sidepane", "quick-access");
      quick.prepend(navigationIcon("sidepane"));
      quick.title = "Open the EZEapply side panel";
      const status = statusNode();
      quick.addEventListener("click", () => {
        if (windowId === void 0) {
          showStatus(status, "No active Chrome window.", true);
          return;
        }
        void chrome.sidePanel.open({ windowId }).then(
          () => window.close(),
          (error) => showStatus(status, errorText(error), true)
        );
      });
      root.append(quick, status);
      const switches = el2("div", "popup-switches"), master = masterSwitch(settings.autofillEnabled !== false);
      switches.append(...master.childNodes);
      root.append(switches);
      const preferences = mountPopupControls();
      cleanup.push(() => preferences.dispose());
    } else if (side) {
      document.body.classList.add("sidepanel-page");
      const summary = el2("section", "side-summary"), heading = el2("h1");
      heading.append(
        el2("strong", "daily-total", "0"),
        document.createTextNode(" Applications "),
        el2("small", "", "today")
      );
      heading.title = "Today resets at 00:00 UTC (5:30 a.m. IST).";
      const progress = el2("div", "daily-progress");
      progress.append(el2("span", "daily-progress-value"));
      summary.append(heading, el2("p", "daily-goal", "Goal: 10"), progress);
      root.append(summary);
      const shortcuts = el2("div", "side-links");
      shortcuts.append(
        link("Edit profile", "options.html#/profile"),
        link("Applications", "options.html#/"),
        link("Analytics", "analytics.html")
      );
      for (const anchor of shortcuts.querySelectorAll("a")) anchor.target = "_blank";
      let profileView = mountProfileView(normalizeProfile(settings.profile), resumeDownload);
      const cvTray = mountCVTray();
      cleanup.push(() => cvTray.dispose());
      root.append(
        shortcuts,
        cvTray.element,
        el2("h2", "side-profile-title", "Profile"),
        profileView.element
      );
      const profileChanged = (changes, area) => {
        if (disposed || area !== "local" || !changes.profile) return;
        const next = mountProfileView(normalizeProfile(changes.profile.newValue), resumeDownload);
        profileView.element.replaceWith(next.element);
        profileView.dispose();
        profileView = next;
      };
      chrome.storage.onChanged.addListener(profileChanged);
      cleanup.push(() => {
        profileView.dispose();
        chrome.storage.onChanged.removeListener(profileChanged);
      });
    } else {
      document.body.classList.add("options-page");
      const header = el2("header", "app-header"), home = link("", "options.html#/");
      home.append(brand());
      const nav = el2("nav", "app-nav");
      nav.setAttribute("aria-label", "Main navigation");
      for (const [title, hash] of [
        ["Applications", "#/"],
        ["Profile", "#/profile"],
        ["Settings", "#/settings/autofill"]
      ]) {
        const anchor = el2("a", "", title);
        anchor.href = hash;
        nav.append(anchor);
      }
      nav.append(link("Analytics", "analytics.html"));
      const ai = link("AI settings", "ai-settings.html", "nav-ai");
      ai.prepend(aiPowerIcon());
      nav.append(ai);
      nav.append(appearance.button);
      header.append(home, nav);
      const main = el2("main", "app-main"), footer = el2(
        "footer",
        "app-footer",
        `Created by Piyush Agarwal \xB7 EZEapply ${chrome.runtime.getManifest().version}`
      );
      root.append(header, main, footer);
      const render = async () => {
        const revision = ++view;
        try {
          settings = {
            ...settings,
            ...await chrome.storage.local.get(["profile", "autofillEnabled", "dailyGoal"])
          };
          if (disposed || revision !== view) return;
          const hash = location.hash;
          for (const anchor of nav.querySelectorAll("a")) {
            const selected = anchor.getAttribute("href") === (hash || "#/");
            anchor.classList.toggle("active", selected);
            if (selected) anchor.setAttribute("aria-current", "page");
            else anchor.removeAttribute("aria-current");
          }
          main.replaceChildren();
          if (hash.startsWith("#/profile")) renderProfile(main, normalizeProfile(settings.profile));
          else if (hash.startsWith("#/settings")) {
            const section = el2("div", "settings-layout"), aside = el2("aside");
            aside.append(aiSideEntry(chrome.runtime.getURL("ai-settings.html")));
            const card = el2("section", "card");
            card.append(
              el2("h2", "", "Autofill"),
              masterSwitch(settings.autofillEnabled !== false),
              el2(
                "p",
                "muted",
                "Saved answers fill empty application fields. Your edits are kept. Choose automatic filling in the toolbar popup."
              ),
              link("Open reusable answers", "custom-fields.html", "text-link"),
              link("Edit goal & view progress", "analytics.html", "text-link")
            );
            section.append(aside, card);
            main.append(
              el2("h1", "", "Settings"),
              aiSettingsHero(chrome.runtime.getURL("ai-settings.html")),
              section
            );
          } else {
            await renderApplications(main, () => !disposed && revision === view);
          }
        } catch (error) {
          if (revision === view) {
            main.replaceChildren(
              el2("h1", "", "Could not load this page"),
              el2("p", "error", errorText(error))
            );
          }
        }
      };
      const changed = () => {
        void render();
      };
      window.addEventListener("hashchange", changed);
      cleanup.push(() => window.removeEventListener("hashchange", changed));
      await render();
      const refreshHistory = (changes, area) => {
        if (area === "local" && changes[TRACKING_CACHE_KEY] && !location.hash.startsWith("#/profile") && !location.hash.startsWith("#/settings"))
          void render();
      };
      chrome.storage.onChanged.addListener(refreshHistory);
      cleanup.push(() => chrome.storage.onChanged.removeListener(refreshHistory));
    }
    if (popup || side) {
      paintCount();
      const count = mountApplicationCount(), activity = mountActivityControls();
      cleanup.push(
        () => count.dispose(),
        () => activity.dispose()
      );
      const changed = (changes, area) => {
        if (area !== "local") return;
        for (const [key, value] of Object.entries(changes)) settings[key] = value.newValue;
        paintCount();
      };
      chrome.storage.onChanged.addListener(changed);
      const stopRollover = watchUtcDay(paintCount, root.ownerDocument);
      cleanup.push(() => chrome.storage.onChanged.removeListener(changed), stopRollover);
    }
    return () => {
      disposed = true;
      view++;
      cleanup.forEach((fn) => fn());
      root.replaceChildren();
    };
  }
  async function renderApplications(main, current) {
    const result = await rpc("eze-tracking:snapshot"), snapshot = result.snapshot;
    const data = await chrome.storage.local.get("eze.applicationStages.v1");
    if (!current()) return;
    const stages = record(data["eze.applicationStages.v1"]), heading = el2("div", "page-heading");
    heading.append(
      el2("h1", "", "Applications"),
      link("View analytics \u2197", "analytics.html", "quiet-button")
    );
    const controls = el2("div", "application-filters"), search = el2("input"), source = el2("select"), stage = el2("select");
    search.type = "search";
    search.placeholder = "Search applications\u2026";
    search.setAttribute("aria-label", "Search applications");
    for (const [value, text] of [
      ["", "All sources"],
      ["linkedin", "LinkedIn Easy Apply"],
      ["external", "External forms"],
      ["unknown", "Imported / unclassified"]
    ]) {
      const option = el2("option", "", text);
      option.value = value;
      source.append(option);
    }
    source.setAttribute("aria-label", "Application source");
    for (const value of ["Any stage", "Applied", "Interview", "Offer", "Rejected"])
      stage.append(el2("option", "", value));
    stage.setAttribute("aria-label", "Application stage");
    controls.append(search, source, stage);
    const status = statusNode(), container = el2("div", "application-list"), note = el2(
      "p",
      "muted",
      "Confirmed submissions are captured automatically. Correct missed counts with \u2212 / + in the popup."
    );
    const pages = el2("nav", "journal-pages"), range = el2("span", "muted"), previous = button3("\u2190 Previous"), next = button3("Next \u2192");
    pages.setAttribute("aria-label", "Application journal pages");
    pages.append(range, previous, next);
    let page = 0;
    previous.addEventListener("click", () => {
      page = Math.max(0, page - 1);
      draw();
    });
    next.addEventListener("click", () => {
      page++;
      draw();
    });
    main.append(heading, note, controls, status, container, pages);
    function draw() {
      container.replaceChildren();
      const matches = snapshot.records.filter(
        (item) => `${item.jobTitle} ${item.company}`.toLowerCase().includes(search.value.toLowerCase()) && (!source.value || item.source === source.value) && (stage.value === "Any stage" || (stages[item.id] || "Applied") === stage.value)
      ).sort((a, b) => Date.parse(b.submittedAt) - Date.parse(a.submittedAt));
      page = Math.min(page, Math.max(0, Math.ceil(matches.length / 50) - 1));
      pages.hidden = matches.length === 0;
      previous.disabled = page === 0;
      next.disabled = (page + 1) * 50 >= matches.length;
      range.textContent = `${page * 50 + 1}\u2013${Math.min(matches.length, (page + 1) * 50)} of ${matches.length}`;
      if (!matches.length) {
        const empty = el2("section", "card empty-state");
        empty.append(
          navigationIcon("applications"),
          el2("h2", "", "Your next opportunity starts here"),
          el2(
            "p",
            "muted",
            snapshot.records.length ? "No applications match these filters." : "Confirmed applications will appear here. Open a job form and use EZEapply to get started."
          )
        );
        container.append(empty);
        return;
      }
      const table = el2("table"), head = el2("thead"), row = el2("tr");
      for (const title of ["Job & company", "Source", "Stage", "Applied (UTC)"])
        row.append(el2("th", "", title));
      head.append(row);
      table.append(head);
      const body = el2("tbody");
      for (const item of matches.slice(page * 50, (page + 1) * 50)) {
        const row2 = el2("tr"), job = el2("td"), url = safeWebsite(item.url), title = url ? el2("a", "job-title", item.jobTitle || "Application") : el2("strong", "job-title", item.jobTitle || "Application");
        if (title instanceof HTMLAnchorElement) {
          title.href = url;
          title.target = "_blank";
          title.rel = "noopener noreferrer";
        }
        job.append(title, el2("small", "muted", item.company || "Company not captured"));
        const src = el2("td");
        src.append(
          el2(
            "span",
            `source-chip ${item.source}`,
            item.source === "linkedin" ? "LinkedIn" : item.source === "external" ? "External form" : "Imported"
          )
        );
        const progress = el2("td"), select = el2("select");
        select.setAttribute("aria-label", `Stage for ${item.jobTitle || "application"}`);
        for (const value of ["Applied", "Interview", "Offer", "Rejected"])
          select.append(el2("option", "", value));
        select.value = string(stages[item.id]) || "Applied";
        select.addEventListener("change", async () => {
          const desired = select.value;
          select.disabled = true;
          try {
            await rpc("eze-app:stage", { id: item.id, stage: desired });
            stages[item.id] = desired;
            showStatus(status, "Stage saved.");
          } catch (error) {
            select.value = string(stages[item.id]) || "Applied";
            showStatus(status, errorText(error), true);
          } finally {
            select.disabled = false;
          }
        });
        progress.append(select);
        row2.append(
          job,
          src,
          progress,
          el2(
            "td",
            "muted",
            new Date(item.submittedAt).toLocaleDateString(void 0, {
              day: "numeric",
              month: "short",
              year: "numeric",
              timeZone: "UTC"
            })
          )
        );
        body.append(row2);
      }
      table.append(body);
      container.append(table);
    }
    const filter = () => {
      page = 0;
      draw();
    };
    search.addEventListener("input", filter);
    source.addEventListener("change", filter);
    stage.addEventListener("change", filter);
    draw();
  }
  function renderProfile(main, profile) {
    const heading = el2("div", "page-heading"), tools = el2("div", "toolbar"), exportButton = button3("Export"), importButton = button3("Import"), picker = el2("input");
    picker.type = "file";
    picker.accept = ".json,application/json";
    picker.hidden = true;
    heading.append(el2("h1", "", "Profile"), tools);
    tools.append(importButton, exportButton, picker);
    const form = el2("form", "profile-form"), status = statusNode();
    main.append(
      heading,
      el2(
        "p",
        "muted",
        "Your profile stays on this device. Saved answers and AI use these facts when enabled."
      ),
      status,
      form
    );
    const sync = [];
    let busy = false, dirty = false;
    const save = el2("button", "primary-button", "Save profile");
    save.type = "submit";
    form.addEventListener("input", () => {
      dirty = true;
      showStatus(status, "Unsaved changes");
    });
    function field(parent, label, obj, key, type = "text") {
      const wrapper = el2("label", "form-field");
      wrapper.append(el2("span", "", label));
      const input = type === "textarea" ? el2("textarea") : el2("input");
      if (input instanceof HTMLInputElement) input.type = type;
      const original = obj[key];
      input.value = typeof original === "boolean" ? original ? "Yes" : "No" : typeof original === "number" ? String(original) : string(original);
      if (key === "startDate" || key === "endDate") input.value = profileDate(original);
      let initial = input.value;
      if (input instanceof HTMLTextAreaElement) input.rows = 3;
      input.maxLength = 3e4;
      wrapper.append(input);
      sync.push(() => {
        if (input.value !== initial) {
          const value = input.value.trim();
          obj[key] = typeof original === "boolean" && /^(yes|no)$/i.test(value) ? value.toLowerCase() === "yes" : value;
          initial = input.value;
        }
      });
      parent.append(wrapper);
    }
    function section(title) {
      const section2 = el2("section", "card profile-section");
      section2.append(el2("h2", "", title));
      const grid2 = el2("div", "form-grid");
      section2.append(grid2);
      form.append(section2);
      return grid2;
    }
    let grid = section("Personal details");
    field(grid, "Profile name", profile, "profileName");
    for (const [label, key] of [
      ["First name", "firstName"],
      ["Middle name", "middleName"],
      ["Last name", "lastName"]
    ])
      field(grid, label, profile.nameData, key);
    grid = section("Contact & address");
    for (const [label, key, type] of [
      ["Email", "email", "email"],
      ["Phone number (include country code)", "phoneNumber", "tel"]
    ])
      field(grid, label, profile.contactData, key, type);
    for (const [label, key] of [
      ["Address line 1", "line1"],
      ["Address line 2", "line2"],
      ["City", "city"],
      ["State / province", "state"],
      ["Postal code", "postalCode"],
      ["Country", "country"]
    ])
      field(grid, label, profile.addressData, key);
    grid = section("Portfolio");
    for (const [label, key] of [
      ["LinkedIn", "linkedin"],
      ["GitHub", "github"],
      ["Personal website", "personal"]
    ])
      field(grid, label, profile.websiteData, key, "url");
    const extra = {
      websites: Array.isArray(profile.websiteData.websites) ? profile.websiteData.websites.filter((v) => typeof v === "string").join("\n") : ""
    }, skills = { skills: profile.skillsData.join(", ") };
    field(grid, "Other links (one per line)", extra, "websites", "textarea");
    field(grid, "Skills (comma separated)", skills, "skills");
    sync.push(() => {
      profile.websiteData.websites = extra.websites.split("\n").map((v) => v.trim()).filter(Boolean);
      profile.skillsData = skills.skills.split(",").map((v) => v.trim()).filter(Boolean);
    });
    const resume = el2("div", "resume-editor"), resumeName = el2("span", "muted", string(profile.resumeData.fileName) || "No resume saved"), resumePicker = el2("input"), replace = button3("Choose resume"), download = button3("Download"), remove = button3("Remove resume");
    resumePicker.type = "file";
    resumePicker.accept = ".pdf,.doc,.docx,.txt,.rtf,.odt";
    resumePicker.hidden = true;
    download.disabled = remove.disabled = !string(profile.resumeData.resumeBase64);
    replace.addEventListener("click", () => resumePicker.click());
    download.addEventListener("click", () => resumeDownload(profile.resumeData));
    remove.addEventListener("click", () => {
      if (confirm("Remove the saved resume? Save profile to keep this change.")) {
        profile.resumeData = {};
        resumeName.textContent = "No resume saved";
        download.disabled = remove.disabled = true;
        dirty = true;
        showStatus(status, "Unsaved changes");
      }
    });
    resumePicker.addEventListener("change", async () => {
      const file = resumePicker.files?.[0];
      if (!file) return;
      busy = true;
      save.disabled = replace.disabled = true;
      try {
        profile.resumeData = await resumeFromFile(file);
        resumeName.textContent = string(profile.resumeData.fileName);
        download.disabled = remove.disabled = false;
        dirty = true;
        showStatus(status, "Resume ready. Save profile to keep it.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        save.disabled = replace.disabled = false;
        resumePicker.value = "";
      }
    });
    resume.append(resumeName, replace, download, remove, resumePicker);
    grid.parentElement?.append(resume);
    function history(title, key, columns, flag) {
      const section2 = el2("section", "card profile-section"), titleRow = el2("div", "page-heading"), add = button3("+ Add");
      titleRow.append(el2("h2", "", title), add);
      const entries = el2("div", "history-entries");
      section2.append(titleRow, entries);
      form.append(section2);
      function entry(item) {
        const box = el2("fieldset", "history-editor"), grid2 = el2("div", "form-grid"), deleteEntry = button3("Remove entry", "danger-button");
        for (const [label, key2, type] of columns) field(grid2, label, item, key2, type);
        if (flag) {
          const row = el2("label", "check-field"), input = el2("input");
          input.type = "checkbox";
          input.checked = item[flag[1]] === true;
          row.append(input, document.createTextNode(flag[0]));
          grid2.append(row);
          sync.push(() => {
            item[flag[1]] = input.checked;
          });
        }
        deleteEntry.addEventListener("click", () => {
          if (confirm("Remove this entry? Save profile to keep this change.")) {
            profile[key] = profile[key].filter((value) => value !== item);
            box.remove();
            dirty = true;
            showStatus(status, "Unsaved changes");
          }
        });
        box.append(grid2, deleteEntry);
        entries.append(box);
      }
      profile[key].forEach(entry);
      add.addEventListener("click", () => {
        if (profile[key].length >= 100) {
          showStatus(status, "This section is limited to 100 entries.", true);
          return;
        }
        const item = {};
        profile[key].push(item);
        entry(item);
        dirty = true;
        entries.lastElementChild?.querySelector("input")?.focus();
      });
    }
    history(
      "Work history",
      "jobData",
      [
        ["Job title", "jobTitle"],
        ["Company", "company"],
        ["Location", "location"],
        ["Start date", "startDate"],
        ["End date", "endDate"],
        ["Description", "description", "textarea"]
      ],
      ["I currently work here", "currentlyWorkHere"]
    );
    history("Education", "educationData", [
      ["School / institution", "school"],
      ["Degree", "degree"],
      ["Field of study", "fieldOfStudy"],
      ["Start date", "startDate"],
      ["End date", "endDate"]
    ]);
    history("Languages", "languageData", [
      ["Language", "language"],
      ["Proficiency", "proficiency"]
    ]);
    grid = section("Employment information");
    for (const [label, key] of [
      ["Authorized to work in country of residence", "eligibilityUS"],
      ["Visa sponsorship", "sponsorship"],
      ["Gender", "gender"],
      ["Ethnicity", "ethnicity"],
      ["Veteran status", "veteranStatus"],
      ["Disability", "disability"],
      ["Age", "age"]
    ])
      field(grid, label, profile.employmentData, key);
    form.append(save);
    const collect = () => {
      sync.forEach((fn) => fn());
      return normalizeProfile(profile);
    };
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      busy = true;
      save.disabled = true;
      try {
        await rpc("eze-app:save-profile", { profile: collect() });
        dirty = false;
        showStatus(status, "Profile saved.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        save.disabled = false;
      }
    });
    exportButton.addEventListener("click", () => {
      try {
        downloadFile(
          "EZEapply-profile.json",
          new Blob([JSON.stringify({ version: 1, profile: collect() }, null, 2)], {
            type: "application/json"
          })
        );
      } catch (error) {
        showStatus(status, errorText(error), true);
      }
    });
    importButton.addEventListener("click", () => picker.click());
    picker.addEventListener("change", async () => {
      const file = picker.files?.[0];
      if (!file || busy) return;
      try {
        if (file.size > 32e6) throw new Error("Choose a profile export smaller than 32 MB.");
        const imported = parseProfileImport(await file.text());
        if (dirty && !confirm("Replace your unsaved profile edits with this import?")) return;
        if (!confirm(
          "Replace your saved profile with this imported profile? Reusable answers and API keys stay unchanged."
        ))
          return;
        busy = true;
        importButton.disabled = true;
        await rpc("eze-app:save-profile", { profile: imported });
        main.replaceChildren();
        renderProfile(main, imported);
        const next = main.querySelector(".app-status");
        if (next) showStatus(next, "Profile imported.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        importButton.disabled = false;
        picker.value = "";
      }
    });
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.id && typeof document !== "undefined") {
    const root = document.getElementById("root");
    if (root)
      void mountApp(root).catch((error) => {
        root.replaceChildren(el2("p", "error", errorText(error)));
      });
  }
})();
