"use strict";
(() => {
  // src/app-profile.ts
  function record(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function string(value) {
    return typeof value === "string" ? value : "";
  }
  function safeValue(value, depth = 0) {
    if (typeof value === "string") return value.slice(0, 3e4);
    if (typeof value === "boolean" || value === null || typeof value === "number" && Number.isFinite(value))
      return value;
    if (depth >= 4) return void 0;
    if (Array.isArray(value))
      return value.slice(0, 100).map((item) => safeValue(item, depth + 1)).filter((item) => item !== void 0);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.entries(record(value)).slice(0, 80).filter(([key]) => !["__proto__", "constructor", "prototype"].includes(key)).map(([key, item]) => [key, safeValue(item, depth + 1)]).filter(([, item]) => item !== void 0)
      );
    return void 0;
  }
  function fields(value) {
    return record(safeValue(record(value)));
  }
  function normalizeProfile(input) {
    const raw = record(input);
    const profile = {
      profileName: string(raw.profileName).slice(0, 100) || "My profile",
      nameData: fields(raw.nameData),
      contactData: fields(raw.contactData),
      addressData: fields(raw.addressData),
      websiteData: fields(raw.websiteData),
      employmentData: fields(raw.employmentData),
      resumeData: {},
      jobData: [],
      educationData: [],
      languageData: [],
      skillsData: []
    };
    for (const key of ["jobData", "educationData", "languageData"]) {
      const values = raw[key];
      if (values !== void 0 && !Array.isArray(values))
        throw new Error("Profile history must be a list.");
      if (Array.isArray(values)) {
        if (values.length > 100)
          throw new Error("A profile can contain up to 100 entries in each history section.");
        profile[key] = values.map(fields);
      }
    }
    profile.skillsData = Array.isArray(raw.skillsData) ? [
      ...new Set(
        raw.skillsData.filter((v) => typeof v === "string").map((v) => v.trim().slice(0, 200)).filter(Boolean)
      )
    ].slice(0, 300) : [];
    const resume = record(raw.resumeData), bytes = string(resume.resumeBase64);
    if (bytes.length > 28e6) throw new Error("Choose a resume smaller than 20 MB.");
    if (bytes && !/^(?:data:[\w.+/-]+;base64,)?[A-Za-z0-9+/]*={0,2}$/.test(bytes))
      throw new Error("The resume data is not a valid file.");
    if (bytes && !/\.(pdf|doc|docx|txt|rtf|odt)$/i.test(string(resume.fileName)))
      throw new Error("Choose a PDF, DOC, DOCX, text, RTF or ODT resume.");
    profile.resumeData = {
      fileName: string(resume.fileName).replace(/[\u0000-\u001f/\\]/g, "").slice(0, 240),
      resumeBase64: bytes,
      fileSize: typeof resume.fileSize === "number" && Number.isFinite(resume.fileSize) ? Math.max(0, resume.fileSize) : 0,
      dateUploaded: string(resume.dateUploaded).slice(0, 100)
    };
    return profile;
  }
  function parseProfileImport(text) {
    if (text.length > 32e6) throw new Error("Choose a profile export smaller than 32 MB.");
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("Choose a valid JSON profile export.");
    }
    const container = record(parsed), raw = record(container.profile || container.profileData || container);
    if (!raw.nameData && !raw.contactData && !raw.educationData)
      throw new Error(
        "This is not an applicant profile export. Import reusable answers from Your fields instead."
      );
    return normalizeProfile(raw);
  }

  // src/types.ts
  var STORAGE_KEY = "eze.customFields.v1";
  var PANEL_RESTORE_KEY = "eze.showFloatingRestore";
  var LINKEDIN_NOFOLLOW_KEY = "eze.linkedin.disableAutoFollow";
  var APPLICATION_COUNTS_KEY = "eze.applicationCountAdjustments.v1";

  // src/profile-fields.ts
  var OTHER_PERSON = [
    "referrer",
    "referral",
    "referred by",
    "reference",
    "recruiter",
    "emergency",
    "manager",
    "supervisor",
    "parent",
    "guardian"
  ];
  var OTHER_ADDRESS = [
    ...OTHER_PERSON,
    "company",
    "employer",
    "office",
    "school",
    "university",
    "institution",
    "billing",
    "shipping",
    "previous",
    "former",
    "preferred",
    "desired",
    "job location"
  ];

  // src/storage.ts
  var emptyProfile = () => ({ fields: [], autoFill: true });
  var SHORTCUT_IDS = new Set(
    [
      "first",
      "middle",
      "middle-initial",
      "last",
      "full",
      "phone-local",
      "phone-international",
      "dial-code",
      "phone-formatted"
    ].map((id) => `builtin:${id}`)
  );
  function object(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function string2(value) {
    return typeof value === "string" ? value : "";
  }
  function contextFrom(data) {
    const profile = object(data.profile);
    const names = object(profile.nameData);
    const contact = object(profile.contactData);
    const synced = object(data.lastSyncProfile);
    return {
      id: string2(synced.id) || "local",
      name: [names.firstName, names.lastName].filter(Boolean).join(" ") || "Your profile",
      personal: { ...names, ...contact, country: object(profile.addressData).country }
    };
  }
  function validateProfile(input) {
    const data = object(input);
    if (!Array.isArray(data.fields) || data.fields.length > 2e3 || typeof data.autoFill !== "boolean") {
      throw new Error(
        "Choose a custom-fields export with a fields list and an automatic-fill setting (up to 2,000 fields)."
      );
    }
    const validateFields = (values, shortcuts = false) => {
      const seen = /* @__PURE__ */ new Set();
      return values.map((raw) => {
        const field = object(raw);
        const id = string2(field.id);
        const label = string2(field.label).trim();
        const value = string2(field.value);
        if (!id || (shortcuts ? !SHORTCUT_IDS.has(id) : id.startsWith("builtin:")) || seen.has(id) || !label || label.length > 200 || value.length > 3e4) {
          throw new Error(
            "Every field needs a unique ID, a label (up to 200 characters), and an answer under 30,000 characters."
          );
        }
        seen.add(id);
        const list = (key) => {
          if (!Array.isArray(field[key]) || field[key].length > 100 || field[key].some((v) => typeof v !== "string" || v.length > 300)) {
            throw new Error(
              "Matching phrases and exclusions must be text lists (up to 100 phrases, 300 characters each)."
            );
          }
          return [...new Set(field[key].map((s) => s.trim()).filter(Boolean))];
        };
        let scope = string2(field.scope).trim().toLowerCase();
        if (scope) {
          try {
            const parsed = new URL(scope.includes("://") ? scope : `https://${scope}`);
            if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash || parsed.port)
              throw new Error();
            scope = parsed.hostname;
          } catch {
            throw new Error(
              "Site scope must be a hostname, such as linkedin.com. Leave it empty for every site."
            );
          }
        }
        if (!["exact", "phrase"].includes(string2(field.matchMode)) || typeof field.enabled !== "boolean") {
          throw new Error("Each field needs an exact/phrase match mode and an enabled setting.");
        }
        return {
          id,
          label,
          value,
          aliases: list("aliases"),
          exclude: list("exclude"),
          category: string2(field.category).trim().slice(0, 100) || "Personal questions",
          enabled: field.enabled,
          matchMode: field.matchMode,
          scope
        };
      });
    };
    const fields2 = validateFields(data.fields);
    if (data.profileOverrides !== void 0 && (!Array.isArray(data.profileOverrides) || data.profileOverrides.length > SHORTCUT_IDS.size))
      throw new Error("Profile edits must be a list of valid profile shortcuts.");
    const profileOverrides = data.profileOverrides === void 0 ? void 0 : validateFields(data.profileOverrides, true);
    const hidden = data.hiddenBuiltIns;
    if (hidden !== void 0 && (!Array.isArray(hidden) || hidden.length > 100 || hidden.some((id) => typeof id !== "string" || !/^builtin:[a-z-]{1,80}$/.test(id)))) {
      throw new Error("Hidden profile shortcuts must be a list of valid shortcut IDs.");
    }
    const order = data.fieldOrder;
    if (order !== void 0 && (!Array.isArray(order) || order.length > 2200 || order.some((id) => typeof id !== "string" || !id.trim() || id.length > 200))) {
      throw new Error(
        "Field order must be a list of up to 2,200 nonempty field IDs, each at most 200 characters."
      );
    }
    return {
      fields: fields2,
      autoFill: data.autoFill,
      ...hidden === void 0 ? {} : { hiddenBuiltIns: [...new Set(hidden)] },
      ...order === void 0 ? {} : { fieldOrder: [...new Set(order)] },
      ...profileOverrides === void 0 ? {} : { profileOverrides }
    };
  }
  async function getAutoFillPreference() {
    const data = await chrome.storage.local.get(["profile", "lastSyncProfile", STORAGE_KEY]);
    const { id } = contextFrom(data);
    const store = data[STORAGE_KEY];
    const saved = store?.version === 1 && store.profiles?.[id] ? validateProfile(store.profiles[id]) : emptyProfile();
    return { profileId: id, enabled: saved.autoFill };
  }
  async function setAutoFillPreference(enabled, expectedProfileId) {
    const result = await chrome.runtime.sendMessage({
      type: "eze-custom:auto-fill",
      profileId: expectedProfileId,
      enabled
    });
    if (!result?.ok)
      throw new Error(result?.error || "Automatic filling could not be saved. Please try again.");
  }

  // src/popup-controls.ts
  function savedAnswersSwitch() {
    let disposed = false, ready = false, saving = false, revision = 0;
    let preference = { profileId: "", enabled: false };
    const row = document.createElement("label");
    row.className = "eze-popup-option eze-popup-auto-fill";
    row.title = "Fill empty job application fields from your saved answers when pages and new form steps load. Synced with Auto fill in the side panel. Your edits are kept.";
    const toggle = document.createElement("input");
    toggle.type = "checkbox";
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", "Auto-fill saved answers");
    const text = document.createElement("span");
    text.textContent = "Auto-fill saved answers";
    row.append(toggle, text);
    const status = document.createElement("div");
    status.className = "eze-popup-preference-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      toggle.checked = preference.enabled;
      toggle.disabled = !ready || saving;
    }
    async function refresh() {
      const request = ++revision;
      ready = false;
      render();
      try {
        const current = await getAutoFillPreference();
        if (disposed || request !== revision) return;
        preference = current;
        ready = true;
        status.hidden = true;
      } catch {
        if (!disposed && request === revision) {
          status.textContent = "Could not load automatic filling. Reopen this popup to retry.";
          status.hidden = false;
        }
      } finally {
        if (!disposed && request === revision) render();
      }
    }
    const changed = (changes, area) => {
      if (!disposed && area === "local" && (changes[STORAGE_KEY] || changes.profile || changes.lastSyncProfile))
        void refresh();
    };
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked, profileId = preference.profileId;
      saving = true;
      status.hidden = true;
      render();
      try {
        await setAutoFillPreference(desired, profileId);
        if (!disposed) await refresh();
      } catch (error) {
        if (!disposed) {
          status.textContent = error instanceof Error ? error.message : "Could not save automatic filling. Try again.";
          status.hidden = false;
        }
      } finally {
        saving = false;
        if (!disposed) render();
      }
    });
    chrome.storage.onChanged.addListener(changed);
    void refresh();
    return {
      row,
      status,
      dispose() {
        disposed = true;
        chrome.storage.onChanged.removeListener(changed);
        row.remove();
        status.remove();
      }
    };
  }
  function savedSwitch(key, label, accessibleLabel, title, cls, settingName) {
    let disposed = false;
    let enabled = false;
    let ready = false;
    let saving = false;
    let revision = 0;
    const row = document.createElement("label");
    row.className = `eze-popup-option ${cls}`;
    row.title = title;
    const toggle = document.createElement("input");
    toggle.type = "checkbox";
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", accessibleLabel);
    const text = document.createElement("span");
    text.textContent = label;
    row.append(toggle, text);
    const status = document.createElement("div");
    status.className = "eze-popup-preference-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      toggle.checked = enabled;
      toggle.disabled = !ready || saving;
    }
    function error(message) {
      status.textContent = message;
      status.hidden = false;
    }
    const changed = (changes, area) => {
      if (disposed || area !== "local" || !changes[key]) return;
      revision++;
      enabled = changes[key].newValue === true;
      render();
    };
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked;
      const writeRevision = ++revision;
      saving = true;
      status.hidden = true;
      render();
      try {
        await chrome.storage.local.set({ [key]: desired });
        if (revision === writeRevision) enabled = desired;
      } catch {
        if (!disposed) error(`Could not save the ${settingName} setting. Try again.`);
      } finally {
        saving = false;
        if (!disposed) render();
      }
    });
    chrome.storage.onChanged.addListener(changed);
    const initialRevision = revision;
    chrome.storage.local.get(key).then((data) => {
      if (!disposed && revision === initialRevision) enabled = data[key] === true;
      ready = true;
    }).catch(() => {
      if (!disposed)
        error(`Could not load the ${settingName} setting. Reopen this popup to retry.`);
    }).finally(() => {
      if (!disposed) render();
    });
    render();
    return {
      row,
      status,
      dispose() {
        disposed = true;
        chrome.storage.onChanged.removeListener(changed);
        row.remove();
        status.remove();
      }
    };
  }
  function mountPopupControls() {
    let disposed = false;
    const controls = [
      savedAnswersSwitch(),
      savedSwitch(
        PANEL_RESTORE_KEY,
        "Closed panel floating button",
        "Show closed panel floating button",
        "Show a small EZEapply button on webpages when the side panel is closed.",
        "eze-popup-floating",
        "floating button"
      ),
      savedSwitch(
        LINKEDIN_NOFOLLOW_KEY,
        "Turn off LinkedIn auto-follow",
        "Turn off LinkedIn auto-follow",
        "Automatically untick company-follow boxes in LinkedIn application dialogs. Existing follows and other checkboxes are unchanged.",
        "eze-popup-linkedin-follow",
        "LinkedIn auto-follow"
      )
    ];
    function decorate() {
      if (disposed) return;
      let previous = [...document.querySelectorAll("#root label")].find(
        (label) => /^Autofill (?:Enabled|Disabled)$/.test(label.textContent?.trim() || "")
      );
      if (!previous) return;
      for (const control of controls) {
        if (previous.nextElementSibling !== control.row) previous.after(control.row, control.status);
        previous = control.status;
      }
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        controls.forEach((control) => control.dispose());
      }
    };
  }

  // src/tracking-model.ts
  function localDayKey(date = /* @__PURE__ */ new Date()) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
  function validDay(day) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return false;
    const [year, month, date] = day.split("-").map(Number), parsed = new Date(year, month - 1, date);
    return year >= 1970 && localDayKey(parsed) === day;
  }

  // src/tracking-types.ts
  var TRACKING_CACHE_KEY = "eze.tracking.v1";
  var TRACKING_DAILY_TOTALS_KEY = "eze.tracking.dailyTotals.v1";

  // src/application-count.ts
  var localDay = localDayKey;
  function countAdjustments(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return {};
    return Object.fromEntries(
      Object.entries(value).filter(
        ([day, amount]) => validDay(day) && Number.isSafeInteger(amount) && Math.abs(amount) <= 99999
      )
    );
  }
  function applicationCount(appliedList, adjustments, now = /* @__PURE__ */ new Date()) {
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
    const detected = Array.isArray(appliedList) ? appliedList.filter((item) => {
      if (!item || typeof item !== "object" || typeof item.date !== "string") return false;
      const date = new Date(item.date).getTime();
      return date >= start && date < end;
    }).length : 0;
    return Math.max(0, detected + (countAdjustments(adjustments)[localDay(now)] || 0));
  }
  function mountApplicationCount() {
    let disposed = false, busy = false, ready = false, revision = 0, total = 0;
    const controls = document.createElement("span");
    controls.className = "eze-count-controls";
    controls.setAttribute("role", "group");
    controls.setAttribute("aria-label", "Adjust today\u2019s application count");
    const minus = document.createElement("button"), plus = document.createElement("button");
    for (const [button2, label, sign] of [
      [minus, "Decrease today\u2019s application count", "\u2212"],
      [plus, "Increase today\u2019s application count", "+"]
    ]) {
      button2.type = "button";
      button2.className = "eze-count-step";
      button2.textContent = sign;
      button2.setAttribute("aria-label", label);
      button2.title = label;
    }
    controls.append(minus, plus);
    const status = document.createElement("span");
    status.className = "eze-count-status";
    status.setAttribute("role", "status");
    status.hidden = true;
    function render() {
      minus.disabled = !ready || busy || total === 0;
      plus.disabled = !ready || busy;
      controls.title = `Today: ${total}. Correct missed or extra counts manually.`;
    }
    async function refresh() {
      const request = ++revision;
      try {
        const data = await chrome.storage.local.get([
          "appliedList",
          APPLICATION_COUNTS_KEY,
          TRACKING_DAILY_TOTALS_KEY
        ]);
        if (disposed || request !== revision) return;
        const cached = data[TRACKING_DAILY_TOTALS_KEY]?.[localDay()]?.total;
        total = typeof cached === "number" && Number.isSafeInteger(cached) && cached >= 0 ? cached : applicationCount(data.appliedList, data[APPLICATION_COUNTS_KEY]);
        ready = true;
        render();
      } catch {
        if (!disposed && request === revision) {
          ready = false;
          render();
          status.textContent = "Could not load the application count.";
          status.hidden = false;
        }
      }
    }
    async function adjust(delta) {
      busy = true;
      status.hidden = true;
      render();
      try {
        const result = await chrome.runtime.sendMessage({
          type: "eze-custom:adjust-count",
          delta,
          day: localDay()
        });
        if (!result?.ok) throw new Error(result?.error || "Could not update the count. Try again.");
        if (!disposed) {
          await refresh();
          status.textContent = `Today\u2019s application count: ${result.count}`;
          status.hidden = false;
        }
      } catch (error) {
        if (!disposed) {
          status.textContent = error instanceof Error ? error.message : "Could not update the count.";
          status.hidden = false;
        }
      } finally {
        busy = false;
        if (!disposed) render();
      }
    }
    minus.addEventListener("click", () => void adjust(-1));
    plus.addEventListener("click", () => void adjust(1));
    const changed = (changes, area) => {
      if (!disposed && area === "local" && (changes.appliedList || changes[APPLICATION_COUNTS_KEY] || changes[TRACKING_DAILY_TOTALS_KEY]))
        void refresh();
    };
    chrome.storage.onChanged.addListener(changed);
    const rollover = setInterval(() => void refresh(), 6e4);
    render();
    void refresh();
    function decorate() {
      if (disposed) return;
      const heading = [...document.querySelectorAll("#root h1")].find(
        (node2) => /\bapplications?\b.*\btoday\b/i.test(node2.textContent || "")
      );
      const chart = location.pathname.endsWith("/popup.html") ? document.querySelector("#root [data-chart]") : null;
      const anchor = heading || chart;
      if (!anchor) return;
      anchor.classList.add("eze-count-anchor");
      if (controls.parentElement !== anchor) anchor.append(controls);
      if (anchor.nextElementSibling !== status) anchor.after(status);
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        clearInterval(rollover);
        chrome.storage.onChanged.removeListener(changed);
        controls.remove();
        status.remove();
      }
    };
  }

  // src/activity-controls.ts
  function analyticsIcon() {
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS(ns, "path");
    path.setAttribute("d", "M3 3v18h18M6 15l4-5 4 3 6-8");
    svg.append(path);
    for (const [cx, cy] of [
      [6, 15],
      [10, 10],
      [14, 13],
      [20, 5]
    ]) {
      const circle = document.createElementNS(ns, "circle");
      circle.setAttribute("cx", String(cx));
      circle.setAttribute("cy", String(cy));
      circle.setAttribute("r", "1.4");
      circle.setAttribute("fill", "currentColor");
      svg.append(circle);
    }
    return svg;
  }
  function mountActivityControls() {
    let disposed = false, editor;
    const href = chrome.runtime.getURL("analytics.html");
    const shortcut = document.createElement("a");
    shortcut.href = href;
    shortcut.target = "_blank";
    shortcut.rel = "noopener";
    shortcut.title = "Analytics";
    shortcut.setAttribute("aria-label", "Open application analytics");
    shortcut.append(analyticsIcon());
    const nav = document.createElement("a");
    nav.href = href;
    nav.textContent = "Analytics";
    nav.dataset.ezeAnalytics = "true";
    const goal = document.createElement("button");
    goal.type = "button";
    goal.className = "eze-count-step eze-goal-edit";
    goal.title = "Edit daily goal";
    goal.setAttribute("aria-label", "Edit daily goal");
    const ns = "http://www.w3.org/2000/svg", pencil = document.createElementNS(ns, "svg"), path = document.createElementNS(ns, "path");
    pencil.setAttribute("viewBox", "0 0 24 24");
    pencil.setAttribute("fill", "none");
    pencil.setAttribute("stroke", "currentColor");
    pencil.setAttribute("stroke-width", "1.8");
    pencil.setAttribute("aria-hidden", "true");
    path.setAttribute("d", "m15 5 4 4M4 20l5-1L20 8a2.8 2.8 0 0 0-4-4L5 15l-1 5Z");
    pencil.append(path);
    goal.append(pencil);
    function openGoal() {
      if (editor) return;
      const dialog = document.createElement("dialog");
      editor = dialog;
      dialog.className = "eze-goal-dialog";
      dialog.setAttribute("aria-labelledby", "eze-goal-title");
      const form = document.createElement("form"), title = document.createElement("h2"), help = document.createElement("p");
      title.id = "eze-goal-title";
      title.textContent = "Your daily goal";
      help.textContent = "Set your target. Applications already counted stay counted.";
      const label = document.createElement("label");
      label.textContent = "Applications per day";
      const input = document.createElement("input");
      input.type = "number";
      input.min = "1";
      input.max = "10000";
      input.step = "1";
      input.required = true;
      input.value = "10";
      label.append(input);
      const error = document.createElement("p");
      error.className = "eze-goal-error";
      error.setAttribute("role", "alert");
      error.hidden = true;
      const actions = document.createElement("div");
      actions.className = "eze-goal-actions";
      const cancel = document.createElement("button"), save = document.createElement("button");
      cancel.type = "button";
      cancel.textContent = "Cancel";
      save.type = "submit";
      save.textContent = "Save goal";
      save.className = "eze-goal-save";
      actions.append(cancel, save);
      form.append(title, help, label, error, actions);
      dialog.append(form);
      document.body.append(dialog);
      let dirty = false;
      input.addEventListener("input", () => {
        dirty = true;
      });
      chrome.storage.local.get("dailyGoal").then((data) => {
        if (dialog.isConnected && !dirty && typeof data.dailyGoal === "number" && Number.isInteger(data.dailyGoal) && data.dailyGoal > 0)
          input.value = String(data.dailyGoal);
      }).catch(() => {
      });
      function close() {
        dialog.close?.();
        dialog.remove();
        editor = void 0;
        goal.focus();
      }
      cancel.addEventListener("click", close);
      dialog.addEventListener("cancel", (event) => {
        event.preventDefault();
        close();
      });
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const value = Number(input.value);
        error.hidden = true;
        if (!Number.isInteger(value) || value < 1 || value > 1e4) {
          error.textContent = "Choose a whole number from 1 to 10,000.";
          error.hidden = false;
          return;
        }
        save.disabled = true;
        try {
          const result = await chrome.runtime.sendMessage({
            type: "eze-tracking:set-goal",
            goal: value
          });
          if (!result?.ok) throw new Error(result?.error || "Could not save your goal. Try again.");
          if (dialog.isConnected) close();
        } catch (reason) {
          if (dialog.isConnected) {
            error.textContent = reason instanceof Error ? reason.message : "Could not save your goal.";
            error.hidden = false;
            save.disabled = false;
          }
        }
      });
      if (typeof dialog.showModal === "function") dialog.showModal();
      else dialog.setAttribute("open", "");
      input.focus();
      input.select();
    }
    goal.addEventListener("click", openGoal);
    function decorate() {
      if (disposed) return;
      const count = document.querySelector(".eze-count-controls");
      if (count && goal.parentElement !== count) count.append(goal);
      const applications = [...document.querySelectorAll("#root button")].find(
        (button2) => button2.title === "View Applications"
      );
      const shortcuts = applications?.parentElement;
      if (shortcuts && shortcut.parentElement !== shortcuts) {
        shortcut.className = `${applications.className} eze-analytics-shortcut`;
        shortcuts.append(shortcut);
      }
      const nativeNav = document.querySelector("#root .eze-native-nav-links");
      if (nativeNav && nav.parentElement !== nativeNav) nativeNav.append(nav);
    }
    decorate();
    return {
      decorate,
      dispose() {
        disposed = true;
        editor?.remove();
        goal.remove();
        shortcut.remove();
        nav.remove();
      }
    };
  }

  // src/ai-entry.ts
  function node(tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    if (text !== void 0) element.textContent = text;
    return element;
  }
  function aiPowerIcon() {
    const image = node("img", "eze-ai-logo");
    image.src = chrome.runtime.getURL("custom/ai-logo.png");
    image.alt = "";
    image.setAttribute("aria-hidden", "true");
    image.width = 64;
    image.height = 64;
    image.decoding = "async";
    return image;
  }
  function aiSideEntry(url) {
    const link2 = node("a", "eze-native-ai-link eze-native-ai-side");
    link2.href = url;
    link2.dataset.ezeAiLink = "true";
    const icon2 = node("span", "eze-ai-side-icon");
    icon2.append(aiPowerIcon());
    const copy = node("span", "eze-ai-side-copy");
    copy.append(
      node("strong", "", "AI providers & keys"),
      node("small", "", "Power up your applications")
    );
    link2.append(icon2, copy);
    return link2;
  }
  function aiSettingsHero(url) {
    const hero = node("section", "eze-ai-hero");
    hero.dataset.ezeAiHero = "true";
    hero.setAttribute("aria-labelledby", "eze-ai-hero-title");
    const icon2 = node("div", "eze-ai-power-icon");
    icon2.append(aiPowerIcon());
    const copy = node("div", "eze-ai-hero-copy");
    const title = node("h2", "", "Your application superpower");
    title.id = "eze-ai-hero-title";
    const providers = node("div", "eze-ai-provider-list");
    providers.setAttribute("aria-label", "Supported AI providers");
    for (const name of ["OpenAI", "Claude", "Gemini", "+ more"])
      providers.append(node("span", "", name));
    copy.append(
      node("span", "eze-ai-eyebrow", "EZEapply AI"),
      title,
      node("p", "", "Connect your AI provider. Choose your model. Draft answers in your own voice."),
      providers
    );
    const actions = node("div", "eze-ai-hero-actions");
    const link2 = node("a", "eze-ai-configure", "Configure AI");
    link2.href = url;
    const arrow = node("span", "", "\u2197");
    arrow.setAttribute("aria-hidden", "true");
    link2.append(arrow);
    actions.append(link2, node("span", "eze-ai-hero-hint", "Your keys. Your models."));
    hero.append(icon2, copy, actions);
    return hero;
  }

  // src/app-ui.ts
  function el(tag, cls = "", text = "") {
    const node2 = document.createElement(tag);
    node2.className = cls;
    node2.textContent = text;
    return node2;
  }
  function button(text, cls = "quiet-button") {
    const node2 = el("button", cls, text);
    node2.type = "button";
    return node2;
  }
  function link(text, path, cls = "") {
    const node2 = el("a", cls, text);
    node2.href = chrome.runtime.getURL(path);
    return node2;
  }
  function brand() {
    const img = el("img", "wordmark");
    img.src = chrome.runtime.getURL("custom/wordmark.svg");
    img.alt = "EZEapply";
    img.width = 236;
    img.height = 40;
    return img;
  }
  function icon(kind) {
    const node2 = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    for (const [key, value] of Object.entries({
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": "1.7",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "aria-hidden": "true"
    }))
      node2.setAttribute(key, value);
    const path = document.createElementNS(node2.namespaceURI, "path");
    path.setAttribute(
      "d",
      {
        applications: "M4 3v18h17M8 17v-5m5 5V7m5 10V9",
        profile: "M20 21v-2a7 7 0 0 0-14 0v2M17 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
        settings: "m9 3-1 3-3 1-2 3 2 2v3l2 3h3l2 3 3-1 1-3 3-1 1-3-2-2V9l-3-1-1-3-3-1-2 1ZM16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
        bolt: "m13 2-9 12h7l-1 8 10-12h-8l1-8Z"
      }[kind]
    );
    node2.append(path);
    return node2;
  }
  async function rpc(type, extra = {}) {
    const result = await chrome.runtime.sendMessage({ type, ...extra });
    if (!result?.ok) throw new Error(result?.error || "Could not save this change. Try again.");
    return result;
  }
  function errorText(reason) {
    return reason instanceof Error ? reason.message : "This action could not be completed. Try again.";
  }
  function statusNode() {
    const node2 = el("p", "app-status");
    node2.setAttribute("role", "status");
    node2.hidden = true;
    return node2;
  }
  function profileDate(value) {
    if (typeof value === "string") return value;
    const date = record(value), year = String(date.year ?? ""), month = String(date.month ?? "");
    return /^\d{4}$/.test(year) && /^(?:[1-9]|1[0-2])$/.test(month) ? `${year}-${month.padStart(2, "0")}` : "";
  }
  function showStatus(node2, text, error = false) {
    node2.textContent = text;
    node2.hidden = !text;
    node2.classList.toggle("error", error);
  }
  function safeWebsite(value) {
    try {
      const url = new URL(value);
      return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.href : "";
    } catch {
      return "";
    }
  }
  function downloadFile(name, blob) {
    const url = URL.createObjectURL(blob), anchor = el("a");
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function resumeFromFile(file) {
    if (!file.size || file.size > 20 * 1024 * 1024)
      throw new Error("Choose a nonempty resume smaller than 20 MB.");
    if (!/\.(pdf|doc|docx|txt|rtf|odt)$/i.test(file.name))
      throw new Error("Choose a PDF, DOC, DOCX, text, RTF or ODT resume.");
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    for (let i = 0; i < bytes.length; i += 16384)
      binary += String.fromCharCode(...bytes.subarray(i, i + 16384));
    return normalizeProfile({
      resumeData: {
        fileName: file.name,
        resumeBase64: btoa(binary),
        fileSize: file.size / 1024,
        dateUploaded: (/* @__PURE__ */ new Date()).toISOString()
      }
    }).resumeData;
  }
  function resumeDownload(saved) {
    const raw = string(saved.resumeBase64).replace(/^data:[^,]+,/, ""), bytes = Uint8Array.from(atob(raw), (c) => c.charCodeAt(0));
    downloadFile(string(saved.fileName), new Blob([bytes]));
  }
  function masterSwitch(initial) {
    const row = el("label", "master-switch"), toggle = el("input"), caption = el("span", "", `Autofill ${initial ? "Enabled" : "Disabled"}`), status = statusNode();
    toggle.type = "checkbox";
    toggle.checked = initial;
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-label", "Enable autofill");
    toggle.addEventListener("change", async () => {
      const desired = toggle.checked;
      toggle.disabled = true;
      try {
        await rpc("eze-app:autofill", { enabled: desired });
        caption.textContent = `Autofill ${desired ? "Enabled" : "Disabled"}`;
        showStatus(status, "");
      } catch (error) {
        toggle.checked = !desired;
        showStatus(status, errorText(error), true);
      } finally {
        toggle.disabled = false;
      }
    });
    row.append(toggle, caption);
    const block = el("div", "master-control");
    block.append(row, status);
    return block;
  }
  function copyValue(label, value) {
    const row = el("div", "profile-value"), key = el("span", "", label), answer = button(value || "Not set", "copy-value");
    answer.disabled = !value;
    answer.title = `Copy ${label}`;
    answer.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(value);
        answer.textContent = "Copied";
        setTimeout(() => {
          answer.textContent = value;
        }, 1e3);
      } catch {
        answer.textContent = "Copy failed";
        setTimeout(() => {
          answer.textContent = value;
        }, 1500);
      }
    });
    row.append(key, answer);
    return row;
  }
  function profileCards(profile) {
    const stack = el("div", "profile-cards");
    const personal = el("section", "card");
    personal.append(el("h2", "", "Personal details"));
    const names = profile.nameData, contact = profile.contactData, address = profile.addressData;
    for (const [label, value] of [
      ["Legal name", [names.firstName, names.middleName, names.lastName].filter(Boolean).join(" ")],
      ["Email", string(contact.email)],
      ["Phone", string(contact.phoneNumber)],
      [
        "Address",
        [
          address.line1,
          address.line2,
          address.city,
          address.state,
          address.postalCode,
          address.country
        ].filter(Boolean).join(", ")
      ]
    ])
      personal.append(copyValue(label, value));
    stack.append(personal);
    for (const [title, items, primary, secondary] of [
      ["Work history", profile.jobData, "jobTitle", "company"],
      ["Education", profile.educationData, "school", "degree"]
    ]) {
      const section = el("section", "card");
      section.append(el("h2", "", title));
      if (!items.length) section.append(el("p", "muted", "Add this in your profile."));
      for (const item of items) {
        const entry = el("div", "history-summary");
        entry.append(copyValue(string(item[primary]) || title, string(item[secondary])));
        if (string(item.description)) entry.append(copyValue("Details", string(item.description)));
        section.append(entry);
      }
      stack.append(section);
    }
    const portfolio = el("section", "card");
    portfolio.append(el("h2", "", "Portfolio"));
    if (string(profile.resumeData.fileName)) {
      const resume = button(`\u2193 ${string(profile.resumeData.fileName)}`);
      resume.addEventListener("click", () => resumeDownload(profile.resumeData));
      portfolio.append(resume);
    }
    for (const [key, value] of Object.entries(profile.websiteData)) {
      if (typeof value === "string" && value)
        portfolio.append(copyValue(key === "personal" ? "Website" : key, value));
      if (key === "websites" && Array.isArray(value)) {
        for (const website of value)
          if (typeof website === "string") portfolio.append(copyValue("Website", website));
      }
    }
    if (profile.skillsData.length)
      portfolio.append(copyValue("Skills", profile.skillsData.join(", ")));
    stack.append(portfolio);
    if (profile.languageData.length) {
      const languages = el("section", "card");
      languages.append(el("h2", "", "Languages"));
      for (const item of profile.languageData)
        languages.append(copyValue(string(item.language), string(item.proficiency)));
      stack.append(languages);
    }
    const employment = el("section", "card");
    employment.append(el("h2", "", "Employment information"));
    for (const [key, value] of Object.entries(profile.employmentData))
      if (typeof value === "string" || typeof value === "boolean")
        employment.append(copyValue(key.replace(/([a-z])([A-Z])/g, "$1 $2"), String(value)));
    stack.append(employment);
    return stack;
  }
  function ring() {
    const chart = el("div", "daily-ring");
    chart.dataset.chart = "today";
    const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 240 240");
    svg.setAttribute("aria-hidden", "true");
    for (const cls of ["ring-track", "ring-value"]) {
      const circle = document.createElementNS(ns, "circle");
      for (const [key, value] of Object.entries({
        cx: "120",
        cy: "120",
        r: "105",
        fill: "none",
        class: cls
      }))
        circle.setAttribute(key, value);
      svg.append(circle);
    }
    const text = el("div", "ring-text");
    text.append(
      el("strong", "daily-total", "0"),
      el("span", "", "Applications Today"),
      el("small", "daily-goal", "Goal: 10")
    );
    chart.append(svg, text);
    return chart;
  }
  async function mountApp(root) {
    let disposed = false, view = 0;
    const path = location.pathname, popup = path.endsWith("/popup.html"), side = path.endsWith("/sidepanel.html");
    const cleanup = [];
    let settings = await chrome.storage.local.get([
      "profile",
      "autofillEnabled",
      "dailyGoal",
      TRACKING_DAILY_TOTALS_KEY,
      "appliedList",
      APPLICATION_COUNTS_KEY
    ]);
    if (disposed) return () => {
    };
    function counts() {
      const cached = record(record(settings[TRACKING_DAILY_TOTALS_KEY])[localDayKey()]).total;
      return typeof cached === "number" && Number.isSafeInteger(cached) && cached >= 0 ? cached : applicationCount(settings.appliedList, settings[APPLICATION_COUNTS_KEY]);
    }
    function paintCount() {
      const total = counts(), goal = typeof settings.dailyGoal === "number" && settings.dailyGoal > 0 ? settings.dailyGoal : 10;
      for (const node2 of root.querySelectorAll(".daily-total")) node2.textContent = String(total);
      for (const node2 of root.querySelectorAll(".daily-goal")) node2.textContent = `Goal: ${goal}`;
      const circle = root.querySelector(".ring-value");
      if (circle instanceof SVGElement) {
        circle.style.strokeDasharray = `${Math.min(1, total / goal) * 660} 660`;
        circle.style.opacity = total > 0 ? "1" : "0";
      }
      const bar = root.querySelector(".daily-progress-value");
      if (bar) bar.style.width = `${Math.min(100, total / goal * 100)}%`;
    }
    if (popup) {
      const windowId = (await chrome.windows.getCurrent()).id;
      document.body.classList.add("popup-page");
      root.append(brand(), ring());
      const shortcuts = el("div", "popup-shortcuts");
      for (const [title, target, kind] of [
        ["View Applications", "options.html#/", "applications"],
        ["Manage Profile", "options.html#/profile", "profile"],
        ["Manage Settings", "options.html#/settings/autofill", "settings"]
      ]) {
        const control = button("", "round-shortcut");
        control.title = title;
        control.setAttribute("aria-label", title);
        control.append(icon(kind));
        control.addEventListener("click", () => {
          void chrome.tabs.create({ url: chrome.runtime.getURL(target) });
        });
        shortcuts.append(control);
      }
      root.append(shortcuts);
      const quick = button("Quick Access", "quick-access");
      quick.prepend(icon("bolt"));
      const status = statusNode();
      quick.addEventListener("click", () => {
        if (windowId === void 0) {
          showStatus(status, "No active Chrome window.", true);
          return;
        }
        void chrome.sidePanel.open({ windowId }).then(
          () => window.close(),
          (error) => showStatus(status, errorText(error), true)
        );
      });
      root.append(quick, status);
      const switches = el("div", "popup-switches"), master = masterSwitch(settings.autofillEnabled !== false);
      switches.append(...master.childNodes);
      root.append(switches);
      const preferences = mountPopupControls();
      cleanup.push(() => preferences.dispose());
    } else if (side) {
      document.body.classList.add("sidepanel-page");
      const summary = el("section", "side-summary"), heading = el("h1");
      heading.append(
        el("strong", "daily-total", "0"),
        document.createTextNode(" Applications "),
        el("small", "", "today")
      );
      const progress = el("div", "daily-progress");
      progress.append(el("span", "daily-progress-value"));
      summary.append(heading, el("p", "daily-goal", "Goal: 10"), progress);
      root.append(summary);
      const shortcuts = el("div", "side-links");
      shortcuts.append(
        link("Edit profile", "options.html#/profile"),
        link("Applications", "options.html#/"),
        link("Analytics", "analytics.html")
      );
      for (const anchor of shortcuts.querySelectorAll("a")) anchor.target = "_blank";
      root.append(shortcuts, profileCards(normalizeProfile(settings.profile)));
    } else {
      document.body.classList.add("options-page");
      const header = el("header", "app-header"), home = link("", "options.html#/");
      home.append(brand());
      const nav = el("nav", "app-nav");
      nav.setAttribute("aria-label", "Main navigation");
      for (const [title, hash] of [
        ["Applications", "#/"],
        ["Profile", "#/profile"],
        ["Settings", "#/settings/autofill"]
      ]) {
        const anchor = el("a", "", title);
        anchor.href = hash;
        nav.append(anchor);
      }
      nav.append(link("Analytics", "analytics.html"));
      const ai = link("AI settings", "ai-settings.html", "nav-ai");
      ai.prepend(aiPowerIcon());
      nav.append(ai);
      header.append(home, nav);
      const main = el("main", "app-main"), footer = el(
        "footer",
        "app-footer",
        `Created by Piyush Agarwal \xB7 EZEapply ${chrome.runtime.getManifest().version}`
      );
      root.append(header, main, footer);
      const render = async () => {
        const revision = ++view;
        try {
          settings = {
            ...settings,
            ...await chrome.storage.local.get(["profile", "autofillEnabled", "dailyGoal"])
          };
          if (disposed || revision !== view) return;
          const hash = location.hash;
          for (const anchor of nav.querySelectorAll("a")) {
            const selected = anchor.getAttribute("href") === (hash || "#/");
            anchor.classList.toggle("active", selected);
            if (selected) anchor.setAttribute("aria-current", "page");
            else anchor.removeAttribute("aria-current");
          }
          main.replaceChildren();
          if (hash.startsWith("#/profile")) renderProfile(main, normalizeProfile(settings.profile));
          else if (hash.startsWith("#/settings")) {
            const section = el("div", "settings-layout"), aside = el("aside");
            aside.append(aiSideEntry(chrome.runtime.getURL("ai-settings.html")));
            const card = el("section", "card");
            card.append(
              el("h2", "", "Autofill"),
              masterSwitch(settings.autofillEnabled !== false),
              el(
                "p",
                "muted",
                "Saved answers fill empty application fields. Your edits are kept. Choose automatic filling in the toolbar popup."
              ),
              link("Open reusable answers", "custom-fields.html", "text-link"),
              link("Edit goal & view progress", "analytics.html", "text-link")
            );
            section.append(aside, card);
            main.append(
              el("h1", "", "Settings"),
              aiSettingsHero(chrome.runtime.getURL("ai-settings.html")),
              section
            );
          } else {
            await renderApplications(main, () => !disposed && revision === view);
          }
        } catch (error) {
          if (revision === view) {
            main.replaceChildren(
              el("h1", "", "Could not load this page"),
              el("p", "error", errorText(error))
            );
          }
        }
      };
      const changed = () => {
        void render();
      };
      window.addEventListener("hashchange", changed);
      cleanup.push(() => window.removeEventListener("hashchange", changed));
      await render();
      const refreshHistory = (changes, area) => {
        if (area === "local" && changes[TRACKING_CACHE_KEY] && !location.hash.startsWith("#/profile") && !location.hash.startsWith("#/settings"))
          void render();
      };
      chrome.storage.onChanged.addListener(refreshHistory);
      cleanup.push(() => chrome.storage.onChanged.removeListener(refreshHistory));
    }
    if (popup || side) {
      paintCount();
      const count = mountApplicationCount(), activity = mountActivityControls();
      cleanup.push(
        () => count.dispose(),
        () => activity.dispose()
      );
      const changed = (changes, area) => {
        if (area !== "local") return;
        for (const [key, value] of Object.entries(changes)) settings[key] = value.newValue;
        paintCount();
      };
      chrome.storage.onChanged.addListener(changed);
      const timer = setInterval(paintCount, 6e4);
      cleanup.push(
        () => chrome.storage.onChanged.removeListener(changed),
        () => clearInterval(timer)
      );
    }
    return () => {
      disposed = true;
      view++;
      cleanup.forEach((fn) => fn());
      root.replaceChildren();
    };
  }
  async function renderApplications(main, current) {
    const result = await rpc("eze-tracking:snapshot"), snapshot = result.snapshot;
    const data = await chrome.storage.local.get("eze.applicationStages.v1");
    if (!current()) return;
    const stages = record(data["eze.applicationStages.v1"]), heading = el("div", "page-heading");
    heading.append(
      el("h1", "", "Applications"),
      link("View analytics \u2197", "analytics.html", "quiet-button")
    );
    const controls = el("div", "application-filters"), search = el("input"), source = el("select"), stage = el("select");
    search.type = "search";
    search.placeholder = "Search applications\u2026";
    search.setAttribute("aria-label", "Search applications");
    for (const [value, text] of [
      ["", "All sources"],
      ["linkedin", "LinkedIn Easy Apply"],
      ["external", "External forms"],
      ["unknown", "Imported / unclassified"]
    ]) {
      const option = el("option", "", text);
      option.value = value;
      source.append(option);
    }
    source.setAttribute("aria-label", "Application source");
    for (const value of ["Any stage", "Applied", "Interview", "Offer", "Rejected"])
      stage.append(el("option", "", value));
    stage.setAttribute("aria-label", "Application stage");
    controls.append(search, source, stage);
    const status = statusNode(), container = el("div", "application-list"), note = el(
      "p",
      "muted",
      "Confirmed submissions are captured automatically. Correct missed counts with \u2212 / + in the popup."
    );
    const pages = el("nav", "journal-pages"), range = el("span", "muted"), previous = button("\u2190 Previous"), next = button("Next \u2192");
    pages.setAttribute("aria-label", "Application journal pages");
    pages.append(range, previous, next);
    let page = 0;
    previous.addEventListener("click", () => {
      page = Math.max(0, page - 1);
      draw();
    });
    next.addEventListener("click", () => {
      page++;
      draw();
    });
    main.append(heading, note, controls, status, container, pages);
    function draw() {
      container.replaceChildren();
      const matches = snapshot.records.filter(
        (item) => `${item.jobTitle} ${item.company}`.toLowerCase().includes(search.value.toLowerCase()) && (!source.value || item.source === source.value) && (stage.value === "Any stage" || (stages[item.id] || "Applied") === stage.value)
      ).sort((a, b) => Date.parse(b.submittedAt) - Date.parse(a.submittedAt));
      page = Math.min(page, Math.max(0, Math.ceil(matches.length / 50) - 1));
      pages.hidden = matches.length === 0;
      previous.disabled = page === 0;
      next.disabled = (page + 1) * 50 >= matches.length;
      range.textContent = `${page * 50 + 1}\u2013${Math.min(matches.length, (page + 1) * 50)} of ${matches.length}`;
      if (!matches.length) {
        const empty = el("section", "card empty-state");
        empty.append(
          icon("applications"),
          el("h2", "", "Your next opportunity starts here"),
          el(
            "p",
            "muted",
            snapshot.records.length ? "No applications match these filters." : "Confirmed applications will appear here. Open a job form and use EZEapply to get started."
          )
        );
        container.append(empty);
        return;
      }
      const table = el("table"), head = el("thead"), row = el("tr");
      for (const title of ["Job & company", "Source", "Stage", "Applied"])
        row.append(el("th", "", title));
      head.append(row);
      table.append(head);
      const body = el("tbody");
      for (const item of matches.slice(page * 50, (page + 1) * 50)) {
        const row2 = el("tr"), job = el("td"), url = safeWebsite(item.url), title = url ? el("a", "job-title", item.jobTitle || "Application") : el("strong", "job-title", item.jobTitle || "Application");
        if (title instanceof HTMLAnchorElement) {
          title.href = url;
          title.target = "_blank";
          title.rel = "noopener noreferrer";
        }
        job.append(title, el("small", "muted", item.company || "Company not captured"));
        const src = el("td");
        src.append(
          el(
            "span",
            `source-chip ${item.source}`,
            item.source === "linkedin" ? "LinkedIn" : item.source === "external" ? "External form" : "Imported"
          )
        );
        const progress = el("td"), select = el("select");
        select.setAttribute("aria-label", `Stage for ${item.jobTitle || "application"}`);
        for (const value of ["Applied", "Interview", "Offer", "Rejected"])
          select.append(el("option", "", value));
        select.value = string(stages[item.id]) || "Applied";
        select.addEventListener("change", async () => {
          const desired = select.value;
          select.disabled = true;
          try {
            await rpc("eze-app:stage", { id: item.id, stage: desired });
            stages[item.id] = desired;
            showStatus(status, "Stage saved.");
          } catch (error) {
            select.value = string(stages[item.id]) || "Applied";
            showStatus(status, errorText(error), true);
          } finally {
            select.disabled = false;
          }
        });
        progress.append(select);
        row2.append(
          job,
          src,
          progress,
          el(
            "td",
            "muted",
            new Date(item.submittedAt).toLocaleDateString(void 0, {
              day: "numeric",
              month: "short",
              year: "numeric"
            })
          )
        );
        body.append(row2);
      }
      table.append(body);
      container.append(table);
    }
    const filter = () => {
      page = 0;
      draw();
    };
    search.addEventListener("input", filter);
    source.addEventListener("change", filter);
    stage.addEventListener("change", filter);
    draw();
  }
  function renderProfile(main, profile) {
    const heading = el("div", "page-heading"), tools = el("div", "toolbar"), exportButton = button("Export"), importButton = button("Import"), picker = el("input");
    picker.type = "file";
    picker.accept = ".json,application/json";
    picker.hidden = true;
    heading.append(el("h1", "", "Profile"), tools);
    tools.append(importButton, exportButton, picker);
    const form = el("form", "profile-form"), status = statusNode();
    main.append(
      heading,
      el(
        "p",
        "muted",
        "Your profile stays on this device. Saved answers and AI use these facts when enabled."
      ),
      status,
      form
    );
    const sync = [];
    let busy = false, dirty = false;
    const save = el("button", "primary-button", "Save profile");
    save.type = "submit";
    form.addEventListener("input", () => {
      dirty = true;
      showStatus(status, "Unsaved changes");
    });
    function field(parent, label, obj, key, type = "text") {
      const wrapper = el("label", "form-field");
      wrapper.append(el("span", "", label));
      const input = type === "textarea" ? el("textarea") : el("input");
      if (input instanceof HTMLInputElement) input.type = type;
      const original = obj[key];
      input.value = typeof original === "boolean" ? original ? "Yes" : "No" : typeof original === "number" ? String(original) : string(original);
      if (key === "startDate" || key === "endDate") input.value = profileDate(original);
      let initial = input.value;
      if (input instanceof HTMLTextAreaElement) input.rows = 3;
      input.maxLength = 3e4;
      wrapper.append(input);
      sync.push(() => {
        if (input.value !== initial) {
          const value = input.value.trim();
          obj[key] = typeof original === "boolean" && /^(yes|no)$/i.test(value) ? value.toLowerCase() === "yes" : value;
          initial = input.value;
        }
      });
      parent.append(wrapper);
    }
    function section(title) {
      const section2 = el("section", "card profile-section");
      section2.append(el("h2", "", title));
      const grid2 = el("div", "form-grid");
      section2.append(grid2);
      form.append(section2);
      return grid2;
    }
    let grid = section("Personal details");
    field(grid, "Profile name", profile, "profileName");
    for (const [label, key] of [
      ["First name", "firstName"],
      ["Middle name", "middleName"],
      ["Last name", "lastName"]
    ])
      field(grid, label, profile.nameData, key);
    grid = section("Contact & address");
    for (const [label, key, type] of [
      ["Email", "email", "email"],
      ["Phone number (include country code)", "phoneNumber", "tel"]
    ])
      field(grid, label, profile.contactData, key, type);
    for (const [label, key] of [
      ["Address line 1", "line1"],
      ["Address line 2", "line2"],
      ["City", "city"],
      ["State / province", "state"],
      ["Postal code", "postalCode"],
      ["Country", "country"]
    ])
      field(grid, label, profile.addressData, key);
    grid = section("Portfolio");
    for (const [label, key] of [
      ["LinkedIn", "linkedin"],
      ["GitHub", "github"],
      ["Personal website", "personal"]
    ])
      field(grid, label, profile.websiteData, key, "url");
    const extra = {
      websites: Array.isArray(profile.websiteData.websites) ? profile.websiteData.websites.filter((v) => typeof v === "string").join("\n") : ""
    }, skills = { skills: profile.skillsData.join(", ") };
    field(grid, "Other links (one per line)", extra, "websites", "textarea");
    field(grid, "Skills (comma separated)", skills, "skills");
    sync.push(() => {
      profile.websiteData.websites = extra.websites.split("\n").map((v) => v.trim()).filter(Boolean);
      profile.skillsData = skills.skills.split(",").map((v) => v.trim()).filter(Boolean);
    });
    const resume = el("div", "resume-editor"), resumeName = el("span", "muted", string(profile.resumeData.fileName) || "No resume saved"), resumePicker = el("input"), replace = button("Choose resume"), download = button("Download"), remove = button("Remove resume");
    resumePicker.type = "file";
    resumePicker.accept = ".pdf,.doc,.docx,.txt,.rtf,.odt";
    resumePicker.hidden = true;
    download.disabled = remove.disabled = !string(profile.resumeData.resumeBase64);
    replace.addEventListener("click", () => resumePicker.click());
    download.addEventListener("click", () => resumeDownload(profile.resumeData));
    remove.addEventListener("click", () => {
      if (confirm("Remove the saved resume? Save profile to keep this change.")) {
        profile.resumeData = {};
        resumeName.textContent = "No resume saved";
        download.disabled = remove.disabled = true;
        dirty = true;
        showStatus(status, "Unsaved changes");
      }
    });
    resumePicker.addEventListener("change", async () => {
      const file = resumePicker.files?.[0];
      if (!file) return;
      busy = true;
      save.disabled = replace.disabled = true;
      try {
        profile.resumeData = await resumeFromFile(file);
        resumeName.textContent = string(profile.resumeData.fileName);
        download.disabled = remove.disabled = false;
        dirty = true;
        showStatus(status, "Resume ready. Save profile to keep it.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        save.disabled = replace.disabled = false;
        resumePicker.value = "";
      }
    });
    resume.append(resumeName, replace, download, remove, resumePicker);
    grid.parentElement?.append(resume);
    function history(title, key, columns, flag) {
      const section2 = el("section", "card profile-section"), titleRow = el("div", "page-heading"), add = button("+ Add");
      titleRow.append(el("h2", "", title), add);
      const entries = el("div", "history-entries");
      section2.append(titleRow, entries);
      form.append(section2);
      function entry(item) {
        const box = el("fieldset", "history-editor"), grid2 = el("div", "form-grid"), deleteEntry = button("Remove entry", "danger-button");
        for (const [label, key2, type] of columns) field(grid2, label, item, key2, type);
        if (flag) {
          const row = el("label", "check-field"), input = el("input");
          input.type = "checkbox";
          input.checked = item[flag[1]] === true;
          row.append(input, document.createTextNode(flag[0]));
          grid2.append(row);
          sync.push(() => {
            item[flag[1]] = input.checked;
          });
        }
        deleteEntry.addEventListener("click", () => {
          if (confirm("Remove this entry? Save profile to keep this change.")) {
            profile[key] = profile[key].filter((value) => value !== item);
            box.remove();
            dirty = true;
            showStatus(status, "Unsaved changes");
          }
        });
        box.append(grid2, deleteEntry);
        entries.append(box);
      }
      profile[key].forEach(entry);
      add.addEventListener("click", () => {
        if (profile[key].length >= 100) {
          showStatus(status, "This section is limited to 100 entries.", true);
          return;
        }
        const item = {};
        profile[key].push(item);
        entry(item);
        dirty = true;
        entries.lastElementChild?.querySelector("input")?.focus();
      });
    }
    history(
      "Work history",
      "jobData",
      [
        ["Job title", "jobTitle"],
        ["Company", "company"],
        ["Location", "location"],
        ["Start date", "startDate"],
        ["End date", "endDate"],
        ["Description", "description", "textarea"]
      ],
      ["I currently work here", "currentlyWorkHere"]
    );
    history("Education", "educationData", [
      ["School / institution", "school"],
      ["Degree", "degree"],
      ["Field of study", "fieldOfStudy"],
      ["Start date", "startDate"],
      ["End date", "endDate"]
    ]);
    history("Languages", "languageData", [
      ["Language", "language"],
      ["Proficiency", "proficiency"]
    ]);
    grid = section("Employment information");
    for (const [label, key] of [
      ["Authorized to work in country of residence", "eligibilityUS"],
      ["Visa sponsorship", "sponsorship"],
      ["Gender", "gender"],
      ["Ethnicity", "ethnicity"],
      ["Veteran status", "veteranStatus"],
      ["Disability", "disability"],
      ["Age", "age"]
    ])
      field(grid, label, profile.employmentData, key);
    form.append(save);
    const collect = () => {
      sync.forEach((fn) => fn());
      return normalizeProfile(profile);
    };
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (busy) return;
      busy = true;
      save.disabled = true;
      try {
        await rpc("eze-app:save-profile", { profile: collect() });
        dirty = false;
        showStatus(status, "Profile saved.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        save.disabled = false;
      }
    });
    exportButton.addEventListener("click", () => {
      try {
        downloadFile(
          "EZEapply-profile.json",
          new Blob([JSON.stringify({ version: 1, profile: collect() }, null, 2)], {
            type: "application/json"
          })
        );
      } catch (error) {
        showStatus(status, errorText(error), true);
      }
    });
    importButton.addEventListener("click", () => picker.click());
    picker.addEventListener("change", async () => {
      const file = picker.files?.[0];
      if (!file || busy) return;
      try {
        if (file.size > 32e6) throw new Error("Choose a profile export smaller than 32 MB.");
        const imported = parseProfileImport(await file.text());
        if (dirty && !confirm("Replace your unsaved profile edits with this import?")) return;
        if (!confirm(
          "Replace your saved profile with this imported profile? Reusable answers and API keys stay unchanged."
        ))
          return;
        busy = true;
        importButton.disabled = true;
        await rpc("eze-app:save-profile", { profile: imported });
        main.replaceChildren();
        renderProfile(main, imported);
        const next = main.querySelector(".app-status");
        if (next) showStatus(next, "Profile imported.");
      } catch (error) {
        showStatus(status, errorText(error), true);
      } finally {
        busy = false;
        importButton.disabled = false;
        picker.value = "";
      }
    });
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.id && typeof document !== "undefined") {
    const root = document.getElementById("root");
    if (root)
      void mountApp(root).catch((error) => {
        root.replaceChildren(el("p", "error", errorText(error)));
      });
  }
})();
