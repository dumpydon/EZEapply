"use strict";
(() => {
  // src/form-labels.ts
  var CONTROL_SELECTOR = 'input,textarea,select,[role="combobox"],[contenteditable="true"][role="textbox"],[contenteditable=""]';
  var FIELD_CONTAINER = '[data-automation-id="formField"], [data-automation-id^="formField-"], .form-group, .form-field, .field, .application-question, .jobs-easy-apply-form-element, .fb-dash-form-element, [data-testid="field"], [role="group"], [role="listitem"]';
  function isGenericPrompt(value) {
    const text5 = value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    return !text5 || /^(?:(?:please )?(?:enter|type|write|add|provide|input)(?: your| the| an)?(?: answer| response| text| information)?(?: here)?|your answer|your response|answer(?: here)?|response|text|textbox|text field|short answer(?: text)?|long answer(?: text)?|search and select|select an option)$/.test(
      text5
    );
  }
  function parentOf(element) {
    return element.parentElement || element.getRootNode().host || null;
  }
  function reference(element, id2) {
    let scope = element.getRootNode();
    while (true) {
      const found = scope.getElementById(id2);
      if (found) return found;
      if (!("host" in scope)) return null;
      scope = scope.host.getRootNode();
    }
  }
  function controlsWithin(container) {
    let count = [...container.querySelectorAll(CONTROL_SELECTOR)].filter(
      (control) => control.getAttribute("type") !== "hidden" && !control.closest('[role="listbox"]') && (!control.closest('[role="combobox"]') || control.closest('[role="combobox"]') === control)
    ).length;
    if (count > 1) return count;
    for (const child of container.querySelectorAll("*"))
      if (child.shadowRoot) {
        count += controlsWithin(child.shadowRoot);
        if (count > 1) break;
      }
    return count;
  }
  function clean(element) {
    if (!element) return "";
    const copy = element.cloneNode(true);
    copy.querySelectorAll(`${CONTROL_SELECTOR},button,[role="option"],script,style`).forEach((node) => node.remove());
    return copy.textContent?.replace(/\s+/g, " ").trim().slice(0, 500) || "";
  }
  function ariaLabel(element) {
    return (element.getAttribute("aria-labelledby") || "").split(/\s+/).filter(Boolean).map((id2) => clean(reference(element, id2))).filter(Boolean).join(" ");
  }
  function fieldInstructions(element) {
    return [
      ...new Set(
        (element.getAttribute("aria-describedby") || "").split(/\s+/).filter(Boolean).map((id2) => clean(reference(element, id2))).filter(Boolean)
      )
    ].join("\n").slice(0, 1500);
  }
  function humanLabels(element) {
    const labels = [ariaLabel(element), element.getAttribute("aria-label") || ""];
    if ("labels" in element)
      labels.push(...[...element.labels || []].map(clean));
    if (!labels.some((label) => !isGenericPrompt(label))) {
      let node = element;
      for (let depth = 0; depth < 9; depth++) {
        const sibling = node.previousElementSibling;
        if (sibling?.matches('label,[class*="label"],[class*="question"],legend') && !sibling.querySelector(CONTROL_SELECTOR))
          labels.push(clean(sibling));
        const parent3 = parentOf(node);
        if (!parent3 || parent3.matches("form,body,main,section,html") || controlsWithin(parent3) > 1)
          break;
        if (parent3.matches(FIELD_CONTAINER)) {
          const label = parent3.querySelector(
            'label,[class*="label"],[class*="question"],legend,[role="heading"],h2,h3'
          );
          if (label && !label.contains(element)) labels.push(clean(label));
        }
        if (labels.some((label) => !isGenericPrompt(label))) break;
        node = parent3;
      }
    }
    labels.push(
      element.getAttribute("placeholder") || "",
      element.getAttribute("data-placeholder") || ""
    );
    return [...new Set(labels.filter((label) => !isGenericPrompt(label)))];
  }
  function fieldQuestion(element) {
    return humanLabels(element)[0] || "";
  }
  function fieldLabels(element) {
    const human = humanLabels(element);
    const attributes = ["name", "id", "data-automation-id", "data-testid"].map(
      (name) => element.getAttribute(name) || ""
    );
    return [...new Set([...human, ...attributes].filter(Boolean))];
  }
  function autocompleteToken(element) {
    const tokens = (element.getAttribute("autocomplete") || "").toLowerCase().split(/\s+/).filter(Boolean);
    return tokens.filter(
      (token) => !token.startsWith("section-") && !["shipping", "billing", "home", "work", "mobile", "fax", "pager", "webauthn"].includes(
        token
      )
    ).at(-1);
  }
  function fieldContext(element) {
    let group = element;
    while (group && !group.matches('fieldset,[role="group"],[role="radiogroup"]'))
      group = parentOf(group);
    if (!group) return "";
    return [
      ariaLabel(group),
      group.getAttribute("aria-label"),
      clean(group.querySelector(":scope > legend,:scope > h2,:scope > h3"))
    ].filter(Boolean).join(" ");
  }

  // src/ai/generation.ts
  function fits(answer, maxLength, maxWords) {
    return answer.length <= maxLength && (!maxWords || answer.trim().split(/\s+/).filter(Boolean).length <= maxWords);
  }

  // src/ai/field-ui.ts
  var css = `
:host{all:initial!important;font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;color:#edf8f5!important}
*{box-sizing:border-box}[hidden]{display:none!important}button,input,textarea{font:inherit}button{cursor:pointer}button:disabled{opacity:.5;cursor:default}button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid #61d4be;outline-offset:2px}
.pill{position:fixed;z-index:2147483646;display:flex;align-items:center;justify-content:center;gap:4px;border:1px solid #38978377;background:#effffb;color:#146a58;padding:3px 7px;height:24px;min-height:0;border-radius:7px;box-shadow:0 2px 6px #0002;font:600 11px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;white-space:nowrap}.pill:hover{background:#dcf7ef}.pill[hidden]{display:none}.ai-logo{display:block;width:14px;height:14px;flex:none;object-fit:contain}.dialog-logo{width:22px;height:22px}
dialog{background:#25342f;color:#edf8f5;border:1px solid #526a61;border-radius:16px;padding:16px;width:min(460px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;box-shadow:0 18px 80px #0008;margin:auto}dialog::backdrop{background:#0b151bc4;backdrop-filter:blur(3px)}
header,.actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}h2{margin:0;font-size:18px;flex:1}p{margin:10px 0}label{display:block;margin:12px 0 5px;font-weight:600}textarea{display:block;width:100%;resize:vertical;background:#18251f;color:#f0f8f4;border:1px solid #527569;border-radius:9px;padding:10px;min-height:80px}textarea.answer{min-height:130px}
button{border:1px solid #66827680;background:#ffffff0b;color:inherit;border-radius:8px;padding:7px 10px}button:hover{background:#ffffff14}.primary{background:linear-gradient(115deg,#167f70,#359d72);border-color:#63ba9f;color:white}.muted{color:#b0c5bc;font-size:12px}.error{color:#ffb8bb}.actions{margin-top:14px}.actions .spacer{flex:1}.count{font-size:11px;text-align:right;color:#b0c5bc}.question{padding-bottom:12px;border-bottom:1px solid #ffffff20;font-weight:550}small{display:block}.mode{display:flex;align-items:center;gap:8px;font-weight:400}input{accent-color:#299d80}.extra{border:1px solid #52756977;border-radius:9px;padding:9px 11px;margin-top:12px}.extra summary{cursor:pointer;color:#b0c5bc;font-size:12px}.context-ready{background:#299d801a;border:1px solid #48b79d66;border-radius:9px;padding:10px 12px;color:#b4e5d5;font-size:12px}
`;
  function mountAIFieldUI(integration) {
    const host = document.createElement("ezeapply-ai");
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = css;
    shadow.append(style);
    function logo(dialog2 = false) {
      const image = document.createElement("img");
      image.className = `ai-logo${dialog2 ? " dialog-logo" : ""}`;
      image.alt = "";
      image.setAttribute("aria-hidden", "true");
      const url = typeof chrome !== "undefined" ? chrome.runtime?.getURL?.("custom/ai-logo.png") : void 0;
      if (url) image.src = url;
      image.addEventListener("error", () => {
        image.hidden = true;
      });
      return image;
    }
    const pill = document.createElement("button");
    pill.type = "button";
    pill.className = "pill";
    pill.append(logo(), document.createTextNode("EZE AI"));
    pill.title = "Draft an application answer";
    pill.hidden = true;
    shadow.append(pill);
    document.documentElement.append(host);
    let target, dialog, id2 = "", stopped = false;
    let refreshCurrent;
    let heartbeat, port;
    function node(tag, cls = "", text5 = "") {
      const element = document.createElement(tag);
      element.className = cls;
      element.textContent = text5;
      return element;
    }
    function button(label, cls = "") {
      const el = node("button", cls, label);
      el.type = "button";
      return el;
    }
    function stopRequest() {
      if (id2) void chrome.runtime.sendMessage({ type: "eze-ai:cancel", id: id2 }).catch(() => {
      });
      id2 = "";
      if (heartbeat) clearInterval(heartbeat);
      heartbeat = void 0;
      port?.disconnect();
      port = void 0;
    }
    function currentField(field) {
      if (!field.element.isConnected || !integration.enabled()) return;
      return integration.fields().find((item) => item.element === field.element && item.question === field.question);
    }
    function close() {
      stopRequest();
      refreshCurrent = void 0;
      dialog?.close();
      dialog?.remove();
      dialog = void 0;
      if (target && currentField(target)) target.element.focus();
    }
    function position() {
      if (!target || !currentField(target)) {
        target = void 0;
        pill.hidden = true;
        if (dialog) close();
        return;
      }
      const rect = target.element.getBoundingClientRect();
      pill.hidden = rect.width < 20 || rect.height < 10 || rect.bottom < 0 || rect.top > innerHeight || !!dialog;
      if (pill.hidden) return;
      const width = pill.offsetWidth || 76, height = pill.offsetHeight || 24, gap = 4;
      const left = Math.max(gap, Math.min(rect.left + rect.width - width, innerWidth - width - gap));
      let top = rect.bottom + gap;
      if (top + height > innerHeight - gap) top = rect.top - height - gap;
      if (top < gap) {
        pill.hidden = true;
        return;
      }
      pill.style.left = `${left}px`;
      pill.style.top = `${top}px`;
    }
    function focus(event) {
      if (dialog || event.composedPath().includes(host)) return;
      if (!integration.enabled()) {
        target = void 0;
        pill.hidden = true;
        return;
      }
      const element = event.composedPath()[0];
      const match = integration.fields().find((field) => field.element === element);
      if (match) {
        target = match;
        position();
      } else {
        target = void 0;
        pill.hidden = true;
      }
    }
    async function open() {
      if (!target || dialog) return false;
      const field = currentField(target);
      if (!field) {
        target = void 0;
        pill.hidden = true;
        return false;
      }
      const baseline = field.value;
      dialog = node("dialog");
      dialog.setAttribute("aria-label", "EZEapply AI answer");
      shadow.append(dialog);
      const currentDialog = dialog;
      const header = node("header"), title = node("h2", "", "EZE AI"), dismiss = button("Close");
      header.append(logo(true), title, dismiss);
      const question2 = node("p", "question", field.question);
      if (field.instructions) question2.append(node("small", "muted", field.instructions));
      const summary = node("p", "muted", "Checking your AI setup\u2026");
      const backgroundHint = node("p", "context-ready", "Checking saved r\xE9sum\xE9/background\u2026");
      const mode = node("label", "mode"), smart = node("input");
      smart.type = "checkbox";
      mode.append(smart, "Smart model");
      const contextLabel = node("label", "", "Additional context (optional)"), context = node("textarea");
      context.id = "context";
      context.maxLength = 8e3;
      context.placeholder = "Add facts that help answer this question.";
      contextLabel.htmlFor = context.id;
      const extras = node("details", "extra"), extraToggle = node("summary", "", "Add question-specific facts (optional)");
      extras.append(extraToggle, contextLabel, context);
      const status = node("p", "muted");
      status.setAttribute("role", "status");
      const answerLabel = node("label", "", "Review your answer"), answer = node("textarea", "answer");
      answer.id = "draft";
      answerLabel.htmlFor = answer.id;
      answer.hidden = answerLabel.hidden = true;
      const count = node("div", "count");
      const actions = node("div", "actions"), settings = button("AI settings"), spacer = node("span", "spacer"), generate = button("Generate", "primary"), cancel = button("Cancel"), use = button("Use answer", "primary");
      cancel.hidden = true;
      use.hidden = true;
      actions.append(settings, spacer, cancel, generate, use);
      currentDialog.append(
        header,
        question2,
        summary,
        backgroundHint,
        mode,
        extras,
        answerLabel,
        answer,
        count,
        status,
        actions
      );
      let draft;
      let ready = false, version = 0, backgroundIncluded = false;
      generate.disabled = true;
      function updateCount() {
        count.textContent = draft ? `${answer.value.length} / ${draft.maxLength} characters${draft.maxWords ? ` \xB7 ${answer.value.trim().split(/\s+/).filter(Boolean).length} / ${draft.maxWords} words` : ""}` : "";
        use.disabled = !draft || !answer.value.trim() || !fits(answer.value, draft.maxLength, draft.maxWords);
      }
      const report = (text5, error = false) => {
        status.textContent = text5;
        status.classList.toggle("error", error);
      };
      dismiss.addEventListener("click", close);
      currentDialog.addEventListener("cancel", (event) => {
        event.preventDefault();
        close();
      });
      settings.addEventListener("click", () => {
        void chrome.runtime.sendMessage({ type: "eze-ai:open-settings" });
      });
      answer.addEventListener("input", updateCount);
      cancel.addEventListener("click", () => {
        stopRequest();
        generate.disabled = !ready;
        generate.hidden = false;
        cancel.hidden = true;
        report("Cancelled. Your form answer is unchanged.");
      });
      generate.addEventListener("click", async (event) => {
        if (!event.isTrusted || id2 || !ready) return;
        if (!currentField(field)) {
          target = void 0;
          close();
          return;
        }
        id2 = crypto.randomUUID();
        const requestId = id2;
        generate.disabled = true;
        use.hidden = true;
        cancel.hidden = false;
        report("Generating with your provider\u2026");
        try {
          port = chrome.runtime.connect({ name: "eze-ai:keepalive" });
          port.postMessage({ id: requestId });
          heartbeat = setInterval(() => {
            try {
              port?.postMessage({ ping: true });
            } catch {
              stopRequest();
            }
          }, 2e4);
          const description2 = document.querySelector(
            '.jobs-description,[data-testid="job-description"],#job-description,[itemprop="description"]'
          );
          const response = await chrome.runtime.sendMessage({
            type: "eze-ai:generate",
            id: requestId,
            request: {
              question: [field.question, field.instructions].filter(Boolean).join("\n"),
              context: context.value,
              pageTitle: document.title,
              jobDescription: description2?.textContent?.slice(0, 8e3) || "",
              maxLength: field.maxLength,
              tier: smart.checked ? "smart" : "fast"
            }
          });
          if (id2 !== requestId || dialog !== currentDialog) return;
          if (response?.error) throw new Error(response.error);
          draft = response.draft;
          if (!draft || typeof draft.answer !== "string") throw new Error("No answer was returned.");
          if (draft.needsInfo) {
            report(
              `${backgroundIncluded ? "Your saved r\xE9sum\xE9/background was included. " : ""}${draft.needsInfo}`,
              true
            );
            answer.hidden = answerLabel.hidden = true;
            count.textContent = "";
            extras.open = true;
            context.focus();
          } else {
            answer.value = draft.answer;
            answer.hidden = answerLabel.hidden = false;
            use.hidden = false;
            report(
              draft.warning || `Drafted with ${draft.provider} \xB7 ${draft.model}. Review before using.`,
              !!draft.warning
            );
            updateCount();
          }
          generate.textContent = "Regenerate";
        } catch (error) {
          if (id2 === requestId && dialog === currentDialog)
            report(error instanceof Error ? error.message : "Generation failed.", true);
        } finally {
          if (id2 === requestId) {
            id2 = "";
            if (heartbeat) clearInterval(heartbeat);
            heartbeat = void 0;
            port?.disconnect();
            port = void 0;
            generate.disabled = !ready;
            cancel.hidden = true;
          }
        }
      });
      use.addEventListener("click", (event) => {
        if (!event.isTrusted || !draft || !fits(answer.value, draft.maxLength, draft.maxWords) || !answer.value.trim())
          return;
        if (!currentField(field)) {
          target = void 0;
          close();
          return;
        }
        try {
          integration.apply(field, answer.value.trim(), baseline);
          close();
        } catch (error) {
          report(error instanceof Error ? error.message : "Could not apply this answer.", true);
        }
      });
      let initialized = false;
      refreshCurrent = async () => {
        const requested = ++version;
        try {
          const info = await chrome.runtime.sendMessage({
            type: "eze-ai:status",
            ...initialized ? { tier: smart.checked ? "smart" : "fast" } : {}
          });
          if (dialog !== currentDialog || version !== requested) return;
          if (info?.error) throw new Error(info.error);
          if (!info || typeof info.configured !== "boolean")
            throw new Error("Could not read AI setup. Open AI settings, then return here.");
          if (!initialized) smart.checked = !!info.smart;
          initialized = true;
          ready = info.configured;
          generate.disabled = !!id2 || !ready;
          summary.textContent = ready ? `Your provider: ${info.provider} \xB7 ${info.model}` : info.issue || "Add your provider key and model in AI settings. Your r\xE9sum\xE9 does not replace provider setup.";
          summary.classList.toggle("error", !ready);
          backgroundIncluded = !!info.hasBackground;
          backgroundHint.textContent = backgroundIncluded ? `Saved r\xE9sum\xE9/background${info.backgroundCharacters ? ` \xB7 ${Number(info.backgroundCharacters).toLocaleString()} characters` : ""} \xB7 included automatically. You can generate without adding extra context.` : info.includeProfile ? "Saved profile and custom answers are included. To add r\xE9sum\xE9 text once: AI settings \u2192 Answers \u2192 Use saved r\xE9sum\xE9 or Load PDF / text." : "No saved r\xE9sum\xE9/background is available. Add it once in AI settings \u2192 Answers \u2192 Use saved r\xE9sum\xE9 or Load PDF / text.";
        } catch (error) {
          if (dialog === currentDialog && version === requested) {
            ready = false;
            generate.disabled = true;
            report(error instanceof Error ? error.message : "Could not check AI setup.", true);
          }
        }
      };
      smart.addEventListener("change", () => void refreshCurrent?.());
      currentDialog.showModal();
      pill.hidden = true;
      await refreshCurrent();
      if (dialog === currentDialog) (ready ? generate : settings).focus();
      return dialog === currentDialog;
    }
    pill.addEventListener("click", (event) => {
      if (event.isTrusted) void open();
    });
    document.addEventListener("focusin", focus, true);
    target = integration.enabled() ? integration.fields().find((field) => field.element === document.activeElement) : void 0;
    position();
    window.addEventListener("scroll", position, true);
    window.addEventListener("resize", position);
    const timer = setInterval(() => {
      if (!stopped) position();
    }, 1e3);
    const onWindowFocus = () => {
      if (dialog && !id2) void refreshCurrent?.();
    };
    window.addEventListener("focus", onWindowFocus);
    return {
      async open(element) {
        if (stopped || !integration.enabled()) return false;
        if (dialog)
          throw new Error(
            "An AI draft is already open on this page. Close it before opening another question."
          );
        const field = integration.fields().find((field2) => field2.element === element);
        if (!field) return false;
        target = field;
        return open();
      },
      dispose() {
        stopped = true;
        close();
        clearInterval(timer);
        document.removeEventListener("focusin", focus, true);
        window.removeEventListener("scroll", position, true);
        window.removeEventListener("resize", position);
        window.removeEventListener("focus", onWindowFocus);
        host.remove();
      }
    };
  }

  // src/matching-text.ts
  function normalize(value) {
    return value.normalize("NFKC").replace(/([a-z])([A-Z])/g, "$1 $2").toLocaleLowerCase("en").replace(/\b(?:required|optional)\b/g, " ").replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/\s+/g, " ");
  }
  function includesPhrase(text5, phrase) {
    return !!phrase && ` ${text5} `.includes(` ${phrase} `);
  }

  // src/matching-terms.ts
  var WRAPPER_WORDS = new Set(
    "please kindly enter provide share mention select choose indicate specify tell state what whats s your you the a an is are was were would could can do does how many much of to in for us me have has been with using this these that".split(
      " "
    )
  );
  var AMOUNT_WORDS = new Set(
    "inr rupee rupees rs usd eur gbp cad aud sgd dollar dollars euro euros lakh lakhs lac lacs lpa crore crores thousand thousands million millions amount".split(
      " "
    )
  );
  var EXPERIENCE_WORDS = new Set(
    "total overall professional work working worked employment number these this fields field relevant additional long".split(
      " "
    )
  );
  var NOTICE_WORDS = new Set(
    "notice period duration length time current currently contractual contract join joining start starting work working employment availability available ready earliest soon long within after before from if offered offer accepted accepting acceptance role position job opportunity selected successful able be will required need needed number calendar days day weeks week months month years year".split(
      " "
    )
  );
  var CURRENCIES = new Map(
    Object.entries({
      inr: "INR",
      rupee: "INR",
      rupees: "INR",
      rs: "INR",
      usd: "USD",
      dollar: "DOLLAR",
      dollars: "DOLLAR",
      eur: "EUR",
      euro: "EUR",
      euros: "EUR",
      gbp: "GBP",
      cad: "CAD",
      aud: "AUD",
      sgd: "SGD"
    })
  );
  function monetarySymbols(text5) {
    return text5.replace(/₹/g, " INR ").replace(/€/g, " EUR ").replace(/£/g, " GBP ").replace(/\$/g, " dollars ");
  }
  function monetaryFormat(raw) {
    const words = normalize(monetarySymbols(raw)).split(" "), text5 = words.join(" ");
    const scales = [];
    if (words.some((word) => ["lakh", "lakhs", "lac", "lacs", "lpa"].includes(word)))
      scales.push("lakh");
    if (words.some((word) => ["crore", "crores"].includes(word))) scales.push("crore");
    if (words.some((word) => ["thousand", "thousands"].includes(word))) scales.push("thousand");
    if (words.some((word) => ["million", "millions"].includes(word))) scales.push("million");
    const periods = [];
    if (/\b(annual|annually|annum|year|yearly|lpa)\b/.test(text5)) periods.push("year");
    if (/\b(month|monthly)\b/.test(text5)) periods.push("month");
    if (/\b(week|weekly)\b/.test(text5)) periods.push("week");
    if (/\b(day|daily)\b/.test(text5)) periods.push("day");
    if (/\b(hour|hourly)\b/.test(text5)) periods.push("hour");
    return {
      currencies: [
        ...new Set(
          words.map((word) => CURRENCIES.get(word)).filter((value) => !!value)
        )
      ],
      scales,
      periods
    };
  }
  function responseKind(text5) {
    text5 = text5.replace(/^(?:(?:please|kindly) )+/, "");
    if (/^(?:describe|summarize|explain)\b|\btell us about\b|\bdescription\b/.test(text5))
      return "description";
    if (/^(?:do|does|did|are|is|have|has|will|would|can|could)\b/.test(text5)) return "boolean";
    return "duration";
  }
  function matchingTerms(raw) {
    let text5 = normalize(
      monetarySymbols(raw.replace(/\bc\+\+/gi, " cpp ").replace(/\bc#/gi, " csharp ")).replace(
        /%/g,
        " percent "
      )
    ).replace(/\bc t c\b/g, "ctc").replace(/\bcost to company\b/g, "ctc");
    let topic = /\bctc\b/.test(text5) ? "ctc" : /\bsalary\b/.test(text5) ? "salary" : /\b(compensation|pay|remuneration)\b/.test(text5) ? "compensation" : void 0;
    const compensation = !!topic;
    let kind;
    let payPeriod;
    let payComponent;
    const joiningDuration = /\b(join|joining|start|starting)\b/.test(text5) && (/\b(?:how many|number of) (?:calendar |working |business )?(?:days?|weeks?|months?|years?)\b|\bhow (?:soon|long)\b/.test(
      text5
    ) || /\b(?:availability|available|joining|join)\b.*\bin (?:days?|weeks?|months?)\b/.test(text5)) && !/\bdate\b|\bwhen\b/.test(text5);
    if (compensation) {
      text5 = text5.replace(/\b(desired|target)\b/g, "expected").replace(/\bpresent\b/g, "current").replace(/\blast drawn\b/g, "current").replace(/\b(salary|compensation|pay) expectations?\b/g, "expected $1").replace(/\bexpectations? (?:for|of)\b/g, "expected").replace(
        /\b(?:including|inclusive of) (?:any |all |both |the |your )?(?:fixed and )?variable (?:components?|pay|compensation|bonus)\b/g,
        " "
      );
      if (topic === "ctc") text5 = text5.replace(/\b(salary|compensation|pay|remuneration)\b/g, " ");
      kind = /\b(percent|percentage)\b/.test(text5) ? "percentage" : /^(?:describe|summarize|explain)\b|\btell us about\b/.test(text5) ? "description" : /\b(negotiable|negotiability)\b/.test(text5) ? "boolean" : "amount";
      payComponent = /\b(?:fixed|base)\b|\bexcluding variable\b/.test(text5) ? "fixed" : /\bvariable\b/.test(text5) ? "variable" : /\bbonus\b/.test(text5) ? "bonus" : /\b(equity|stock)\b/.test(text5) ? "equity" : "total";
      const { periods } = monetaryFormat(text5);
      payPeriod = periods.length > 1 ? "mixed" : periods[0] || (topic === "ctc" ? "year" : void 0);
    } else if (/\bnotice (?:period|duration)\b/.test(text5) || joiningDuration) {
      topic = "notice";
      text5 = text5.replace(
        /\bif you (?:are|re) (?:already )?(?:serving|on) (?:a )?notice\b.*\b(?:join|joining|start)\b.*$/,
        ""
      ).replace(/\bnotice duration\b/g, "notice period").replace(/\b(?:working|business) days?\b/g, "business days");
      kind = /\bdate\b|\blast working day\b/.test(text5) ? "date" : joiningDuration ? "duration" : responseKind(text5);
    } else if (/\bexperience\b/.test(text5) || /\b(worked|working)\b/.test(text5) && /\b(years?|months?|how long)\b/.test(text5)) {
      topic = "experience";
      kind = responseKind(text5);
      text5 = text5.replace(/\b(worked|working)\b/g, "experience").replace(/\bjava script\b/g, "javascript").replace(/\btype script\b/g, "typescript");
    } else if (/\b(school|college|university|institution|institute)\b/.test(text5) && /\bname\b/.test(text5)) {
      topic = "institution";
      kind = "name";
      text5 = text5.replace(/\b(school|college|university|institution|institute)\b/g, "institution").replace(/\b(?:or|educational)\b/g, " ");
    }
    const words = text5.split(" ").filter(Boolean);
    const format = monetaryFormat(text5);
    const currency = compensation ? format.currencies[0] : void 0;
    let amountUnit;
    if (compensation) {
      amountUnit = format.scales[0] || (currency ? "base" : void 0);
    }
    const noticeWord = topic === "notice" ? words.find((word) => /^(days?|weeks?|months?|years?)$/.test(word)) : void 0;
    const noticeUnit = noticeWord?.replace(/s$/, "");
    let experienceUnit;
    let experienceScope;
    if (topic === "experience") {
      const years = words.some((word) => /^years?$/.test(word));
      const months = words.some((word) => /^months?$/.test(word));
      experienceUnit = years && months ? "combined" : months ? "month" : "year";
      experienceScope = words.includes("additional") ? "additional" : words.includes("relevant") ? "relevant" : "total";
    }
    const keywords = [
      .../* @__PURE__ */ new Set([
        ...words.filter((word) => {
          if (WRAPPER_WORDS.has(word)) return false;
          if (compensation && (AMOUNT_WORDS.has(word) || /^(per|annual|annually|annum|year|yearly|month|monthly|week|weekly|day|daily|hour|hourly)$/.test(
            word
          ) || topic === "ctc" && ["total", "overall"].includes(word)))
            return false;
          if (topic === "notice" && kind === "duration" && NOTICE_WORDS.has(word)) return false;
          if (topic === "experience" && (EXPERIENCE_WORDS.has(word) || /^(years?|months?)$/.test(word)))
            return false;
          return true;
        }),
        ...topic === "notice" && kind === "duration" ? ["notice", "period"] : []
      ])
    ].sort();
    return {
      keywords,
      topic,
      responseKind: kind,
      compensation,
      currency,
      amountUnit,
      payPeriod,
      payComponent,
      noticeUnit,
      experienceUnit,
      experienceScope,
      ...topic === "notice" && kind === "duration" ? { noticeSubjects: keywords.filter((word) => !["notice", "period"].includes(word)) } : {},
      ...topic === "experience" ? { experienceSubjects: keywords.filter((word) => word !== "experience") } : {},
      ...topic === "institution" ? {
        institutionQualifiers: keywords.filter((word) => !["institution", "name"].includes(word))
      } : {}
    };
  }
  function savedMatchingTerms(label, value) {
    const terms = matchingTerms(label);
    if (terms.topic === "notice" && terms.responseKind === "duration" && !terms.noticeUnit) {
      const unit = normalize(value).match(/^\d+(?: \d+)? (days?|weeks?|months?|years?)$/)?.[1];
      if (unit) terms.noticeUnit = unit.replace(/s$/, "");
    }
    return terms;
  }
  function sameList(left, right) {
    return left.length === right.length && left.every((word, index) => word === right[index]);
  }
  function aliasTerms(label, alias) {
    if (label.currency && alias.currency && label.currency !== alias.currency || label.amountUnit && alias.amountUnit && label.amountUnit !== alias.amountUnit || label.noticeUnit && alias.noticeUnit && label.noticeUnit !== alias.noticeUnit || label.payPeriod && alias.payPeriod && label.payPeriod !== alias.payPeriod || label.payComponent && alias.payComponent && label.payComponent !== alias.payComponent || label.responseKind && alias.responseKind && label.responseKind !== alias.responseKind || label.noticeSubjects?.length && alias.noticeSubjects?.length && !sameList(label.noticeSubjects, alias.noticeSubjects) || label.institutionQualifiers?.length && alias.institutionQualifiers?.length && !sameList(label.institutionQualifiers, alias.institutionQualifiers) || label.experienceUnit && alias.experienceUnit && label.experienceUnit !== alias.experienceUnit || label.experienceScope && alias.experienceScope && label.experienceScope !== alias.experienceScope || label.experienceSubjects?.length && alias.experienceSubjects?.length && !sameList(label.experienceSubjects, alias.experienceSubjects))
      return void 0;
    return {
      ...alias,
      topic: alias.topic || label.topic,
      responseKind: label.responseKind || alias.responseKind,
      compensation: label.compensation || alias.compensation,
      currency: label.currency || alias.currency,
      amountUnit: label.amountUnit || alias.amountUnit,
      payPeriod: label.payPeriod || alias.payPeriod,
      payComponent: label.payComponent || alias.payComponent,
      noticeUnit: label.noticeUnit || alias.noticeUnit,
      noticeSubjects: label.noticeSubjects?.length ? label.noticeSubjects : alias.noticeSubjects,
      experienceUnit: label.experienceUnit || alias.experienceUnit,
      experienceScope: label.experienceScope || alias.experienceScope,
      experienceSubjects: label.experienceSubjects?.length ? label.experienceSubjects : alias.experienceSubjects,
      institutionQualifiers: label.institutionQualifiers?.length ? label.institutionQualifiers : alias.institutionQualifiers
    };
  }
  function sameKeywords(left, right) {
    const enough = left.keywords.length >= 2 || left.topic === "experience" && right.topic === "experience" && left.keywords.length > 0;
    return enough && sameList(left.keywords, right.keywords);
  }
  function matchCompatibility(answer, question2) {
    if (answer.topic && question2.topic && answer.topic !== question2.topic)
      return { priority: 0, reason: "meaning" };
    if (answer.responseKind && question2.responseKind && answer.responseKind !== question2.responseKind)
      return { priority: 0, reason: "meaning" };
    if (answer.payPeriod === "mixed" || question2.payPeriod === "mixed" || answer.payPeriod && question2.payPeriod && answer.payPeriod !== question2.payPeriod || answer.payComponent && question2.payComponent && answer.payComponent !== question2.payComponent)
      return { priority: 0, reason: "meaning" };
    if (answer.topic === "experience" && question2.topic === "experience" && (answer.experienceUnit !== question2.experienceUnit || answer.experienceScope !== question2.experienceScope || !sameList(answer.experienceSubjects || [], question2.experienceSubjects || [])))
      return { priority: 0, reason: "meaning" };
    if (answer.topic === "notice" && question2.topic === "notice" && answer.responseKind === "duration" && question2.responseKind === "duration") {
      if ((answer.noticeUnit || "day") !== (question2.noticeUnit || "day"))
        return { priority: 0, reason: "notice-units" };
      if (!sameList(answer.noticeSubjects || [], question2.noticeSubjects || []))
        return { priority: 0, reason: "meaning" };
    }
    if (answer.topic === "institution" && question2.topic === "institution" && !sameList(answer.institutionQualifiers || [], question2.institutionQualifiers || []))
      return { priority: 0, reason: "meaning" };
    if (answer.compensation && question2.compensation) {
      if (!question2.amountUnit && !question2.currency && question2.topic === "ctc" && answer.amountUnit === "lakh" && (!answer.currency || answer.currency === "INR"))
        return { priority: 1 };
      if (answer.topic === "ctc" && question2.topic === "ctc" && !answer.amountUnit && !answer.currency && question2.amountUnit === "lakh" && (!question2.currency || question2.currency === "INR"))
        return { priority: 1 };
      const sameIndianLakh = question2.topic === "ctc" && answer.amountUnit === "lakh" && question2.amountUnit === "lakh" && (!answer.currency || answer.currency === "INR") && (!question2.currency || question2.currency === "INR");
      if (answer.amountUnit !== question2.amountUnit || answer.currency !== question2.currency && !sameIndianLakh)
        return { priority: 0, reason: "units" };
    }
    return { priority: 3 };
  }

  // src/fill-notice.ts
  function fillNotice(document2) {
    let host, timer;
    function dispose() {
      clearTimeout(timer);
      host?.remove();
      host = void 0;
    }
    return {
      show(text5, busy = false) {
        dispose();
        if (document2.defaultView?.top !== document2.defaultView) return;
        host = document2.createElement("ezeapply-status");
        const shadow = host.attachShadow({ mode: "closed" }), style = document2.createElement("style"), notice = document2.createElement("div"), mark = document2.createElement("span");
        style.textContent = ":host{all:initial;position:fixed;top:22px;left:50%;transform:translateX(-50%);z-index:2147483646;pointer-events:none}.notice{display:flex;align-items:center;gap:10px;max-width:calc(100vw - 32px);padding:12px 18px;border:1px solid #85e0bd88;border-radius:14px;background:linear-gradient(115deg,#167f70,#269b83 70%,#359d72);color:#fff;font:600 14px/1.4 -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 8px 30px #092d2b44}.mark{width:14px;height:14px;flex:none;border-radius:50%;border:2px solid #ffffff55;border-top-color:white}.busy{animation:spin .8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.busy{animation:none}}";
        notice.className = "notice";
        notice.setAttribute("role", "status");
        mark.className = `mark${busy ? " busy" : ""}`;
        mark.setAttribute("aria-hidden", "true");
        notice.append(mark, document2.createTextNode(text5));
        shadow.append(style, notice);
        document2.documentElement.append(host);
        timer = setTimeout(dispose, busy ? 3e4 : 2600);
      },
      dispose
    };
  }

  // src/matcher.ts
  function matchesScope(scope, hostname) {
    if (!scope.trim()) return true;
    const target = scope.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "");
    return hostname.toLowerCase() === target || hostname.toLowerCase().endsWith(`.${target}`);
  }
  function qualifier(text5, variants) {
    return variants.some((value) => includesPhrase(text5, value));
  }
  function contradicts(field, question2) {
    const fieldLabel = normalize(field.label);
    const pairs = [
      [
        ["expected", "desired", "target"],
        ["current", "present", "last drawn", "previous"]
      ],
      [
        ["first", "given"],
        ["last", "family", "surname"]
      ],
      [["middle"], ["first", "given", "last", "family", "surname"]],
      [
        ["without country code", "national", "number only", "local number"],
        ["international", "including country code", "with country code"]
      ]
    ];
    return pairs.some(
      ([left, right]) => qualifier(fieldLabel, left) && qualifier(question2, right) || qualifier(fieldLabel, right) && qualifier(question2, left)
    );
  }
  function matchField(labels, fields, hostname, autocomplete) {
    const uniqueQuestions = /* @__PURE__ */ new Map();
    for (const label of labels) {
      const normalized = normalize(label);
      if (normalized && !uniqueQuestions.has(normalized)) uniqueQuestions.set(normalized, label);
    }
    const questions = [...uniqueQuestions.keys()];
    const rawQuestions = [...uniqueQuestions.values()];
    const questionTerms = rawQuestions.map(matchingTerms);
    if (!questions.length && !autocomplete) return { score: 0, reason: "No usable label" };
    const candidates = [];
    let differentUnits = false;
    let differentNoticeUnits = false;
    let differentMeaning = false;
    for (const field of fields) {
      if (!field.enabled || !field.value.trim() || !matchesScope(field.scope, hostname)) continue;
      if (questions[0] && contradicts(field, questions[0])) continue;
      if (field.exclude.some(
        (exclude) => questions.some((question2) => includesPhrase(question2, normalize(exclude)))
      ))
        continue;
      let best = autocomplete && field.autocomplete?.includes(autocomplete) ? 180 : 0;
      let bestPriority = best ? 3 : 0;
      const fieldTerms = savedMatchingTerms(field.label, field.value);
      for (const rawAlias of [field.label, ...field.aliases]) {
        const alias = normalize(rawAlias);
        if (!alias) continue;
        const terms = aliasTerms(fieldTerms, matchingTerms(rawAlias));
        if (!terms) continue;
        questions.forEach((question2, index) => {
          const exact = question2 === alias;
          const phrase = field.matchMode !== "exact" && includesPhrase(question2, alias);
          const keywords = field.matchMode !== "exact" && sameKeywords(terms, questionTerms[index]);
          if (!exact && !phrase && !keywords) return;
          const units = questionTerms[0]?.topic ? questionTerms[0] : questionTerms[index];
          const { priority, reason } = matchCompatibility(terms, units);
          if (!priority) {
            if (reason === "units") differentUnits = true;
            else if (reason === "notice-units") differentNoticeUnits = true;
            else differentMeaning = true;
            return;
          }
          const score = (exact ? 120 : keywords ? 90 : 65) + Math.min(keywords && !exact ? terms.keywords.length : alias.split(" ").length, 10) * 3 - index * 4;
          if (priority > bestPriority || priority === bestPriority && score > best) {
            best = score;
            bestPriority = priority;
          }
        });
      }
      if (best) candidates.push({ field, score: best, priority: bestPriority });
    }
    candidates.sort(
      (a, b) => b.priority - a.priority || b.score - a.score || a.field.id.localeCompare(b.field.id)
    );
    const first = candidates[0];
    if (!first)
      return {
        score: 0,
        reason: differentUnits ? "Saved answers use different units. Save a matching INR or lakh/LPA variant. A generic CTC question can use a saved generic or lakh answer." : differentNoticeUnits ? "The saved notice-period answer uses different time units. Save a separate answer for days, weeks, or months." : differentMeaning ? "Saved answers describe a different pay period, component, experience type, or response format." : "No matching saved field"
      };
    const peers = candidates.filter((candidate) => candidate.priority === first.priority);
    const conflict = peers.find(
      (candidate) => candidate.field.value !== first.field.value && first.score - candidate.score <= 6
    );
    if (conflict) {
      const user = peers.filter(
        (candidate) => !/^(builtin|profile):/.test(candidate.field.id) && candidate.score >= 120
      );
      if (user.length === 1 && peers.every(
        (candidate) => /^(builtin|profile):/.test(candidate.field.id) || candidate === user[0]
      ))
        return { field: user[0].field, score: user[0].score, reason: "Matched your custom answer" };
      return {
        score: first.score,
        reason: "Multiple saved answers match; refine their matching phrases"
      };
    }
    return {
      field: first.field,
      score: first.score,
      reason: first.priority === 1 ? "Matched saved CTC answer using the default lakh format" : "Matched saved field"
    };
  }

  // src/types.ts
  var STORAGE_KEY = "eze.customFields.v1";
  var MESSAGE_PREFIX = "eze-custom:";
  var PANEL_RESTORE_KEY = "eze.showFloatingRestore";
  var LINKEDIN_NOFOLLOW_KEY = "eze.linkedin.disableAutoFollow";

  // node_modules/libphonenumber-js/metadata.min.json.js
  var metadata_min_json_default = { "version": 4, "country_calling_codes": { "1": ["US", "AG", "AI", "AS", "BB", "BM", "BS", "CA", "DM", "DO", "GD", "GU", "JM", "KN", "KY", "LC", "MP", "MS", "PR", "SX", "TC", "TT", "VC", "VG", "VI"], "7": ["RU", "KZ"], "20": ["EG"], "27": ["ZA"], "30": ["GR"], "31": ["NL"], "32": ["BE"], "33": ["FR"], "34": ["ES"], "36": ["HU"], "39": ["IT", "VA"], "40": ["RO"], "41": ["CH"], "43": ["AT"], "44": ["GB", "GG", "IM", "JE"], "45": ["DK"], "46": ["SE"], "47": ["NO", "SJ"], "48": ["PL"], "49": ["DE"], "51": ["PE"], "52": ["MX"], "53": ["CU"], "54": ["AR"], "55": ["BR"], "56": ["CL"], "57": ["CO"], "58": ["VE"], "60": ["MY"], "61": ["AU", "CC", "CX"], "62": ["ID"], "63": ["PH"], "64": ["NZ"], "65": ["SG"], "66": ["TH"], "81": ["JP"], "82": ["KR"], "84": ["VN"], "86": ["CN"], "90": ["TR"], "91": ["IN"], "92": ["PK"], "93": ["AF"], "94": ["LK"], "95": ["MM"], "98": ["IR"], "211": ["SS"], "212": ["MA", "EH"], "213": ["DZ"], "216": ["TN"], "218": ["LY"], "220": ["GM"], "221": ["SN"], "222": ["MR"], "223": ["ML"], "224": ["GN"], "225": ["CI"], "226": ["BF"], "227": ["NE"], "228": ["TG"], "229": ["BJ"], "230": ["MU"], "231": ["LR"], "232": ["SL"], "233": ["GH"], "234": ["NG"], "235": ["TD"], "236": ["CF"], "237": ["CM"], "238": ["CV"], "239": ["ST"], "240": ["GQ"], "241": ["GA"], "242": ["CG"], "243": ["CD"], "244": ["AO"], "245": ["GW"], "246": ["IO"], "247": ["AC"], "248": ["SC"], "249": ["SD"], "250": ["RW"], "251": ["ET"], "252": ["SO"], "253": ["DJ"], "254": ["KE"], "255": ["TZ"], "256": ["UG"], "257": ["BI"], "258": ["MZ"], "260": ["ZM"], "261": ["MG"], "262": ["RE", "YT"], "263": ["ZW"], "264": ["NA"], "265": ["MW"], "266": ["LS"], "267": ["BW"], "268": ["SZ"], "269": ["KM"], "290": ["SH", "TA"], "291": ["ER"], "297": ["AW"], "298": ["FO"], "299": ["GL"], "350": ["GI"], "351": ["PT"], "352": ["LU"], "353": ["IE"], "354": ["IS"], "355": ["AL"], "356": ["MT"], "357": ["CY"], "358": ["FI", "AX"], "359": ["BG"], "370": ["LT"], "371": ["LV"], "372": ["EE"], "373": ["MD"], "374": ["AM"], "375": ["BY"], "376": ["AD"], "377": ["MC"], "378": ["SM"], "380": ["UA"], "381": ["RS"], "382": ["ME"], "383": ["XK"], "385": ["HR"], "386": ["SI"], "387": ["BA"], "389": ["MK"], "420": ["CZ"], "421": ["SK"], "423": ["LI"], "500": ["FK"], "501": ["BZ"], "502": ["GT"], "503": ["SV"], "504": ["HN"], "505": ["NI"], "506": ["CR"], "507": ["PA"], "508": ["PM"], "509": ["HT"], "590": ["GP", "BL", "MF"], "591": ["BO"], "592": ["GY"], "593": ["EC"], "594": ["GF"], "595": ["PY"], "596": ["MQ"], "597": ["SR"], "598": ["UY"], "599": ["CW", "BQ"], "670": ["TL"], "672": ["NF"], "673": ["BN"], "674": ["NR"], "675": ["PG"], "676": ["TO"], "677": ["SB"], "678": ["VU"], "679": ["FJ"], "680": ["PW"], "681": ["WF"], "682": ["CK"], "683": ["NU"], "685": ["WS"], "686": ["KI"], "687": ["NC"], "688": ["TV"], "689": ["PF"], "690": ["TK"], "691": ["FM"], "692": ["MH"], "850": ["KP"], "852": ["HK"], "853": ["MO"], "855": ["KH"], "856": ["LA"], "880": ["BD"], "886": ["TW"], "960": ["MV"], "961": ["LB"], "962": ["JO"], "963": ["SY"], "964": ["IQ"], "965": ["KW"], "966": ["SA"], "967": ["YE"], "968": ["OM"], "970": ["PS"], "971": ["AE"], "972": ["IL"], "973": ["BH"], "974": ["QA"], "975": ["BT"], "976": ["MN"], "977": ["NP"], "992": ["TJ"], "993": ["TM"], "994": ["AZ"], "995": ["GE"], "996": ["KG"], "998": ["UZ"] }, "countries": { "AC": ["247", "00", "(?:[01589]\\d|[2-467])\\d{4}", [5, 6]], "AD": ["376", "00", "(?:1|6\\d)\\d{7}|[135-9]\\d{5}", [6, 8, 9], [["(\\d{3})(\\d{3})", "$1 $2", ["[135-9]"]], ["(\\d{4})(\\d{4})", "$1 $2", ["1"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]]]], "AE": ["971", "00", "(?:[4-7]\\d|9[0-689])\\d{7}|800\\d{2,9}|[2-4679]\\d{7}", [5, 6, 7, 8, 9, 10, 11, 12], [["(\\d{3})(\\d{2,9})", "$1 $2", ["60|8"]], ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[236]|[479][2-8]"], "0$1"], ["(\\d{3})(\\d)(\\d{5})", "$1 $2 $3", ["[479]"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["5"], "0$1"]], "0"], "AF": ["93", "00", "[2-7]\\d{8}", [9], [["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-7]"], "0$1"]], "0"], "AG": ["1", "011", "(?:268|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([457]\\d{6})$|1", "268$1", 0, "268"], "AI": ["1", "011", "(?:264|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2457]\\d{6})$|1", "264$1", 0, "264"], "AL": ["355", "00", "(?:700\\d\\d|900)\\d{3}|8\\d{5,7}|(?:[2-5]|6\\d)\\d{7}", [6, 7, 8, 9], [["(\\d{3})(\\d{3,4})", "$1 $2", ["80|9"], "0$1"], ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["4[2-6]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2358][2-5]|4"], "0$1"], ["(\\d{3})(\\d{5})", "$1 $2", ["[23578]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["6"], "0$1"]], "0"], "AM": ["374", "00", "(?:[1-489]\\d|55|60|77)\\d{6}", [8], [["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[89]0"], "0 $1"], ["(\\d{3})(\\d{5})", "$1 $2", ["2|3[12]"], "(0$1)"], ["(\\d{2})(\\d{6})", "$1 $2", ["1|47"], "(0$1)"], ["(\\d{2})(\\d{6})", "$1 $2", ["[3-9]"], "0$1"]], "0"], "AO": ["244", "00", "[29]\\d{8}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[29]"]]]], "AR": ["54", "00", "(?:11|[89]\\d\\d)\\d{8}|[2368]\\d{9}", [10, 11], [["(\\d{4})(\\d{2})(\\d{4})", "$1 $2-$3", ["2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9])", "2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8]))|2(?:2[24-9]|3[1-59]|47)", "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5[56][46]|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]", "2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|58|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|54(?:4|5[13-7]|6[89])|86[3-6]))|2(?:2[24-9]|3[1-59]|47)|38(?:[58][78]|7[378])|3(?:454|85[56])[46]|3(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"], "0$1", 1], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2-$3", ["1"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["[68]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2-$3", ["[23]"], "0$1", 1], ["(\\d)(\\d{4})(\\d{2})(\\d{4})", "$2 15-$3-$4", ["9(?:2[2-469]|3[3-578])", "9(?:2(?:2[024-9]|3[0-59]|47|6[245]|9[02-8])|3(?:3[28]|4[03-9]|5[2-46-8]|7[1-578]|8[2-9]))", "9(?:2(?:[23]02|6(?:[25]|4[6-8])|9(?:[02356]|4[02568]|72|8[23]))|3(?:3[28]|4(?:[04679]|3[5-8]|5[4-68]|8[2379])|5(?:[2467]|3[237]|8[2-5])|7[1-578]|8(?:[2469]|3[2578]|5[4-8]|7[36-8]|8[5-8])))|92(?:2[24-9]|3[1-59]|47)", "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3[78]|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8[23])|7[1-578]|8(?:[2469]|3[278]|5(?:[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4[35][56]|58[45]|8(?:[38]5|54|76))[4-6]", "9(?:2(?:[23]02|6(?:[25]|4(?:64|[78]))|9(?:[02356]|4(?:[0268]|5[2-6])|72|8[23]))|3(?:3[28]|4(?:[04679]|3(?:5(?:4[0-25689]|[56])|[78])|5(?:4[46]|8)|8[2379])|5(?:[2467]|3[237]|8(?:[23]|4(?:[45]|60)|5(?:4[0-39]|5|64)))|7[1-578]|8(?:[2469]|3[278]|5(?:4(?:4|5[13-7]|6[89])|[56][46]|[78])|7[378]|8(?:6[3-6]|[78]))))|92(?:2[24-9]|3[1-59]|47)|93(?:4(?:36|5[56])|8(?:[38]5|76))[4-6]"], "0$1", 0, "$1 $2 $3-$4"], ["(\\d)(\\d{2})(\\d{4})(\\d{4})", "$2 15-$3-$4", ["91"], "0$1", 0, "$1 $2 $3-$4"], ["(\\d{3})(\\d{3})(\\d{5})", "$1-$2-$3", ["8"], "0$1"], ["(\\d)(\\d{3})(\\d{3})(\\d{4})", "$2 15-$3-$4", ["9"], "0$1", 0, "$1 $2 $3-$4"]], "0", 0, "0?(?:(11|2(?:2(?:02?|[13]|2[13-79]|4[1-6]|5[2457]|6[124-8]|7[1-4]|8[13-6]|9[1267])|3(?:02?|1[467]|2[03-6]|3[13-8]|[49][2-6]|5[2-8]|[67])|4(?:7[3-578]|9)|6(?:[0136]|2[24-6]|4[6-8]?|5[15-8])|80|9(?:0[1-3]|[19]|2\\d|3[1-6]|4[02568]?|5[2-4]|6[2-46]|72?|8[23]?))|3(?:3(?:2[79]|6|8[2578])|4(?:0[0-24-9]|[12]|3[5-8]?|4[24-7]|5[4-68]?|6[02-9]|7[126]|8[2379]?|9[1-36-8])|5(?:1|2[1245]|3[237]?|4[1-46-9]|6[2-4]|7[1-6]|8[2-5]?)|6[24]|7(?:[069]|1[1568]|2[15]|3[145]|4[13]|5[14-8]|7[2-57]|8[126])|8(?:[01]|2[15-7]|3[2578]?|4[13-6]|5[4-8]?|6[1-357-9]|7[36-8]?|8[5-8]?|9[124])))15)?", "9$1"], "AS": ["1", "011", "(?:[58]\\d\\d|684|900)\\d{7}", [10], 0, "1", 0, "([267]\\d{6})$|1", "684$1", 0, "684"], "AT": ["43", "00", "1\\d{3,12}|2\\d{6,12}|43(?:(?:0\\d|5[02-9])\\d{3,9}|2\\d{4,5}|[3467]\\d{4}|8\\d{4,6}|9\\d{4,7})|5\\d{4,12}|8\\d{7,12}|9\\d{8,12}|(?:[367]\\d|4[0-24-9])\\d{4,11}", [4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [["(\\d)(\\d{3,12})", "$1 $2", ["1(?:11|[2-9])"], "0$1"], ["(\\d{3})(\\d{2})", "$1 $2", ["517"], "0$1"], ["(\\d{2})(\\d{3,5})", "$1 $2", ["5[079]"], "0$1"], ["(\\d{3})(\\d{3,10})", "$1 $2", ["(?:31|4)6|51|6(?:48|5[0-3579]|[6-9])|7(?:20|32|8)|[89]", "(?:31|4)6|51|6(?:485|5[0-3579]|[6-9])|7(?:20|32|8)|[89]"], "0$1"], ["(\\d{4})(\\d{3,9})", "$1 $2", ["[2-467]|5[2-6]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["5"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4,7})", "$1 $2 $3", ["5"], "0$1"]], "0"], "AU": ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{7}(?:\\d(?:\\d{2})?)?|8[0-24-9]\\d{7})|[2-478]\\d{8}|1\\d{4,7}", [5, 6, 7, 8, 9, 10, 12], [["(\\d{2})(\\d{3,4})", "$1 $2", ["16"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2,4})", "$1 $2 $3", ["16"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["14|4"], "0$1"], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["[2378]"], "(0$1)"], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1(?:30|[89])"]]], "0", 0, "(183[12])|0", 0, 0, 0, [["(?:(?:241|349)0\\d\\d|8(?:51(?:0(?:0[03-9]|[12479]\\d|3[2-9]|5[0-8]|6[1-9]|8[0-7])|1(?:[0235689]\\d|1[0-69]|4[0-589]|7[0-47-9])|2(?:0[0-79]|[18][13579]|2[14-9]|3[0-46-9]|[4-6]\\d|7[89]|9[0-4])|[34]\\d\\d)|91(?:(?:[0-58]\\d|6[0135-9])\\d|7(?:0[0-24-9]|[1-9]\\d)|9(?:[0-46-9]\\d|5[0-79]))))\\d{3}|(?:2(?:[0-26-9]\\d|3[0-8]|4[02-9]|5[0135-9])|3(?:[0-3589]\\d|4[0-578]|6[1-9]|7[0-35-9])|7(?:[013-57-9]\\d|2[0-8])|8(?:55|6[0-8]|[78]\\d|9[02-9]))\\d{6}", [9]], ["4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}", [9]], ["180(?:0\\d{3}|2)\\d{3}", [7, 10]], ["190[0-26]\\d{6}", [10]], 0, 0, 0, ["163\\d{2,6}", [5, 6, 7, 8, 9]], ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]], ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]], "0011"], "AW": ["297", "00", "(?:[25-79]\\d\\d|800)\\d{4}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[25-9]"]]]], "AX": ["358", "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))", "2\\d{4,9}|35\\d{4,5}|(?:60\\d\\d|800)\\d{4,6}|7\\d{5,11}|(?:[14]\\d|3[0-46-9]|50)\\d{4,8}", [5, 6, 7, 8, 9, 10, 11, 12], 0, "0", 0, 0, 0, 0, "18", 0, "00"], "AZ": ["994", "00", "365\\d{6}|(?:[124579]\\d|60|88)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["90"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[28]|2|365|46", "1[28]|2|365[45]|46", "1[28]|2|365(?:4|5[02])|46"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[13-9]"], "0$1"]], "0"], "BA": ["387", "00", "6\\d{8}|(?:[35689]\\d|49|70)\\d{6}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["6[1-3]|[7-9]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2-$3", ["[3-5]|6[56]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["6"], "0$1"]], "0"], "BB": ["1", "011", "(?:246|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "246$1", 0, "246"], "BD": ["880", "00", "[1-469]\\d{9}|8[0-79]\\d{7,8}|[2-79]\\d{8}|[2-9]\\d{7}|[3-9]\\d{6}|[57-9]\\d{5}", [6, 7, 8, 9, 10], [["(\\d{2})(\\d{4,6})", "$1-$2", ["31[5-8]|[459]1"], "0$1"], ["(\\d{3})(\\d{3,7})", "$1-$2", ["3(?:[67]|8[013-9])|4(?:6[168]|7|[89][18])|5(?:6[128]|9)|6(?:[15]|28)|7[2-589]|8(?:0[014-9]|[12])|9[358]|(?:3[2-5]|4[235]|5[2-578]|6[0389]|76|8[3-7]|9[24])1|(?:44|66)[01346-9]"], "0$1"], ["(\\d{4})(\\d{3,6})", "$1-$2", ["[13-9]|2[23]"], "0$1"], ["(\\d)(\\d{7,8})", "$1-$2", ["2"], "0$1"]], "0"], "BE": ["32", "00", "4\\d{8}|[1-9]\\d{7}", [8, 9], [["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["(?:80|9)0"], "0$1"], ["(\\d)(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[239]|4[23]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[15-8]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["4"], "0$1"]], "0"], "BF": ["226", "00", "[024-7]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[024-7]"]]]], "BG": ["359", "00", "00800\\d{7}|[2-7]\\d{6,7}|[89]\\d{6,8}|2\\d{5}", [6, 7, 8, 9, 12], [["(\\d)(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["2"], "0$1"], ["(\\d{3})(\\d{4})", "$1 $2", ["43[1-6]|70[1-9]"], "0$1"], ["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2,3})", "$1 $2 $3", ["[356]|4[124-7]|7[1-9]|8[1-6]|9[1-7]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["(?:70|8)0"], "0$1"], ["(\\d{3})(\\d{3})(\\d{2})", "$1 $2 $3", ["43[1-7]|7"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[48]|9[08]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"], "0$1"]], "0"], "BH": ["973", "00", "[136-9]\\d{7}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["[13679]|8[02-4679]"]]]], "BI": ["257", "00", "(?:[267]\\d|31)\\d{6}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2367]"]]]], "BJ": ["229", "00", "(?:01\\d|8)\\d{7}", [8, 10], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["0"]]]], "BL": ["590", "00", "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}", [9], 0, "0", 0, 0, 0, 0, 0, [["(?:59(?:0(?:2[7-9]|3[3-7]|5[12]|87)|87\\d)|80[6-9]\\d\\d)\\d{4}"], ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"], ["80[0-5]\\d{6}"], ["8[129]\\d{7}"], 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]]], "BM": ["1", "011", "(?:441|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "441$1", 0, "441"], "BN": ["673", "00", "[2-578]\\d{6}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[2-578]"]]]], "BO": ["591", "00(?:1\\d)?", "(?:[2-7]\\d\\d|8001)\\d{5}", [8, 9], [["(\\d)(\\d{7})", "$1 $2", ["[23]|4[46]|50"]], ["(\\d{8})", "$1", ["[5-7]"]], ["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["8"]]], "0", 0, "0(1\\d)?"], "BQ": ["599", "00", "(?:[34]1|7\\d)\\d{5}", [7], 0, 0, 0, 0, 0, 0, "[347]"], "BR": ["55", "00(?:1[245]|2[1-35]|31|4[13]|[56]5|99)", "[1-467]\\d{9,10}|55[0-46-9]\\d{8}|[34]\\d{7}|55\\d{7,8}|(?:5[0-46-9]|[89]\\d)\\d{7,9}", [8, 9, 10, 11], [["(\\d{4})(\\d{4})", "$1-$2", ["300|4(?:0[02]|37|86)", "300|4(?:0(?:0|20)|370|864)"]], ["(\\d{3})(\\d{2,3})(\\d{4})", "$1 $2 $3", ["(?:[358]|90)0"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2-$3", ["(?:[14689][1-9]|2[12478]|3[1-578]|5[13-5]|7[13-579])[2-57]"], "($1)"], ["(\\d{2})(\\d{5})(\\d{4})", "$1 $2-$3", ["[16][1-9]|[2-57-9]"], "($1)"]], "0", 0, "(?:0|90)(?:(1[245]|2[1-35]|31|4[13]|[56]5|99)(\\d{10,11}))?", "$2"], "BS": ["1", "011", "(?:242|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([3-8]\\d{6})$|1", "242$1", 0, "242"], "BT": ["975", "00", "[178]\\d{7}|[2-8]\\d{6}", [7, 8], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-6]|7[246]|8[2-4]"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[67]|[78]"]]]], "BW": ["267", "00", "(?:0800|(?:[37]|800)\\d)\\d{6}|(?:[2-6]\\d|90)\\d{5}", [7, 8, 10], [["(\\d{2})(\\d{5})", "$1 $2", ["90"]], ["(\\d{3})(\\d{4})", "$1 $2", ["[24-6]|3[15-9]"]], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[37]"]], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["0"]], ["(\\d{3})(\\d{4})(\\d{3})", "$1 $2 $3", ["8"]]]], "BY": ["375", "810", "(?:[12]\\d|33|44|902)\\d{7}|8(?:0[0-79]\\d{5,7}|[1-7]\\d{9})|8(?:1[0-489]|[5-79]\\d)\\d{7}|8[1-79]\\d{6,7}|8[0-79]\\d{5}|8\\d{5}", [6, 7, 8, 9, 10, 11], [["(\\d{3})(\\d{3})", "$1 $2", ["800"], "8 $1"], ["(\\d{3})(\\d{2})(\\d{2,4})", "$1 $2 $3", ["800"], "8 $1"], ["(\\d{4})(\\d{2})(\\d{3})", "$1 $2-$3", ["1(?:5[169]|6[3-5]|7[179])|2(?:1[35]|2[34]|3[3-5])", "1(?:5[169]|6(?:3[1-3]|4|5[125])|7(?:1[3-9]|7[0-24-6]|9[2-7]))|2(?:1[35]|2[34]|3[3-5])"], "8 0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["1(?:[56]|7[467])|2[1-3]"], "8 0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[1-4]"], "8 0$1"], ["(\\d{3})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["[89]"], "8 $1"]], "8", 0, "0|80?", 0, 0, 0, 0, "8~10"], "BZ": ["501", "00", "(?:0800\\d|[2-8])\\d{6}", [7, 11], [["(\\d{3})(\\d{4})", "$1-$2", ["[2-8]"]], ["(\\d)(\\d{3})(\\d{4})(\\d{3})", "$1-$2-$3-$4", ["0"]]]], "CA": ["1", "011", "[2-9]\\d{9}|3\\d{6}", [7, 10], 0, "1", 0, 0, 0, 0, 0, [["(?:2(?:04|[23]6|[48]9|5[07]|[67]3)|3(?:06|43|54|6[578]|82)|4(?:03|1[68]|[26]8|3[178]|50|74)|5(?:06|1[49]|48|79|8[147])|6(?:04|[18]3|39|47|72)|7(?:0[59]|42|53|78|8[02])|8(?:[06]7|19|25|7[39])|9(?:0[25]|42))[2-9]\\d{6}", [10]], ["", [10]], ["8(?:00|33|44|55|66|77|88)[2-9]\\d{6}", [10]], ["900[2-9]\\d{6}", [10]], ["52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|(?:5(?:2[125-9]|3[23]|44|66|77|88)|6(?:22|33))[2-9]\\d{6}", [10]], 0, ["310\\d{4}", [7]], 0, ["600[2-9]\\d{6}", [10]]]], "CC": ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}", [6, 7, 8, 9, 10, 12], 0, "0", 0, "([59]\\d{7})$|0", "8$1", 0, 0, [["8(?:51(?:0(?:02|31|60|89)|1(?:18|76)|223)|91(?:0(?:1[0-2]|29)|1(?:[28]2|50|79)|2(?:10|64)|3(?:[06]8|22)|4[29]8|62\\d|70[23]|959))\\d{3}", [9]], ["4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}", [9]], ["180(?:0\\d{3}|2)\\d{3}", [7, 10]], ["190[0-26]\\d{6}", [10]], 0, 0, 0, 0, ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]], ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]], "0011"], "CD": ["243", "00", "(?:(?:[189]|5\\d)\\d|2)\\d{7}|[1-68]\\d{6}", [7, 8, 9, 10], [["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["88"], "0$1"], ["(\\d{2})(\\d{5})", "$1 $2", ["[1-6]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[89]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["5"], "0$1"]], "0"], "CF": ["236", "00", "8776\\d{4}|(?:[27]\\d|61)\\d{6}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[26-8]"]]]], "CG": ["242", "00", "222\\d{6}|(?:0\\d|80)\\d{7}", [9], [["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["8"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[02]"]]]], "CH": ["41", "00", "8\\d{11}|[2-9]\\d{8}", [9, 12], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8[047]|90"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-79]|81"], "0$1"], ["(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["8"], "0$1"]], "0"], "CI": ["225", "00", "[02]\\d{9}", [10], [["(\\d{2})(\\d{2})(\\d)(\\d{5})", "$1 $2 $3 $4", ["2"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3 $4", ["0"]]]], "CK": ["682", "00", "[2-578]\\d{4}", [5], [["(\\d{2})(\\d{3})", "$1 $2", ["[2-578]"]]]], "CL": ["56", "(?:0|1(?:1[0-69]|2[02-5]|5[13-58]|69|7[0167]|8[018]))0", "12300\\d{6}|6\\d{9,10}|[2-9]\\d{8}", [9, 10, 11], [["(\\d{5})(\\d{4})", "$1 $2", ["219", "2196"], "($1)"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["60|809"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["44"]], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2[1-36]"], "($1)"], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["9(?:10|[2-9])"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["3[2-5]|[47]|5[1-3578]|6[13-57]|8(?:0[1-8]|[1-9])"], "($1)"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["60|8"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]], ["(\\d{3})(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["60"]]]], "CM": ["237", "00", "[26]\\d{8}|88\\d{6,7}", [8, 9], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["88"]], ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[26]|88"]]]], "CN": ["86", "00|1(?:[12]\\d|79)\\d\\d00", "(?:(?:1[03-689]|2\\d)\\d\\d|6)\\d{8}|1\\d{10}|[126]\\d{6}(?:\\d(?:\\d{2})?)?|86\\d{5,6}|(?:[3-579]\\d|8[0-57-9])\\d{5,9}", [7, 8, 9, 10, 11, 12], [["(\\d{2})(\\d{5,6})", "$1 $2", ["(?:10|2[0-57-9])[19]|3(?:[157]|35|49|9[1-68])|4(?:1[124-9]|2[179]|6[47-9]|7|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:07|1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3|4[13]|5[1-5]|7[0-79]|9[0-35-9])|(?:4[35]|59|85)[1-9]", "(?:10|2[0-57-9])(?:1[02]|9[56])|8078|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))1", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|80781|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))12", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|807812|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123", "10(?:1(?:0|23)|9[56])|2[0-57-9](?:1(?:00|23)|9[56])|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:1[124-9]|2[179]|[35][1-9]|6[47-9]|7\\d|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:078|1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|3\\d|4[13]|5[1-5]|7[0-79]|9[0-35-9]))123"], "0$1"], ["(\\d{3})(\\d{5,6})", "$1 $2", ["3(?:[157]|35|49|9[1-68])|4(?:[17]|2[179]|6[47-9]|8[23])|5(?:[1357]|2[37]|4[36]|6[1-46]|80)|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]|4[13]|5[1-5])|(?:4[35]|59|85)[1-9]", "(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[1-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))[19]", "85[23](?:10|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:10|9[56])", "85[23](?:100|95)|(?:3(?:[157]\\d|35|49|9[1-68])|4(?:[17]\\d|2[179]|[35][1-9]|6[47-9]|8[23])|5(?:[1357]\\d|2[37]|4[36]|6[1-46]|80|9[1-9])|6(?:3[1-5]|6[0238]|9[12])|7(?:01|[1579]\\d|2[248]|3[014-9]|4[3-6]|6[023689])|8(?:1[236-8]|2[5-7]|[37]\\d|5[14-9]|8[36-8]|9[1-8])|9(?:0[1-3689]|1[1-79]|[379]\\d|4[13]|5[1-5]))(?:100|9[56])"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["(?:4|80)0"]], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["10|2(?:[02-57-9]|1[1-9])", "10|2(?:[02-57-9]|1[1-9])", "10[0-79]|2(?:[02-57-9]|1[1-79])|(?:10|21)8(?:0[1-9]|[1-9])"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["3(?:[3-59]|7[02-68])|4(?:[26-8]|3[3-9]|5[2-9])|5(?:3[03-9]|[468]|7[028]|9[2-46-9])|6|7(?:[0-247]|3[04-9]|5[0-4689]|6[2368])|8(?:[1-358]|9[1-7])|9(?:[013479]|5[1-5])|(?:[34]1|55|79|87)[02-9]"], "0$1", 1], ["(\\d{3})(\\d{7,8})", "$1 $2", ["9"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["80"], "0$1", 1], ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["[3-578]"], "0$1", 1], ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["1[3-9]"]], ["(\\d{2})(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["[12]"], "0$1", 1]], "0", 0, "(1(?:[12]\\d|79)\\d\\d)|0", 0, 0, 0, 0, "00"], "CO": ["57", "00(?:4(?:[14]4|56)|[579])", "(?:46|60\\d\\d)\\d{6}|(?:1\\d|[39])\\d{9}", [8, 10, 11], [["(\\d{4})(\\d{4})", "$1 $2", ["46"]], ["(\\d{3})(\\d{7})", "$1 $2", ["6|90"], "($1)"], ["(\\d{3})(\\d{7})", "$1 $2", ["3[0-357]|9[14]"]], ["(\\d)(\\d{3})(\\d{7})", "$1-$2-$3", ["1"], "0$1", 0, "$1 $2 $3"]], "0", 0, "0([3579]|4(?:[14]4|56))?"], "CR": ["506", "00", "(?:8\\d|90)\\d{8}|(?:[24-8]\\d{3}|3005)\\d{4}", [8, 10], [["(\\d{4})(\\d{4})", "$1 $2", ["[2-7]|8[3-9]"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["[89]"]]], 0, 0, "(19(?:0[0-2468]|1[09]|20|66|77|99))"], "CU": ["53", "119", "(?:[2-7]|8\\d\\d)\\d{7}|[2-47]\\d{6}|[34]\\d{5}", [6, 7, 8, 10], [["(\\d{2})(\\d{4,6})", "$1 $2", ["2[1-4]|[34]"], "(0$1)"], ["(\\d)(\\d{6,7})", "$1 $2", ["7"], "(0$1)"], ["(\\d)(\\d{7})", "$1 $2", ["[56]"], "0$1"], ["(\\d{3})(\\d{7})", "$1 $2", ["8"], "0$1"]], "0"], "CV": ["238", "0", "(?:[2-59]\\d\\d|800)\\d{4}", [7], [["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2-589]"]]]], "CW": ["599", "00", "(?:[34]1|60|(?:7|9\\d)\\d)\\d{5}", [7, 8], [["(\\d{3})(\\d{4})", "$1 $2", ["[3467]"]], ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["9[4-8]"]]], 0, 0, 0, 0, 0, "[69]"], "CX": ["61", "001[14-689]|14(?:1[14]|34|4[17]|[56]6|7[47]|88)0011", "1(?:[0-79]\\d{8}(?:\\d{2})?|8[0-24-9]\\d{7})|[148]\\d{8}|1\\d{5,7}", [6, 7, 8, 9, 10, 12], 0, "0", 0, "([59]\\d{7})$|0", "8$1", 0, 0, [["8(?:51(?:0(?:01|30|59|88)|1(?:17|46|75)|2(?:22|35))|91(?:00[6-9]|1(?:[28]1|49|78)|2(?:09|63)|3(?:12|26|75)|4(?:56|97)|64\\d|7(?:0[01]|1[0-2])|958))\\d{3}", [9]], ["4(?:79[01]|83[0-36-9]|95[0-3])\\d{5}|4(?:[0-36]\\d|4[047-9]|[58][0-24-9]|7[02-8]|9[0-47-9])\\d{6}", [9]], ["180(?:0\\d{3}|2)\\d{3}", [7, 10]], ["190[0-26]\\d{6}", [10]], 0, 0, 0, 0, ["14(?:5(?:1[0458]|[23][458])|71\\d)\\d{4}", [9]], ["13(?:00\\d{6}(?:\\d{2})?|45[0-4]\\d{3})|13\\d{4}", [6, 8, 10, 12]]], "0011"], "CY": ["357", "00", "(?:[279]\\d|[58]0)\\d{6}", [8], [["(\\d{2})(\\d{6})", "$1 $2", ["[257-9]"]]]], "CZ": ["420", "00", "(?:[2-578]\\d|60)\\d{7}|9\\d{8,11}", [9, 10, 11, 12], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-8]|9[015-7]"]], ["(\\d{2})(\\d{3})(\\d{3})(\\d{2})", "$1 $2 $3 $4", ["96"]], ["(\\d{2})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]], ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]]]], "DE": ["49", "00", "[2579]\\d{5,14}|49(?:[34]0|69|8\\d)\\d\\d?|49(?:37|49|60|7[089]|9\\d)\\d{1,3}|49(?:2[024-9]|3[2-689]|7[1-7])\\d{1,8}|(?:1|[368]\\d|4[0-8])\\d{3,13}|49(?:[015]\\d|2[13]|31|[46][1-8])\\d{1,9}", [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], [["(\\d{2})(\\d{3,13})", "$1 $2", ["3[02]|40|[68]9"], "0$1"], ["(\\d{3})(\\d{3,12})", "$1 $2", ["2(?:0[1-389]|1[124]|2[18]|3[14])|3(?:[35-9][15]|4[015])|906|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1", "2(?:0[1-389]|12[0-8])|3(?:[35-9][15]|4[015])|906|2(?:[13][14]|2[18])|(?:2[4-9]|4[2-9]|[579][1-9]|[68][1-8])1"], "0$1"], ["(\\d{4})(\\d{2,11})", "$1 $2", ["[24-6]|3(?:[3569][02-46-9]|4[2-4679]|7[2-467]|8[2-46-8])|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]", "[24-6]|3(?:3(?:0[1-467]|2[127-9]|3[124578]|7[1257-9]|8[1256]|9[145])|4(?:2[135]|4[13578]|9[1346])|5(?:0[14]|2[1-3589]|6[1-4]|7[13468]|8[13568])|6(?:2[1-489]|3[124-6]|6[13]|7[12579]|8[1-356]|9[135])|7(?:2[1-7]|4[145]|6[1-5]|7[1-4])|8(?:21|3[1468]|6|7[1467]|8[136])|9(?:0[12479]|2[1358]|4[134679]|6[1-9]|7[136]|8[147]|9[1468]))|70[2-8]|8(?:0[2-9]|[1-8])|90[7-9]|[79][1-9]|3[68]4[1347]|3(?:47|60)[1356]|3(?:3[46]|46|5[49])[1246]|3[4579]3[1357]"], "0$1"], ["(\\d{3})(\\d{4})", "$1 $2", ["138"], "0$1"], ["(\\d{5})(\\d{2,10})", "$1 $2", ["3"], "0$1"], ["(\\d{3})(\\d{5,11})", "$1 $2", ["181"], "0$1"], ["(\\d{3})(\\d)(\\d{4,10})", "$1 $2 $3", ["1(?:3|80)|9"], "0$1"], ["(\\d{3})(\\d{7,8})", "$1 $2", ["1[67]"], "0$1"], ["(\\d{3})(\\d{7,12})", "$1 $2", ["8"], "0$1"], ["(\\d{5})(\\d{6})", "$1 $2", ["185", "1850", "18500"], "0$1"], ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["7"], "0$1"], ["(\\d{4})(\\d{7})", "$1 $2", ["18[68]"], "0$1"], ["(\\d{4})(\\d{7})", "$1 $2", ["15[1279]"], "0$1"], ["(\\d{5})(\\d{6})", "$1 $2", ["15[03568]", "15(?:[0568]|3[13])"], "0$1"], ["(\\d{3})(\\d{8})", "$1 $2", ["18"], "0$1"], ["(\\d{3})(\\d{2})(\\d{7,8})", "$1 $2 $3", ["1(?:6[023]|7)"], "0$1"], ["(\\d{4})(\\d{2})(\\d{7})", "$1 $2 $3", ["15[279]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{8})", "$1 $2 $3", ["15"], "0$1"]], "0"], "DJ": ["253", "00", "(?:2\\d|77)\\d{6}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[27]"]]]], "DK": ["45", "00", "[2-9]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-9]"]]]], "DM": ["1", "011", "(?:[58]\\d\\d|767|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "767$1", 0, "767"], "DO": ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "8001|8[024]9"], "DZ": ["213", "00", "(?:[1-4]|[5-79]\\d|80)\\d{7}", [8, 9], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[1-4]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["9"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-8]"], "0$1"]], "0"], "EC": ["593", "00", "1\\d{9,10}|(?:[2-7]|9\\d)\\d{7}", [8, 9, 10, 11], [["(\\d)(\\d{3})(\\d{4})", "$1 $2-$3", ["[2-7]"], "(0$1)", 0, "$1-$2-$3"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["9"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["1"]]], "0"], "EE": ["372", "00", "8\\d{9}|[4578]\\d{7}|(?:[3-8]\\d|90)\\d{5}", [7, 8, 10], [["(\\d{3})(\\d{4})", "$1 $2", ["[369]|4[3-8]|5(?:[0-2]|5[0-478]|6[45])|7[1-9]|88", "[369]|4[3-8]|5(?:[02]|1(?:[0-8]|95)|5[0-478]|6(?:4[0-4]|5[1-589]))|7[1-9]|88"]], ["(\\d{4})(\\d{3,4})", "$1 $2", ["[45]|8(?:00|[1-49])", "[45]|8(?:00[1-9]|[1-49])"]], ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["7"]], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]]]], "EG": ["20", "00", "[189]\\d{8,9}|[24-6]\\d{8}|[135]\\d{7}", [8, 9, 10], [["(\\d)(\\d{7,8})", "$1 $2", ["[23]"], "0$1"], ["(\\d{2})(\\d{6,7})", "$1 $2", ["1[35]|[4-6]|8[2468]|9[235-7]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"], ["(\\d{2})(\\d{8})", "$1 $2", ["1"], "0$1"]], "0"], "EH": ["212", "00", "[5-8]\\d{8}", [9], 0, "0", 0, 0, 0, 0, 0, [["528[89]\\d{5}"], ["(?:6(?:[0-79]\\d|8[0-247-9])|7(?:[016-8]\\d|2[0-8]|3[01]|5[0-5]))\\d{6}"], ["80[0-7]\\d{6}"], ["89\\d{7}"], 0, 0, 0, 0, ["(?:592(?:4[0-2]|93)|80[89]\\d\\d)\\d{4}"]]], "ER": ["291", "00", "[178]\\d{6}", [7], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[178]"], "0$1"]], "0"], "ES": ["34", "00", "(?:400|[5-9]\\d\\d)\\d{6}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[89]00"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[4-9]"]]]], "ET": ["251", "00", "(?:11|[2-57-9]\\d)\\d{7}", [9], [["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-57-9]"], "0$1"]], "0"], "FI": ["358", "00|99(?:[01469]|5(?:[14]1|3[23]|5[59]|77|88|9[09]))", "[1-35689]\\d{4}|7\\d{10,11}|(?:[124-7]\\d|3[0-46-9])\\d{8}|[1-9]\\d{5,8}", [5, 6, 7, 8, 9, 10, 11, 12], [["(\\d{5})", "$1", ["20[2-59]"], "0$1"], ["(\\d{3})(\\d{3,7})", "$1 $2", ["(?:[1-3]0|[68])0|70[07-9]"], "0$1"], ["(\\d{2})(\\d{4,8})", "$1 $2", ["[14]|2[09]|50|7[135]"], "0$1"], ["(\\d{2})(\\d{6,10})", "$1 $2", ["7"], "0$1"], ["(\\d)(\\d{4,9})", "$1 $2", ["(?:19|[2568])[1-8]|3(?:0[1-9]|[1-9])|9"], "0$1"]], "0", 0, 0, 0, 0, "1[03-79]|[2-9]", 0, "00"], "FJ": ["679", "0(?:0|52)", "45\\d{5}|(?:0800\\d|[235-9])\\d{6}", [7, 11], [["(\\d{3})(\\d{4})", "$1 $2", ["[235-9]|45"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["0"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "FK": ["500", "00", "[2-7]\\d{4}", [5]], "FM": ["691", "00", "(?:[39]\\d\\d|820)\\d{4}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[389]"]]]], "FO": ["298", "00", "[2-9]\\d{5}", [6], [["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2-9]"]]], 0, 0, "(10(?:01|[12]0|88))"], "FR": ["33", "00", "[1-9]\\d{8}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0 $1"], ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[1-79]"], "0$1"]], "0"], "GA": ["241", "00", "(?:[067]\\d|11)\\d{6}|[2-7]\\d{6}", [7, 8], [["(\\d)(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-7]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["0"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["11|[67]"], "0$1"]], 0, 0, "0(11\\d{6}|60\\d{6}|61\\d{6}|6[256]\\d{6}|7[467]\\d{6})", "$1"], "GB": ["44", "00", "[1-357-9]\\d{9}|[18]\\d{8}|8\\d{6}", [7, 9, 10], [["(\\d{3})(\\d{4})", "$1 $2", ["800", "8001", "80011", "800111", "8001111"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["845", "8454", "84546", "845464"], "0$1"], ["(\\d{3})(\\d{6})", "$1 $2", ["800"], "0$1"], ["(\\d{5})(\\d{4,5})", "$1 $2", ["1(?:38|5[23]|69|76|94)", "1(?:(?:38|69)7|5(?:24|39)|768|946)", "1(?:3873|5(?:242|39[4-6])|(?:697|768)[347]|9467)"], "0$1"], ["(\\d{4})(\\d{5,6})", "$1 $2", ["1(?:[2-69][02-9]|[78])"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["[25]|7(?:0|6[02-9])", "[25]|7(?:0|6(?:[03-9]|2[356]))"], "0$1"], ["(\\d{4})(\\d{6})", "$1 $2", ["7"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1389]"], "0$1"]], "0", 0, "0|180020", 0, 0, 0, [["(?:1(?:1(?:3(?:[0-58]\\d\\d|73[0-5])|4(?:(?:[0-5]\\d|70)\\d|69[7-9])|(?:(?:5[0-26-9]|[78][0-49])\\d|6(?:[0-4]\\d|5[01]))\\d)|(?:2(?:(?:0[024-9]|2[3-9]|3[3-79]|4[1-689]|[58][02-9]|6[0-47-9]|7[013-9]|9\\d)\\d|1(?:[0-7]\\d|8[0-3]))|(?:3(?:0\\d|1[0-8]|[25][02-9]|3[02-579]|[468][0-46-9]|7[1-35-79]|9[2-578])|4(?:0[03-9]|[137]\\d|[28][02-57-9]|4[02-69]|5[0-8]|[69][0-79])|5(?:0[1-35-9]|[16]\\d|2[024-9]|3[015689]|4[02-9]|5[03-9]|7[0-35-9]|8[0-468]|9[0-57-9])|6(?:0[034689]|1\\d|2[0-35689]|[38][013-9]|4[1-467]|5[0-69]|6[13-9]|7[0-8]|9[0-24578])|7(?:0[0246-9]|2\\d|3[0236-8]|4[03-9]|5[0-46-9]|6[013-9]|7[0-35-9]|8[024-9]|9[02-9])|8(?:0[35-9]|2[1-57-9]|3[02-578]|4[0-578]|5[124-9]|6[2-69]|7\\d|8[02-9]|9[02569])|9(?:0[02-589]|[18]\\d|2[02-689]|3[1-57-9]|4[2-9]|5[0-579]|6[2-47-9]|7[0-24578]|9[2-57]))\\d)\\d)|2(?:0[013478]|3[0189]|4[017]|8[0-46-9]|9[0-2])\\d{3})\\d{4}|1(?:2(?:0(?:46[1-4]|87[2-9])|545[1-79]|76(?:2\\d|3[1-8]|6[1-6])|9(?:7(?:2[0-4]|3[2-5])|8(?:2[2-8]|7[0-47-9]|8[3-5])))|3(?:6(?:38[2-5]|47[23])|8(?:47[04-9]|64[0157-9]))|4(?:044[1-7]|20(?:2[23]|8\\d)|6(?:0(?:30|5[2-57]|6[1-8]|7[2-8])|140)|8(?:052|87[1-3]))|5(?:2(?:4(?:3[2-79]|6\\d)|76\\d)|6(?:26[06-9]|686))|6(?:06(?:4\\d|7[4-79])|295[5-7]|35[34]\\d|47(?:24|61)|59(?:5[08]|6[67]|74)|9(?:55[0-4]|77[23]))|7(?:26(?:6[13-9]|7[0-7])|(?:442|688)\\d|50(?:2[0-3]|[3-68]2|76))|8(?:27[56]\\d|37(?:5[2-5]|8[239])|843[2-58])|9(?:0(?:0(?:6[1-8]|85)|52\\d)|3583|4(?:66[1-8]|9(?:2[01]|81))|63(?:23|3[1-4])|9561))\\d{3}", [9, 10]], ["7(?:457[0-57-9]|700[01]|911[028])\\d{5}|7(?:[1-3]\\d\\d|4(?:[0-46-9]\\d|5[0-689])|5(?:0[0-8]|[13-9]\\d|2[0-35-9])|7(?:0[1-9]|[1-7]\\d|8[02-9]|9[0-689])|8(?:[014-9]\\d|[23][0-8])|9(?:[024-9]\\d|1[02-9]|3[0-689]))\\d{6}", [10]], ["80[08]\\d{7}|800\\d{6}|8001111"], ["(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[2-49]))\\d{7}|845464\\d", [7, 10]], ["70\\d{8}", [10]], 0, ["(?:3[0347]|55)\\d{8}", [10]], ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}", [10]], ["56\\d{8}", [10]]], 0, " x"], "GD": ["1", "011", "(?:473|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "473$1", 0, "473"], "GE": ["995", "00", "(?:[3-57]\\d\\d|800)\\d{6}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["70"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["32"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[57]"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[348]"], "0$1"]], "0"], "GF": ["594", "00", "(?:694\\d|7093)\\d{5}|(?:59|[89]\\d)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-7]|80[6-9]|9[47]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[89]"], "0$1"]], "0"], "GG": ["44", "00", "(?:1481|[357-9]\\d{3})\\d{6}|8\\d{6}(?:\\d{2})?", [7, 9, 10], 0, "0", 0, "([25-9]\\d{5})$|0|180020", "1481$1", 0, 0, [["1481[25-9]\\d{5}", [10]], ["7(?:(?:781|839)\\d|911[17])\\d{5}", [10]], ["80[08]\\d{7}|800\\d{6}|8001111"], ["(?:8(?:4[2-5]|7[0-3])|9(?:[01]\\d|8[0-3]))\\d{7}|845464\\d", [7, 10]], ["70\\d{8}", [10]], 0, ["(?:3[0347]|55)\\d{8}", [10]], ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}", [10]], ["56\\d{8}", [10]]]], "GH": ["233", "00", "[235]\\d{8}|800\\d{5,6}", [8, 9], [["(\\d{3})(\\d{5})", "$1 $2", ["8"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2358]"], "0$1"]], "0"], "GI": ["350", "00", "(?:[25]\\d|60)\\d{6}", [8], [["(\\d{3})(\\d{5})", "$1 $2", ["2"]]]], "GL": ["299", "00", "(?:19|[2-689]\\d|70)\\d{4}", [6], [["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["19|[2-9]"]]]], "GM": ["220", "00", "[48]\\d{8}|[2-9]\\d{6}", [7, 9], [["(\\d{3})(\\d{4})", "$1 $2", ["[235-9]|4(?:[0-35]|4[16-9])"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[48]"]]]], "GN": ["224", "00", "722\\d{6}|(?:3|6\\d)\\d{7}", [8, 9], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["3"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[67]"]]]], "GP": ["590", "00", "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-79]|80[6-9]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]], "0", 0, 0, 0, 0, 0, [["(?:59(?:0(?:0[1-68]|[14][0-24-9]|2[0-68]|3[1-9]|5[3-579]|[68][0-689]|7[08]|9\\d)|87\\d)|80[6-9]\\d\\d)\\d{4}"], ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"], ["80[0-5]\\d{6}"], ["8[129]\\d{7}"], 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]]], "GQ": ["240", "00", "222\\d{6}|(?:3\\d|55|[89]0)\\d{7}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235]"]], ["(\\d{3})(\\d{6})", "$1 $2", ["[89]"]]]], "GR": ["30", "00", "5005000\\d{3}|8\\d{9,11}|(?:[269]\\d|70)\\d{8}", [10, 11, 12], [["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["21|7"]], ["(\\d{4})(\\d{6})", "$1 $2", ["2(?:2|3[2-57-9]|4[2-469]|5[2-59]|6[2-9]|7[2-69]|8[2-49])|5"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2689]"]], ["(\\d{3})(\\d{3,4})(\\d{5})", "$1 $2 $3", ["8"]]]], "GT": ["502", "00", "80\\d{6}|(?:1\\d{3}|[2-7])\\d{7}", [8, 11], [["(\\d{4})(\\d{4})", "$1 $2", ["[2-8]"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]]]], "GU": ["1", "011", "(?:[58]\\d\\d|671|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "671$1", 0, "671"], "GW": ["245", "00", "[49]\\d{8}|4\\d{6}", [7, 9], [["(\\d{3})(\\d{4})", "$1 $2", ["40"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[49]"]]]], "GY": ["592", "001", "(?:[2-8]\\d{3}|9008)\\d{3}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[2-9]"]]]], "HK": ["852", "00(?:30|5[09]|[126-9]?)", "8[0-46-9]\\d{6,7}|9\\d{4,7}|(?:[2-7]|9\\d{3})\\d{7}", [5, 6, 7, 8, 9, 11], [["(\\d{3})(\\d{2,5})", "$1 $2", ["900", "9003"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[2-7]|8[1-4]|9(?:0[1-9]|[1-8])"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]], ["(\\d{3})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["9"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "HN": ["504", "00", "8\\d{10}|[237-9]\\d{7}", [8, 11], [["(\\d{4})(\\d{4})", "$1-$2", ["[237-9]"]]]], "HR": ["385", "00", "[2-69]\\d{8}|80\\d{5,7}|[1-79]\\d{7}|6\\d{6}", [7, 8, 9], [["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["6[01]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["8"], "0$1"], ["(\\d)(\\d{4})(\\d{3})", "$1 $2 $3", ["1"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["6|7[245]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["9"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-57]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"], "0$1"]], "0"], "HT": ["509", "00", "[2-589]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["[2-589]"]]]], "HU": ["36", "00", "[235-7]\\d{8}|[1-9]\\d{7}", [8, 9], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "(06 $1)"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[27][2-9]|3[2-7]|4[24-9]|5[2-79]|6|8[2-57-9]|9[2-69]"], "(06 $1)"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-9]"], "06 $1"]], "06"], "ID": ["62", "00[89]", "00[1-9]\\d{9,14}|(?:[1-36]|8\\d{5})\\d{6}|00\\d{9}|[1-9]\\d{8,10}|[2-9]\\d{7}", [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["15"]], ["(\\d{2})(\\d{5,9})", "$1 $2", ["2[124]|[36]1"], "(0$1)"], ["(\\d{3})(\\d{5,7})", "$1 $2", ["800"], "0$1"], ["(\\d{3})(\\d{5,8})", "$1 $2", ["[2-79]"], "(0$1)"], ["(\\d{3})(\\d{3,4})(\\d{3})", "$1-$2-$3", ["8[1-35-9]"], "0$1"], ["(\\d{3})(\\d{6,8})", "$1 $2", ["1"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["804"], "0$1"], ["(\\d{3})(\\d)(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["80"], "0$1"], ["(\\d{3})(\\d{4})(\\d{4,5})", "$1-$2-$3", ["8"], "0$1"]], "0"], "IE": ["353", "00", "(?:1\\d|[2569])\\d{6,8}|4\\d{6,9}|7\\d{8}|8\\d{8,9}", [7, 8, 9, 10], [["(\\d{2})(\\d{5})", "$1 $2", ["2[24-9]|47|58|6[237-9]|9[35-9]"], "(0$1)"], ["(\\d{3})(\\d{5})", "$1 $2", ["[45]0"], "(0$1)"], ["(\\d)(\\d{3,4})(\\d{4})", "$1 $2 $3", ["1"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2569]|4[1-69]|7[14]"], "(0$1)"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["70"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["81"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[78]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["4"], "(0$1)"], ["(\\d{2})(\\d)(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["8"], "0$1"]], "0"], "IL": ["972", "0(?:0|1(?:05|[2-9]))", "1\\d{6}(?:\\d{3,5})?|[57]\\d{8}|[1-489]\\d{7}", [7, 8, 9, 10, 11, 12], [["(\\d{4})(\\d{3})", "$1-$2", ["125"]], ["(\\d{4})(\\d{2})(\\d{2})", "$1-$2-$3", ["121"]], ["(\\d)(\\d{3})(\\d{4})", "$1-$2-$3", ["[2-489]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["[57]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3})", "$1-$2-$3", ["12"]], ["(\\d{4})(\\d{6})", "$1-$2", ["159"]], ["(\\d)(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3-$4", ["1[7-9]"]], ["(\\d{3})(\\d{1,2})(\\d{3})(\\d{4})", "$1-$2 $3-$4", ["15"]]], "0"], "IM": ["44", "00", "1624\\d{6}|(?:[3578]\\d|90)\\d{8}", [10], 0, "0", 0, "([25-8]\\d{5})$|0|180020", "1624$1", 0, "74576|(?:16|7[56])24"], "IN": ["91", "00", "(?:000800|[2-9]\\d\\d)\\d{7}|1\\d{7,12}", [8, 9, 10, 11, 12, 13], [["(\\d{8})", "$1", ["5(?:0|2[23]|3[03]|[67]1|88)", "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|888)", "5(?:0|2(?:21|3)|3(?:0|3[23])|616|717|8888)"], 0, 1], ["(\\d{4})(\\d{4,5})", "$1 $2", ["180", "1800"], 0, 1], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["140"], 0, 1], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["11|2[02]|33|4[04]|79[1-6]|80[2-46]", "11|2[02]|33|4[04]|79[1-6]|80(?:[2-4]|6[0-589])", "11|2[02]|33|4[04]|79(?:[124-6]|3(?:[02-9]|1[0-24-9]))|80(?:[2-4]|6[0-589])"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["1(?:2[0-249]|3[0-25]|4[145]|[68]|7[1257])|2(?:1[257]|3[013]|4[01]|5[0137]|6[0158]|78|8[1568])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|5[12]|[78]1)|6(?:12|[2-4]1|5[17]|6[13]|80)|7(?:12|3[134]|61|88)|8(?:16|2[014]|3[126]|6[136]|7[078]|8[34]|91)|(?:43|59|75)[15]|(?:1[59]|29|67)[14]", "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|674|7(?:(?:3[34]|5[15])[2-6]|61[346]|88[0-8])|8(?:70[2-6]|84[235-7]|91[3-7])|(?:1(?:29|60|8[06])|261|552|6(?:12|[2-47]1|5[17]|6[13]|80)|7(?:12|31)|8(?:16|2[014]|3[126]|6[136]|7[78]|83))[2-7]", "1(?:2[0-24]|3[0-25]|4[145]|[59][14]|6[1-9]|7[1257]|8[1-57-9])|2(?:1[257]|3[013]|4[01]|5[0137]|6[058]|78|8[1568]|9[14])|3(?:26|4[1-3]|5[34]|6[01489]|7[02-46]|8[159])|4(?:1[36]|2[1-47]|3[15]|5[12]|6[0-26-9]|7[0-24-9]|8[013-57]|9[014-7])|5(?:1[025]|22|[36][25]|4[28]|[578]1|9[15])|6(?:12(?:[2-6]|7[0-8])|74[2-7])|7(?:3171|5[15][2-6]|61[346]|88(?:[2-7]|82))|8(?:70[2-6]|84(?:[2356]|7[19])|91(?:[3-6]|7[19]))|73[134][2-6]|8(?:16|2[014]|3[126]|6[136]|7[78]|83)(?:[2-6]|7[19])|(?:1(?:29|60|8[06])|261|552|6(?:[2-4]1|5[17]|6[13]|7(?:1|4[0189])|80)|7(?:12|88[01]))[2-7]"], "0$1", 1], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2[2457-9]|3[2-5]|4[235-7]|5[2-689]|6[24578]|7[235689]|8[1-6])|7(?:1[013-9]|3[129]|5[29]|6[02-5]|70)|807", "1(?:[2-479]|5[0235-9])|[2-5]|6(?:1[1358]|2(?:[2457]|84|95)|3(?:[2-4]|55)|4[235-7]|5[2-689]|6[24578]|7(?:[23569]|8[0-57-9])|8[1-6])|7(?:1(?:[013-8]|9[6-9])|3(?:17|2[0-49]|9[2-57])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4|5[0-367])|70[13-7])|807[19]", "1(?:[2-479]|5(?:[0236-9]|5[013-9]))|[2-5]|6(?:2(?:84|95)|355|8(?:28[235-7]|3))|73179|807(?:1|9[1-3])|(?:1552|6(?:(?:1[1358]|2[2457]|3[2-4]|4[235-7]|5[2-689]|6[24578])\\d|7(?:[23569]\\d|8[0-57-9])|8(?:[14-6]\\d|2[0-79]))|7(?:1(?:[013-8]\\d|9[6-9])|3(?:2[0-49]|9[2-57])|5(?:2[1-3]|9[0-6])|6(?:0[5689]|2[5-9]|3[02-8]|4\\d|5[0-367])|70[13-7]))[2-7]"], "0$1", 1], ["(\\d{5})(\\d{5})", "$1 $2", ["16|[6-9]"], "0$1", 1], ["(\\d{4})(\\d{2,4})(\\d{4})", "$1 $2 $3", ["18[06]", "18[06]0"], 0, 1], ["(\\d{4})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["18"], 0, 1]], "0"], "IO": ["246", "00", "3\\d{6}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["3"]]]], "IQ": ["964", "00", "(?:1|7\\d\\d)\\d{7}|[2-6]\\d{7,8}", [8, 9, 10], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-6]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"]], "0"], "IR": ["98", "00", "[1-9]\\d{9}|(?:[1-8]\\d\\d|9)\\d{3,4}", [4, 5, 6, 7, 10], [["(\\d{4,5})", "$1", ["96"], "0$1"], ["(\\d{2})(\\d{4,5})", "$1 $2", ["(?:1[137]|2[13-68]|3[1458]|4[145]|5[1468]|6[16]|7[1467]|8[13467])[12689]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["9"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["[1-8]"], "0$1"]], "0"], "IS": ["354", "00|1(?:0(?:01|[12]0)|100)", "(?:38\\d|[4-9])\\d{6}", [7, 9], [["(\\d{3})(\\d{4})", "$1 $2", ["[4-9]"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["3"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "IT": ["39", "00", "0\\d{5,11}|1\\d{8,10}|3(?:[0-8]\\d{7,10}|9\\d{7,8})|(?:43|55|70)\\d{8}|8\\d{5}(?:\\d{2,4})?", [6, 7, 8, 9, 10, 11, 12], [["(\\d{2})(\\d{4,6})", "$1 $2", ["0[26]"]], ["(\\d{3})(\\d{3,6})", "$1 $2", ["0[13-57-9][0159]|8(?:03|4[17]|9[2-5])", "0[13-57-9][0159]|8(?:03|4[17]|9(?:2|3[04]|[45][0-4]))"]], ["(\\d{4})(\\d{2,6})", "$1 $2", ["0(?:[13-579][2-46-8]|8[236-8])"]], ["(\\d{4})(\\d{4})", "$1 $2", ["894"]], ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["0[26]|5"]], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["1(?:44|[679])|[378]|43"]], ["(\\d{3})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["0[13-57-9][0159]|14"]], ["(\\d{2})(\\d{4})(\\d{5})", "$1 $2 $3", ["0[26]"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["0"]], ["(\\d{3})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["[03]"]]], 0, 0, 0, 0, 0, 0, [["0(?:669[0-79]\\d{1,6}|831\\d{2,8})|0(?:1(?:[0159]\\d|[27][1-5]|31|4[1-4]|6[1356]|8[2-57])|2\\d\\d|3(?:[0159]\\d|2[1-4]|3[12]|[48][1-6]|6[2-59]|7[1-7])|4(?:[0159]\\d|[23][1-9]|4[245]|6[1-5]|7[1-4]|81)|5(?:[0159]\\d|2[1-5]|3[2-6]|4[1-79]|6[4-6]|7[1-578]|8[3-8])|6(?:[0-57-9]\\d|6[0-8])|7(?:[0159]\\d|2[12]|3[1-7]|4[2-46]|6[13569]|7[13-6]|8[1-59])|8(?:[0159]\\d|2[3-578]|3[2356]|[6-8][1-5])|9(?:[0159]\\d|[238][1-5]|4[12]|6[1-8]|7[1-6]))\\d{2,7}"], ["3[2-9]\\d{7,8}|(?:31|43)\\d{8}", [9, 10]], ["80(?:0\\d{3}|3)\\d{3}", [6, 9]], ["(?:0878\\d{3}|89(?:2\\d|3[04]|4(?:[0-4]|[5-9]\\d\\d)|5[0-4]))\\d\\d|(?:1(?:44|6[346])|89(?:38|5[5-9]|9))\\d{6}", [6, 8, 9, 10]], ["1(?:78\\d|99)\\d{6}", [9, 10]], ["3[2-8]\\d{9,10}", [11, 12]], 0, 0, ["55\\d{8}", [10]], ["84(?:[08]\\d{3}|[17])\\d{3}", [6, 9]]]], "JE": ["44", "00", "1534\\d{6}|(?:[3578]\\d|90)\\d{8}", [10], 0, "0", 0, "([0-24-8]\\d{5})$|0|180020", "1534$1", 0, 0, [["1534[0-24-8]\\d{5}"], ["7(?:(?:(?:50|82)9|937)\\d|7(?:00[378]|97\\d))\\d{5}"], ["80(?:07(?:35|81)|8901)\\d{4}"], ["(?:8(?:4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|90(?:066[59]|1810|71(?:07|55)))\\d{4}"], ["701511\\d{4}"], 0, ["(?:3(?:0(?:07(?:35|81)|8901)|3\\d{4}|4(?:4(?:4(?:05|42|69)|703)|5(?:041|800))|7(?:0002|1206))|55\\d{4})\\d{4}"], ["76(?:464|652)\\d{5}|76(?:0[0-28]|2[356]|34|4[01347]|5[49]|6[0-369]|77|8[14]|9[139])\\d{6}"], ["56\\d{8}"]]], "JM": ["1", "011", "(?:[58]\\d\\d|658|900)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "658|876"], "JO": ["962", "00", "(?:(?:[2689]|7\\d)\\d|32|427|53)\\d{6}", [8, 9], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2356]|87"], "(0$1)"], ["(\\d{3})(\\d{5,6})", "$1 $2", ["[89]"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["70"], "0$1"], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["[47]"], "0$1"]], "0"], "JP": ["81", "010", "00[1-9]\\d{6,14}|[25-9]\\d{9}|(?:00|[1-9]\\d\\d)\\d{6}", [8, 9, 10, 11, 12, 13, 14, 15, 16, 17], [["(\\d{3})(\\d{3})(\\d{3})", "$1-$2-$3", ["(?:12|57|99)0"], "0$1"], ["(\\d{4})(\\d)(\\d{4})", "$1-$2-$3", ["1(?:26|3[79]|4[56]|5[4-68]|6[3-5])|499|5(?:76|97)|746|8(?:3[89]|47|51)|9(?:80|9[16])", "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:76|97)9|7468|8(?:3(?:8[7-9]|96)|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]", "1(?:267|3(?:7[247]|9[278])|466|5(?:47|58|64)|6(?:3[245]|48|5[4-68]))|499[2468]|5(?:769|979[2-69])|7468|8(?:3(?:8[7-9]|96[2457-9])|477|51[2-9])|9(?:802|9(?:1[23]|69))|1(?:45|58)[67]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["60"], "0$1"], ["(\\d)(\\d{4})(\\d{4})", "$1-$2-$3", ["3|4(?:2[09]|7[01])|6[1-9]", "3|4(?:2(?:0|9[02-69])|7(?:0[019]|1))|6[1-9]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["1(?:1|5[45]|77|88|9[69])|2(?:2[1-37]|3[0-269]|4[59]|5|6[24]|7[1-358]|8[1369]|9[0-38])|4(?:[28][1-9]|3[0-57]|[45]|6[248]|7[2-579]|9[29])|5(?:2|3[0459]|4[0-369]|5[29]|8[02389]|9[0-389])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9[2-6])|8(?:2[124589]|3[26-9]|49|51|6|7[0-468]|8[68]|9[019])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9[1-489])", "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2(?:[127]|3[014-9])|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9[19])|62|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|8[1-9]|9[29])|5(?:2|3(?:[045]|9[0-8])|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0-2469])|3(?:[29]|60)|49|51|6(?:[0-24]|36|5[0-3589]|7[23]|9[01459])|7[0-468]|8[68])|9(?:[23][1-9]|4[15]|5[138]|6[1-3]|7[156]|8[189]|9(?:[1289]|3[34]|4[0178]))|(?:264|837)[016-9]|2(?:57|93)[015-9]|(?:25[0468]|422|838)[01]|(?:47[59]|59[89]|8(?:6[68]|9))[019]", "1(?:1|5(?:4[018]|5[017])|77|88|9[69])|2(?:2[127]|3[0-269]|4[59]|5(?:[1-3]|5[0-69]|9(?:17|99))|6(?:2|4[016-9])|7(?:[1-35]|8[0189])|8(?:[16]|3[0134]|9[0-5])|9(?:[028]|17))|4(?:2(?:[13-79]|8[014-6])|3[0-57]|[45]|6[248]|7[2-47]|9[29])|5(?:2|3(?:[045]|9(?:[0-58]|6[4-9]|7[0-35689]))|4[0-369]|5[29]|8[02389]|9[0-3])|7(?:2[02-46-9]|34|[58]|6[0249]|7[57]|9(?:[23]|4[0-59]|5[01569]|6[0167]))|8(?:2(?:[1258]|4[0-39]|9[0169])|3(?:[29]|60|7(?:[017-9]|6[6-8]))|49|51|6(?:[0-24]|36[2-57-9]|5(?:[0-389]|5[23])|6(?:[01]|9[178])|7(?:2[2-468]|3[78])|9[0145])|7[0-468]|8[68])|9(?:4[15]|5[138]|7[156]|8[189]|9(?:[1289]|3(?:31|4[357])|4[0178]))|(?:8294|96)[1-3]|2(?:57|93)[015-9]|(?:223|8699)[014-9]|(?:25[0468]|422|838)[01]|(?:48|8292|9[23])[1-9]|(?:47[59]|59[89]|8(?:68|9))[019]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{4})", "$1-$2-$3", ["[14]|[289][2-9]|5[3-9]|7[2-4679]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3", ["800"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2-$3", ["[25-9]"], "0$1"]], "0", 0, "(000[2569]\\d{4,6})$|(?:(?:003768)0?)|0", "$1"], "KE": ["254", "000", "(?:[17]\\d\\d|900)\\d{6}|(?:2|80)0\\d{6,7}|[4-6]\\d{6,8}", [7, 8, 9, 10], [["(\\d{2})(\\d{5,7})", "$1 $2", ["[24-6]"], "0$1"], ["(\\d{3})(\\d{6})", "$1 $2", ["[17]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[89]"], "0$1"]], "0"], "KG": ["996", "00", "8\\d{9}|[235-9]\\d{8}", [9, 10], [["(\\d{4})(\\d{5})", "$1 $2", ["3(?:1[346]|[24-79])"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235-79]|88"], "0$1"], ["(\\d{3})(\\d{3})(\\d)(\\d{2,3})", "$1 $2 $3 $4", ["8"], "0$1"]], "0"], "KH": ["855", "00[14-9]", "1\\d{9}|[1-9]\\d{7,8}", [8, 9, 10], [["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-9]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]], "0"], "KI": ["686", "00", "(?:[37]\\d|6[0-79])\\d{6}|(?:[2-48]\\d|50)\\d{3}", [5, 8], 0, "0"], "KM": ["269", "00", "[3478]\\d{6}", [7], [["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[3478]"]]]], "KN": ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "869$1", 0, "869"], "KP": ["850", "00|99", "85\\d{6}|(?:19\\d|[2-7])\\d{7}", [8, 10], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"], "0$1"], ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-7]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"]], "0"], "KR": ["82", "00(?:[125689]|3(?:[46]5|91)|7(?:00|27|3|55|6[126]))", "00[1-9]\\d{8,11}|(?:[12]|5\\d{3})\\d{7}|[13-6]\\d{9}|(?:[1-6]\\d|80)\\d{7}|[3-6]\\d{4,5}|(?:00|7)0\\d{8}", [5, 6, 8, 9, 10, 11, 12, 13, 14], [["(\\d{2})(\\d{3,4})", "$1-$2", ["(?:3[1-3]|[46][1-4]|5[1-5])1"], "0$1"], ["(\\d{4})(\\d{4})", "$1-$2", ["1"]], ["(\\d)(\\d{3,4})(\\d{4})", "$1-$2-$3", ["2"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3", ["[36]0|8"], "0$1"], ["(\\d{2})(\\d{3,4})(\\d{4})", "$1-$2-$3", ["[1346]|5[1-5]"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2-$3", ["[57]"], "0$1"], ["(\\d{2})(\\d{5})(\\d{4})", "$1-$2-$3", ["5"], "0$1"]], "0", 0, "0(8(?:[1-46-8]|5\\d\\d))?"], "KW": ["965", "00", "18\\d{5}|(?:[2569]\\d|41)\\d{6}", [7, 8], [["(\\d{4})(\\d{3,4})", "$1 $2", ["[169]|2(?:[235]|4[1-35-9])|52"]], ["(\\d{3})(\\d{5})", "$1 $2", ["[245]"]]]], "KY": ["1", "011", "(?:345|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "345$1", 0, "345"], "KZ": ["7", "810", "8\\d{13}|[78]\\d{9}", [10, 14], 0, "8", 0, 0, 0, 0, "7", 0, "8~10"], "LA": ["856", "00", "[23]\\d{9}|3\\d{8}|(?:[235-8]\\d|41)\\d{6}", [8, 9, 10], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["2[13]|3[14]|[4-8]"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["3"], "0$1"], ["(\\d{2})(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[23]"], "0$1"]], "0"], "LB": ["961", "00", "[27-9]\\d{7}|[13-9]\\d{6}", [7, 8], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[13-69]|7(?:[2-57]|62|8[0-6]|9[04-9])|8[02-9]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[27-9]"]]], "0"], "LC": ["1", "011", "(?:[58]\\d\\d|758|900)\\d{7}", [10], 0, "1", 0, "([2-8]\\d{6})$|1", "758$1", 0, "758"], "LI": ["423", "00", "[68]\\d{8}|(?:[2378]\\d|90)\\d{5}", [7, 9], [["(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2379]|8(?:0[09]|7)", "[2379]|8(?:0(?:02|9)|7)"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["69"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]]], "0", 0, "(1001)|0"], "LK": ["94", "00", "[1-9]\\d{8}", [9], [["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[1-689]"], "0$1"]], "0"], "LR": ["231", "00", "(?:[2457]\\d|33|88)\\d{7}|(?:2\\d|[4-6])\\d{6}", [7, 8, 9], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["4[67]|[56]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-578]"], "0$1"]], "0"], "LS": ["266", "00", "(?:[256]\\d\\d|800)\\d{5}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["[2568]"]]]], "LT": ["370", "00", "(?:[3469]\\d|52|[78]0)\\d{6}", [8], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["52[0-7]"], "(0-$1)", 1], ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[7-9]"], "0 $1", 1], ["(\\d{2})(\\d{6})", "$1 $2", ["37|4(?:[15]|6[1-8])"], "(0-$1)", 1], ["(\\d{3})(\\d{5})", "$1 $2", ["[3-6]"], "(0-$1)", 1]], "0", 0, "[08]"], "LU": ["352", "00", "35[013-9]\\d{4,8}|6\\d{8}|35\\d{2,4}|(?:[2457-9]\\d|3[0-46-9])\\d{2,9}", [4, 5, 6, 7, 8, 9, 10, 11], [["(\\d{2})(\\d{3})", "$1 $2", ["2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"]], ["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["2(?:0[2-689]|[2-9])|[3-57]|8(?:0[2-9]|[13-9])|9(?:0[89]|[2-579])"]], ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["20[2-689]"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})", "$1 $2 $3 $4", ["20"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{1,5})", "$1 $2 $3 $4", ["[3-57]|8[13-9]|9(?:0[89]|[2-579])|(?:2|80)[2-9]"]], ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["80[01]|90[015]"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3 $4", ["20"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})(\\d{1,2})", "$1 $2 $3 $4 $5", ["20"]]], 0, 0, "(15(?:0[06]|1[12]|[35]5|4[04]|6[26]|77|88|99)\\d)"], "LV": ["371", "00", "(?:[268]\\d|78|90)\\d{6}", [8], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2679]|8[01]"]]]], "LY": ["218", "00", "[2-9]\\d{8}", [9], [["(\\d{2})(\\d{7})", "$1-$2", ["[2-9]"], "0$1"]], "0"], "MA": ["212", "00", "[5-8]\\d{8}", [9], [["(\\d{4})(\\d{5})", "$1-$2", ["892"], "0$1"], ["(\\d{2})(\\d{7})", "$1-$2", ["8(?:0[0-7]|9)"], "0$1"], ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[5-8]"], "0$1"]], "0", 0, 0, 0, 0, "[5-8]"], "MC": ["377", "00", "(?:[3489]|[67]\\d)\\d{7}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["4"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[389]"]], ["(\\d)(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4 $5", ["[67]"], "0$1"]], "0"], "MD": ["373", "00", "(?:[235-7]\\d|[89]0)\\d{6}", [8], [["(\\d{3})(\\d{5})", "$1 $2", ["[89]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["22|3"], "0$1"], ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["[25-7]"], "0$1"]], "0"], "ME": ["382", "00", "(?:20|[3-79]\\d)\\d{6}|80\\d{6,7}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[2-9]"], "0$1"]], "0"], "MF": ["590", "00", "7090\\d{5}|(?:[56]9|[89]\\d)\\d{7}", [9], 0, "0", 0, 0, 0, 0, 0, [["(?:59(?:0(?:0[079]|[14]3|[27][79]|3[03-7]|5[0-268]|87)|87\\d)|80[6-9]\\d\\d)\\d{4}"], ["(?:69(?:0\\d\\d|1(?:2[2-9]|3[0-5]))|7090[0-4])\\d{4}"], ["80[0-5]\\d{6}"], ["8[129]\\d{7}"], 0, 0, 0, 0, ["9(?:(?:39[5-7]|76[018])\\d|475[0-6])\\d{4}"]]], "MG": ["261", "00", "[23]\\d{8}", [9], [["(\\d{2})(\\d{2})(\\d{3})(\\d{2})", "$1 $2 $3 $4", ["[23]"], "0$1"]], "0", 0, "([24-9]\\d{6})$|0", "20$1"], "MH": ["692", "011", "329\\d{4}|(?:[256]\\d|45)\\d{5}", [7], [["(\\d{3})(\\d{4})", "$1-$2", ["[2-6]"]]], "1"], "MK": ["389", "00", "[2-578]\\d{7}", [8], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["2|34[47]|4(?:[37]7|5[47]|64)"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[347]"], "0$1"], ["(\\d{3})(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[58]"], "0$1"]], "0"], "ML": ["223", "00", "[24-9]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[24-9]"]]]], "MM": ["95", "00", "1\\d{5,7}|95\\d{6}|(?:[4-7]|9[0-46-9])\\d{6,8}|(?:2|8\\d)\\d{5,8}", [6, 7, 8, 9, 10], [["(\\d)(\\d{2})(\\d{3})", "$1 $2 $3", ["16|2"], "0$1"], ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["4(?:[2-46]|5[3-5])|5|6(?:[1-689]|7[235-7])|7(?:[0-4]|5[2-7])|8[1-5]|(?:60|86)[23]"], "0$1"], ["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[12]|452|678|86", "[12]|452|6788|86"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[4-7]|8[1-35]"], "0$1"], ["(\\d)(\\d{3})(\\d{4,6})", "$1 $2 $3", ["9(?:2[0-4]|[35-9]|4[137-9])"], "0$1"], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"], ["(\\d)(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["92"], "0$1"], ["(\\d)(\\d{5})(\\d{4})", "$1 $2 $3", ["9"], "0$1"]], "0"], "MN": ["976", "001", "[12]\\d{7,9}|[5-9]\\d{7}", [8, 9, 10], [["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["11|2[16]"], "0$1"], ["(\\d{4})(\\d{4})", "$1 $2", ["[5-9]"]], ["(\\d{3})(\\d{5,6})", "$1 $2", ["[12]2[1-3]"], "0$1"], ["(\\d{4})(\\d{5,6})", "$1 $2", ["[12](?:27|3[2-8]|4[2-68]|5[1-4689])", "[12](?:27|3[2-8]|4[2-68]|5[1-4689])[0-3]"], "0$1"], ["(\\d{5})(\\d{4,5})", "$1 $2", ["[12]"], "0$1"]], "0"], "MO": ["853", "00", "0800\\d{3}|(?:28|[68]\\d)\\d{6}", [7, 8], [["(\\d{4})(\\d{3})", "$1 $2", ["0"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[268]"]]]], "MP": ["1", "011", "[58]\\d{9}|(?:67|90)0\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "670$1", 0, "670"], "MQ": ["596", "00", "7091\\d{5}|(?:[56]9|[89]\\d)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-79]|8(?:0[6-9]|[36])"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]], "0"], "MR": ["222", "00", "(?:[2-4]\\d\\d|800)\\d{5}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-48]"]]]], "MS": ["1", "011", "(?:[58]\\d\\d|664|900)\\d{7}", [10], 0, "1", 0, "([34]\\d{6})$|1", "664$1", 0, "664"], "MT": ["356", "00", "3550\\d{4}|(?:[2579]\\d\\d|800)\\d{5}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["[2357-9]"]]]], "MU": ["230", "0(?:0|[24-7]0|3[03])", "(?:[57]|8\\d\\d)\\d{7}|[2-468]\\d{6}", [7, 8, 10], [["(\\d{3})(\\d{4})", "$1 $2", ["[2-46]|8[013]"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[57]"]], ["(\\d{5})(\\d{5})", "$1 $2", ["8"]]], 0, 0, 0, 0, 0, 0, 0, "020"], "MV": ["960", "0(?:0|19)", "(?:800|9[0-57-9]\\d)\\d{7}|[34679]\\d{6}", [7, 10], [["(\\d{3})(\\d{4})", "$1-$2", ["[34679]"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "MW": ["265", "00", "(?:[1289]\\d|31|77)\\d{7}|1\\d{6}", [7, 9], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["1[2-9]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[1-37-9]"], "0$1"]], "0"], "MX": ["52", "0[09]", "[2-9]\\d{9}", [10], [["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["33|5[56]|81"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[2-9]"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "MY": ["60", "00", "1\\d{8,9}|(?:3\\d|[4-9])\\d{7}", [8, 9, 10], [["(\\d)(\\d{3})(\\d{4})", "$1-$2 $3", ["[4-79]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1-$2 $3", ["1(?:[02469]|[378][1-9]|53)|8", "1(?:[02469]|[37][1-9]|53|8(?:[1-46-9]|5[7-9]))|8"], "0$1"], ["(\\d)(\\d{4})(\\d{4})", "$1-$2 $3", ["3"], "0$1"], ["(\\d)(\\d{3})(\\d{2})(\\d{4})", "$1-$2-$3-$4", ["1(?:[367]|80)"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1-$2 $3", ["15"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4})", "$1-$2 $3", ["1"], "0$1"]], "0"], "MZ": ["258", "00", "(?:2|8\\d)\\d{7}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2|8[2-9]"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["8"]]]], "NA": ["264", "00", "[68]\\d{7,8}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["88"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["6"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["87"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"]], "0"], "NC": ["687", "00", "(?:050|[2-57-9]\\d\\d)\\d{3}", [6], [["(\\d{2})(\\d{2})(\\d{2})", "$1.$2.$3", ["[02-57-9]"]]]], "NE": ["227", "00", "[027-9]\\d{7}", [8], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["08"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[089]|2[013]|7[0467]"]]]], "NF": ["672", "00", "[13]\\d{5}", [6], [["(\\d{2})(\\d{4})", "$1 $2", ["1[0-3]"]], ["(\\d)(\\d{5})", "$1 $2", ["[13]"]]], 0, 0, "([0-258]\\d{4})$", "3$1"], "NG": ["234", "009", "(?:20|9\\d)\\d{8}|[78]\\d{9,13}", [10, 11, 12, 13, 14], [["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[7-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["20[129]"], "0$1"], ["(\\d{4})(\\d{2})(\\d{4})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{3})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["[78]"], "0$1"], ["(\\d{3})(\\d{5})(\\d{5,6})", "$1 $2 $3", ["[78]"], "0$1"]], "0"], "NI": ["505", "00", "(?:1800|[25-8]\\d{3})\\d{4}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["[125-8]"]]]], "NL": ["31", "00", "(?:[124-7]\\d\\d|3(?:[02-9]\\d|1[0-8]))\\d{6}|8\\d{6,9}|9\\d{6,10}|1\\d{4,5}", [5, 6, 7, 8, 9, 10, 11], [["(\\d{3})(\\d{4,7})", "$1 $2", ["[89]0"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["66"], "0$1"], ["(\\d)(\\d{8})", "$1 $2", ["6"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["1[16-8]|2[259]|3[124]|4[17-9]|5[124679]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-578]|91"], "0$1"], ["(\\d{3})(\\d{3})(\\d{5})", "$1 $2 $3", ["9"], "0$1"]], "0"], "NO": ["47", "00", "(?:0|[2-9]\\d{3})\\d{4}", [5, 8], [["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["8"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[2-79]"]]], 0, 0, 0, 0, 0, "[02-689]|7[0-8]"], "NP": ["977", "00", "(?:1\\d|9)\\d{9}|[1-9]\\d{7}", [8, 10, 11], [["(\\d)(\\d{7})", "$1-$2", ["1[2-6]"], "0$1"], ["(\\d{2})(\\d{6})", "$1-$2", ["1[01]|[2-8]|9(?:[1-59]|[67][2-6])"], "0$1"], ["(\\d{3})(\\d{7})", "$1-$2", ["9"]]], "0"], "NR": ["674", "00", "(?:222|444|(?:55|8\\d)\\d|666|777|999)\\d{4}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[24-9]"]]]], "NU": ["683", "00", "(?:[4-7]|888\\d)\\d{3}", [4, 7], [["(\\d{3})(\\d{4})", "$1 $2", ["8"]]]], "NZ": ["64", "0(?:0|161)", "[1289]\\d{9}|50\\d{5}(?:\\d{2,3})?|[27-9]\\d{7,8}|(?:[34]\\d|6[0-35-9])\\d{6}|8\\d{4,6}", [5, 6, 7, 8, 9, 10], [["(\\d{2})(\\d{3,8})", "$1 $2", ["8[1-79]"], "0$1"], ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["50[036-8]|8|90", "50(?:[0367]|88)|8|90"], "0$1"], ["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["24|[346]|7[2-57-9]|9[2-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2(?:10|74)|[589]"], "0$1"], ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["1|2[028]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,5})", "$1 $2 $3", ["2(?:[169]|7[0-35-9])|7"], "0$1"]], "0", 0, 0, 0, 0, 0, 0, "00"], "OM": ["968", "00", "(?:1505|[279]\\d{3}|500)\\d{4}|800\\d{5,6}", [7, 8, 9], [["(\\d{3})(\\d{4,6})", "$1 $2", ["[58]"]], ["(\\d{2})(\\d{6})", "$1 $2", ["2"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[179]"]]]], "PA": ["507", "00", "(?:00800|8\\d{3})\\d{6}|[68]\\d{7}|[1-57-9]\\d{6}", [7, 8, 10, 11], [["(\\d{3})(\\d{4})", "$1-$2", ["[1-57-9]"]], ["(\\d{4})(\\d{4})", "$1-$2", ["[68]"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]]]], "PE": ["51", "00|19(?:1[124]|77|90)00", "(?:[14-8]|9\\d)\\d{7}", [8, 9], [["(\\d{3})(\\d{5})", "$1 $2", ["80"], "(0$1)"], ["(\\d)(\\d{7})", "$1 $2", ["1"], "(0$1)"], ["(\\d{2})(\\d{6})", "$1 $2", ["[4-8]"], "(0$1)"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"]]], "0", 0, 0, 0, 0, 0, 0, "00", " Anexo "], "PF": ["689", "00", "4\\d{5}(?:\\d{2})?|8\\d{7,8}", [6, 8, 9], [["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["44"]], ["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["4|8[7-9]"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]]]], "PG": ["675", "00|140[1-3]", "(?:180|[78]\\d{3})\\d{4}|(?:[2-589]\\d|64)\\d{5}", [7, 8], [["(\\d{3})(\\d{4})", "$1 $2", ["18|[2-69]|85[02-46-9]"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[78]"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "PH": ["63", "00", "(?:[2-7]|9\\d)\\d{8}|2\\d{5}|(?:1800|8)\\d{7,9}", [6, 8, 9, 10, 11, 12, 13], [["(\\d)(\\d{5})", "$1 $2", ["2"], "(0$1)"], ["(\\d{4})(\\d{4,6})", "$1 $2", ["3(?:23|39|46)|4(?:2[3-6]|[35]9|4[26]|76)|544|88[245]|(?:52|64|86)2", "3(?:230|397|461)|4(?:2(?:35|[46]4|51)|396|4(?:22|63)|59[347]|76[15])|5(?:221|446)|642[23]|8(?:622|8(?:[24]2|5[13]))"], "(0$1)"], ["(\\d{5})(\\d{4})", "$1 $2", ["346|4(?:27|9[35])|883", "3469|4(?:279|9(?:30|56))|8834"], "(0$1)"], ["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["2"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[3-7]|8[2-8]"], "(0$1)"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]], ["(\\d{4})(\\d{1,2})(\\d{3})(\\d{4})", "$1 $2 $3 $4", ["1"]]], "0"], "PK": ["92", "00", "122\\d{6}|[24-8]\\d{10,11}|9(?:[013-9]\\d{8,10}|2(?:[01]\\d\\d|2(?:[06-8]\\d|1[01]))\\d{7})|(?:[2-8]\\d{3}|92(?:[0-7]\\d|8[1-9]))\\d{6}|[24-9]\\d{8}|[89]\\d{7}", [8, 9, 10, 11, 12], [["(\\d{3})(\\d{3})(\\d{2,7})", "$1 $2 $3", ["[89]0"], "0$1"], ["(\\d{4})(\\d{5})", "$1 $2", ["1"]], ["(\\d{3})(\\d{6,7})", "$1 $2", ["2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:2[2-8]|3[27-9]|4[2-6]|6[3569]|9[25-8])", "9(?:2[3-8]|98)|(?:2(?:3[2358]|4[2-4]|9[2-8])|45[3479]|54[2-467]|60[468]|72[236]|8(?:2[2-689]|3[23578]|4[3478]|5[2356])|9(?:22|3[27-9]|4[2-6]|6[3569]|9[25-7]))[2-9]"], "(0$1)"], ["(\\d{2})(\\d{7,8})", "$1 $2", ["(?:2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91)[2-9]"], "(0$1)"], ["(\\d{5})(\\d{5})", "$1 $2", ["58"], "(0$1)"], ["(\\d{3})(\\d{7})", "$1 $2", ["3"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["2[125]|4[0-246-9]|5[1-35-7]|6[1-8]|7[14]|8[16]|91"], "(0$1)"], ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[24-9]"], "(0$1)"]], "0"], "PL": ["48", "00", "(?:6|8\\d\\d)\\d{7}|[1-9]\\d{6}(?:\\d{2})?|[26]\\d{5}", [6, 7, 8, 9, 10], [["(\\d{5})", "$1", ["19"]], ["(\\d{3})(\\d{3})", "$1 $2", ["11|20|64"]], ["(\\d{2})(\\d{2})(\\d{3})", "$1 $2 $3", ["30|(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])1", "30|(?:1[2-8]|2[2-69]|3[2-4]|4[1-468]|5[24-689]|6[1-3578]|7[14-7]|8[1-79]|9[145])19"]], ["(\\d{3})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["64"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["21|39|45|5[0137]|6[0469]|7[02389]|8(?:0[14]|8)"]], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[2-8]|[2-7]|8[1-79]|9[145]"]], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["8"]]]], "PM": ["508", "00", "[78]\\d{8}|[2-9]\\d{5}", [6, 9], [["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["[2-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["7"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"], "0$1"]], "0"], "PR": ["1", "011", "(?:[589]\\d\\d|787)\\d{7}", [10], 0, "1", 0, 0, 0, 0, "787|939"], "PS": ["970", "00", "[2489]2\\d{6}|(?:1\\d|5)\\d{8}", [8, 9, 10], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["[2489]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["5"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]], "0"], "PT": ["351", "00", "1693\\d{5}|(?:[26-9]\\d|30)\\d{7}", [9], [["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["2[12]"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["16|[236-9]"]]]], "PW": ["680", "01[12]", "(?:[24-8]\\d\\d|345|900)\\d{4}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[2-9]"]]]], "PY": ["595", "00", "[36-8]\\d{5,8}|4\\d{6,8}|59\\d{6}|9\\d{5,10}|(?:2\\d|5[0-8])\\d{6,7}", [6, 7, 8, 9, 10, 11], [["(\\d{3})(\\d{3,6})", "$1 $2", ["[2-9]0"], "0$1"], ["(\\d{2})(\\d{5})", "$1 $2", ["3[289]|4[246-8]|61|7[1-3]|8[1-36]"], "(0$1)"], ["(\\d{3})(\\d{4,5})", "$1 $2", ["2[279]|3[13-5]|4[359]|5|6(?:[34]|7[1-46-8])|7[46-8]|85"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["2[14-68]|3[26-9]|4[1246-8]|6(?:1|75)|7[1-35]|8[1-36]"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["87"]], ["(\\d{3})(\\d{6})", "$1 $2", ["9(?:[5-79]|8[1-7])"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-8]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["9"]]], "0"], "QA": ["974", "00", "800\\d{4}|(?:2|800)\\d{6}|(?:0080|[3-7])\\d{7}", [7, 8, 9, 11], [["(\\d{3})(\\d{4})", "$1 $2", ["2[136]|8"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[3-7]"]]]], "RE": ["262", "00", "709\\d{6}|(?:26|[689]\\d)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[26-9]"], "0$1"]], "0", 0, 0, 0, 0, 0, [["2631[0-6]\\d{4}|26(?:2\\d|30|88)\\d{5}"], ["(?:69(?:2\\d\\d|3(?:[06][0-6]|1[0-3]|2[0-2]|3[0-39]|4\\d|5[0-5]|7[0-37]|8[0-8]|9[0-479]))|7092[0-3])\\d{4}"], ["80\\d{7}"], ["89[1-37-9]\\d{6}"], 0, 0, 0, 0, ["9(?:399[0-3]|479[0-6]|76(?:2[278]|3[0-37]))\\d{4}"], ["8(?:1[019]|2[0156]|84|90)\\d{6}"]]], "RO": ["40", "00", "(?:[236-8]\\d|90)\\d{7}|[23]\\d{5}", [6, 9], [["(\\d{3})(\\d{3})", "$1 $2", ["2[3-6]", "2[3-6]\\d9"], "0$1"], ["(\\d{2})(\\d{4})", "$1 $2", ["219|31"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[23]1"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[236-9]"], "0$1"]], "0", 0, 0, 0, 0, 0, 0, 0, " int "], "RS": ["381", "00", "38[02-9]\\d{6,9}|6\\d{7,9}|90\\d{4,8}|38\\d{5,6}|(?:7\\d\\d|800)\\d{3,9}|(?:[12]\\d|3[0-79])\\d{5,10}", [6, 7, 8, 9, 10, 11, 12], [["(\\d{3})(\\d{3,9})", "$1 $2", ["(?:2[389]|39)0|[7-9]"], "0$1"], ["(\\d{2})(\\d{5,10})", "$1 $2", ["[1-36]"], "0$1"]], "0"], "RU": ["7", "810", "8\\d{13}|[347-9]\\d{9}", [10, 14], [["(\\d{4})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["7(?:1[0-8]|2[1-9])", "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:1[23]|[2-9]2))", "7(?:1(?:[0-356]2|4[29]|7|8[27])|2(?:13[03-69]|62[013-9]))|72[1-57-9]2"], "8 ($1)", 1], ["(\\d{5})(\\d)(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["7(?:1[0-68]|2[1-9])", "7(?:1(?:[06][3-6]|[18]|2[35]|[3-5][3-5])|2(?:[13][3-5]|[24-689]|7[457]))", "7(?:1(?:0(?:[356]|4[023])|[18]|2(?:3[013-9]|5)|3[45]|43[013-79]|5(?:3[1-8]|4[1-7]|5)|6(?:3[0-35-9]|[4-6]))|2(?:1(?:3[178]|[45])|[24-689]|3[35]|7[457]))|7(?:14|23)4[0-8]|71(?:33|45)[1-79]"], "8 ($1)", 1], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "8 ($1)", 1], ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[349]|8(?:[02-7]|1[1-8])"], "8 ($1)", 1], ["(\\d{4})(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["8"], "8 ($1)"]], "8", 0, 0, 0, 0, "[3489]", 0, "8~10"], "RW": ["250", "00", "(?:06|[27]\\d\\d|[89]00)\\d{6}", [8, 9], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["0"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["2"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[7-9]"], "0$1"]], "0"], "SA": ["966", "00", "(?:[15]\\d|800|92)\\d{7}", [9, 10], [["(\\d{4})(\\d{5})", "$1 $2", ["9"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["5"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]]], "0"], "SB": ["677", "0[01]", "[6-9]\\d{6}|[1-6]\\d{4}", [5, 7], [["(\\d{2})(\\d{5})", "$1 $2", ["6[89]|7|8[4-9]|9(?:[0-8]|9[0-8])"]]]], "SC": ["248", "010|0[0-2]", "(?:[2489]\\d|64)\\d{5}", [7], [["(\\d)(\\d{3})(\\d{3})", "$1 $2 $3", ["[246]|9[57]"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "SD": ["249", "00", "[19]\\d{8}", [9], [["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[19]"], "0$1"]], "0"], "SE": ["46", "00", "(?:[26]\\d\\d|9)\\d{9}|[1-9]\\d{8}|[1-689]\\d{7}|[1-4689]\\d{6}|2\\d{5}", [6, 7, 8, 9, 10, 12], [["(\\d{2})(\\d{2,3})(\\d{2})", "$1-$2 $3", ["20"], "0$1", 0, "$1 $2 $3"], ["(\\d{3})(\\d{4})", "$1-$2", ["9(?:00|39|44|9)"], "0$1", 0, "$1 $2"], ["(\\d{2})(\\d{3})(\\d{2})", "$1-$2 $3", ["[12][136]|3[356]|4[0246]|6[03]|90[1-9]"], "0$1", 0, "$1 $2 $3"], ["(\\d)(\\d{2,3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["8"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d{3})(\\d{2,3})(\\d{2})", "$1-$2 $3", ["1[2457]|2(?:[247-9]|5[0138])|3[0247-9]|4[1357-9]|5[0-35-9]|6(?:[125689]|4[02-57]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"], "0$1", 0, "$1 $2 $3"], ["(\\d{3})(\\d{2,3})(\\d{3})", "$1-$2 $3", ["9(?:00|39|44)"], "0$1", 0, "$1 $2 $3"], ["(\\d{2})(\\d{2,3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["1[13689]|2[0136]|3[1356]|4[0246]|54|6[03]|90[1-9]"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["10|7"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d)(\\d{3})(\\d{3})(\\d{2})", "$1-$2 $3 $4", ["8"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1-$2 $3 $4", ["[13-5]|2(?:[247-9]|5[0138])|6(?:[124-689]|7[0-2])|9(?:[125-8]|3[02-5]|4[0-3])"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d{3})(\\d{2})(\\d{2})(\\d{3})", "$1-$2 $3 $4", ["9"], "0$1", 0, "$1 $2 $3 $4"], ["(\\d{3})(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1-$2 $3 $4 $5", ["[26]"], "0$1", 0, "$1 $2 $3 $4 $5"]], "0"], "SG": ["65", "0[0-3]\\d", "(?:(?:1\\d|8)\\d\\d|7000)\\d{7}|[3689]\\d{7}", [8, 10, 11], [["(\\d{4})(\\d{4})", "$1 $2", ["[369]|8(?:0[1-9]|[1-9])"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"]], ["(\\d{4})(\\d{4})(\\d{3})", "$1 $2 $3", ["7"]], ["(\\d{4})(\\d{3})(\\d{4})", "$1 $2 $3", ["1"]]]], "SH": ["290", "00", "(?:[256]\\d|8)\\d{3}", [4, 5], 0, 0, 0, 0, 0, 0, "[256]"], "SI": ["386", "00|10(?:22|66|88|99)", "[1-7]\\d{7}|8\\d{4,7}|90\\d{4,6}", [5, 6, 7, 8], [["(\\d{2})(\\d{3,6})", "$1 $2", ["8[09]|9"], "0$1"], ["(\\d{3})(\\d{5})", "$1 $2", ["59|8"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[37][01]|4[013]|51|6"], "0$1"], ["(\\d)(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[1-57]"], "(0$1)"]], "0", 0, 0, 0, 0, 0, 0, "00"], "SJ": ["47", "00", "0\\d{4}|(?:[489]\\d|79)\\d{6}", [5, 8], 0, 0, 0, 0, 0, 0, "79"], "SK": ["421", "00", "[2-689]\\d{8}|[2-59]\\d{6}|[2-5]\\d{5}", [6, 7, 9], [["(\\d)(\\d{2})(\\d{3,4})", "$1 $2 $3", ["21"], "0$1"], ["(\\d{2})(\\d{2})(\\d{2,3})", "$1 $2 $3", ["[3-5][1-8]1", "[3-5][1-8]1[67]"], "0$1"], ["(\\d)(\\d{3})(\\d{3})(\\d{2})", "$1 $2 $3 $4", ["2"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[689]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[3-5]"], "0$1"]], "0"], "SL": ["232", "00", "(?:[237-9]\\d|66)\\d{6}", [8], [["(\\d{2})(\\d{6})", "$1 $2", ["[236-9]"], "(0$1)"]], "0"], "SM": ["378", "00", "(?:0549|[5-7]\\d)\\d{6}", [8, 10], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[5-7]"]], ["(\\d{4})(\\d{6})", "$1 $2", ["0"]]], 0, 0, "([89]\\d{5})$", "0549$1"], "SN": ["221", "00", "(?:[378]\\d|93)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[379]"]]]], "SO": ["252", "00", "[346-9]\\d{8}|[12679]\\d{7}|[1-5]\\d{6}|[1348]\\d{5}", [6, 7, 8, 9], [["(\\d{2})(\\d{4})", "$1 $2", ["8[125]"]], ["(\\d{6})", "$1", ["[134]"]], ["(\\d)(\\d{6})", "$1 $2", ["[15]|2[0-79]|3[0-46-8]|4[0-7]"]], ["(\\d{2})(\\d{5,7})", "$1 $2", ["1|28|9[2-9]"]], ["(\\d)(\\d{7})", "$1 $2", ["[267]|904"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[346-9]"]]], "0"], "SR": ["597", "00", "(?:[2-5]|[6-9]\\d)\\d{5}", [6, 7], [["(\\d{2})(\\d{2})(\\d{2})", "$1-$2-$3", ["56"]], ["(\\d{3})(\\d{3})", "$1-$2", ["[2-5]"]], ["(\\d{3})(\\d{4})", "$1-$2", ["[6-9]"]]]], "SS": ["211", "00", "[19]\\d{8}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[19]"], "0$1"]], "0"], "ST": ["239", "00", "(?:22|9\\d)\\d{5}", [7], [["(\\d{3})(\\d{4})", "$1 $2", ["[29]"]]]], "SV": ["503", "00", "[25-7]\\d{7}|(?:80\\d|900)\\d{4}(?:\\d{4})?", [7, 8, 11], [["(\\d{3})(\\d{4})", "$1 $2", ["[89]"]], ["(\\d{4})(\\d{4})", "$1 $2", ["[25-7]"]], ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["[89]"]]]], "SX": ["1", "011", "7215\\d{6}|(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "(5\\d{6})$|1", "721$1", 0, "721"], "SY": ["963", "00", "[1-359]\\d{8}|[1-5]\\d{7}", [8, 9], [["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-4]|5[1-3]"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[59]"], "0$1", 1]], "0"], "SZ": ["268", "00", "0800\\d{4}|(?:[237]\\d|900)\\d{6}", [8, 9], [["(\\d{4})(\\d{4})", "$1 $2", ["[0237]"]], ["(\\d{5})(\\d{4})", "$1 $2", ["9"]]]], "TA": ["290", "00", "8\\d{3}", [4], 0, 0, 0, 0, 0, 0, "8"], "TC": ["1", "011", "(?:[58]\\d\\d|649|900)\\d{7}", [10], 0, "1", 0, "([2-479]\\d{6})$|1", "649$1", 0, "649"], "TD": ["235", "00|16", "(?:22|[3689]\\d|77)\\d{6}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[236-9]"]]], 0, 0, 0, 0, 0, 0, 0, "00"], "TG": ["228", "00", "[279]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[279]"]]]], "TH": ["66", "00[1-9]", "(?:001800|[2-57]|[689]\\d)\\d{7}|1\\d{7,9}", [8, 9, 10, 13], [["(\\d)(\\d{3})(\\d{4})", "$1 $2 $3", ["2"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[13-9]"], "0$1"], ["(\\d{4})(\\d{3})(\\d{3})", "$1 $2 $3", ["1"]]], "0"], "TJ": ["992", "810", "(?:[0-57-9]\\d|66)\\d{7}", [9], [["(\\d{6})(\\d)(\\d{2})", "$1 $2 $3", ["331", "3317"]], ["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["44[02-479]|[34]7"]], ["(\\d{4})(\\d)(\\d{4})", "$1 $2 $3", ["3(?:[1245]|3[12])"]], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["\\d"]]], 0, 0, 0, 0, 0, 0, 0, "8~10"], "TK": ["690", "00", "[2-47]\\d{3,6}", [4, 5, 6, 7]], "TL": ["670", "00", "7\\d{7}|(?:[2-47]\\d|[89]0)\\d{5}", [7, 8], [["(\\d{3})(\\d{4})", "$1 $2", ["[2-489]|70"]], ["(\\d{4})(\\d{4})", "$1 $2", ["7"]]]], "TM": ["993", "810", "[1-7]\\d{7}", [8], [["(\\d{2})(\\d{2})(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["12"], "(8 $1)"], ["(\\d{3})(\\d)(\\d{2})(\\d{2})", "$1 $2-$3-$4", ["[1-5]"], "(8 $1)"], ["(\\d{2})(\\d{6})", "$1 $2", ["[67]"], "8 $1"]], "8", 0, 0, 0, 0, 0, 0, "8~10"], "TN": ["216", "00", "[2-57-9]\\d{7}", [8], [["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-57-9]"]]]], "TO": ["676", "00", "(?:0800|(?:[5-8]\\d\\d|999)\\d)\\d{3}|[2-8]\\d{4}", [5, 7], [["(\\d{2})(\\d{3})", "$1-$2", ["[2-4]|50|6[09]|7[0-24-69]|8[05]"]], ["(\\d{4})(\\d{3})", "$1 $2", ["0"]], ["(\\d{3})(\\d{4})", "$1 $2", ["[5-9]"]]]], "TR": ["90", "00", "4\\d{6}|8\\d{11,12}|(?:[2-58]\\d\\d|900)\\d{7}", [7, 10, 12, 13], [["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["512|8[01589]|90"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["5"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[24][1-8]|3[1-9]"], "(0$1)", 1], ["(\\d{3})(\\d{3})(\\d{6,7})", "$1 $2 $3", ["80"], "0$1", 1]], "0"], "TT": ["1", "011", "(?:[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-46-8]\\d{6})$|1", "868$1", 0, "868"], "TV": ["688", "00", "(?:2|7\\d\\d|90)\\d{4}", [5, 6, 7], [["(\\d{2})(\\d{3})", "$1 $2", ["2"]], ["(\\d{2})(\\d{4})", "$1 $2", ["90"]], ["(\\d{2})(\\d{5})", "$1 $2", ["7"]]]], "TW": ["886", "0(?:0[25-79]|19)", "[2-689]\\d{8}|7\\d{9,10}|[2-8]\\d{7}|2\\d{6}", [7, 8, 9, 10, 11], [["(\\d{2})(\\d)(\\d{4})", "$1 $2 $3", ["202"], "0$1"], ["(\\d{3})(\\d{5})", "$1 $2", ["826"], "0$1"], ["(\\d{3})(\\d{2})(\\d{3})", "$1 $2 $3", ["83"], "0$1"], ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["82"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[25]0|37|49|8[09]"], "0$1"], ["(\\d)(\\d{3,4})(\\d{4})", "$1 $2 $3", ["[23568]|4(?:0[02-48]|[1-478])|7[1-9]", "[23568]|4(?:0[2-48]|[1-478])|(?:400|7)[1-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[49]"], "0$1"], ["(\\d{2})(\\d{4})(\\d{4,5})", "$1 $2 $3", ["7"], "0$1"]], "0", 0, 0, 0, 0, 0, 0, 0, "#"], "TZ": ["255", "00[056]", "(?:[25-8]\\d|41|90)\\d{7}", [9], [["(\\d{3})(\\d{2})(\\d{4})", "$1 $2 $3", ["[89]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[24]"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["5"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[67]"], "0$1"]], "0"], "UA": ["380", "00", "[89]\\d{9}|[3-9]\\d{8}", [9, 10], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["6[12][29]|(?:3[1-8]|4[136-8]|5[12457]|6[49])2|(?:56|65)[24]", "6[12][29]|(?:35|4[1378]|5[12457]|6[49])2|(?:56|65)[24]|(?:3[1-46-8]|46)2[013-9]"], "0$1"], ["(\\d{4})(\\d{5})", "$1 $2", ["3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6[0135689]|7[4-6])|6(?:[12][3-7]|[459])", "3[1-8]|4(?:[1367]|[45][6-9]|8[4-6])|5(?:[1-5]|6(?:[015689]|3[02389])|7[4-6])|6(?:[12][3-7]|[459])"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[3-7]|89|9[1-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[89]"], "0$1"]], "0", 0, 0, 0, 0, 0, 0, "0~0"], "UG": ["256", "00[057]", "800\\d{6}|(?:[29]0|[347]\\d)\\d{7}", [9], [["(\\d{4})(\\d{5})", "$1 $2", ["202", "2024", "20240"], "0$1"], ["(\\d{3})(\\d{6})", "$1 $2", ["20[0-35-7]|4(?:6[45]|[7-9])|[7-9]", "20(?:[0135-7]|2[5-9])|4(?:6[45]|[7-9])|[7-9]"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["[2-4]"], "0$1"]], "0"], "US": ["1", "011", "[2-9]\\d{9}|3\\d{6}", [10], [["(\\d{3})(\\d{4})", "$1-$2", ["310"], 0, 1], ["(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3", ["[2-9]"], 0, 1, "$1-$2-$3"]], "1", 0, 0, 0, 0, 0, [["983[2-57-9]\\d{6}|(?:2(?:0[1-35-9]|1[02-9]|2[03-57-9]|3[1459]|4[08]|5[1-46]|6[0279]|7[02469]|8[13])|3(?:0[1-57-9]|1[02-9]|2[013-79]|3[0-24679]|4[167]|5[0-3]|6[01349]|8[056])|4(?:0[124-9]|1[02-579]|2[3-5]|3[0245]|4[023578]|58|6[349]|7[02589]|8[04])|5(?:0[1-57-9]|1[0235-8]|20|3[0149]|4[01]|5[179]|6[1-47]|7[0-5]|8[0256])|6(?:0[1-35-9]|1[024-9]|2[03689]|3[016]|4[0156]|5[01679]|6[0-279]|78|8[0-269])|7(?:0[1-46-8]|1[2-9]|2[04-8]|3[0-2478]|4[0378]|5[47]|6[02359]|7[0-59]|8[156])|8(?:0[1-68]|1[02-8]|2[0168]|3[0-2589]|4[03578]|5[046-9]|6[02-5]|7[028])|9(?:0[1346-9]|1[02-9]|2[0589]|3[0146-8]|4[01357-9]|5[12469]|7[0-3589]|8[04-69]))[2-9]\\d{6}"], [""], ["8(?:00|33|44|55|66|77|88)[2-9]\\d{6}"], ["900[2-9]\\d{6}"], ["52(?:3(?:[2-46-9][02-9]\\d|5(?:[02-46-9]\\d|5[0-46-9]))|4(?:[2-478][02-9]\\d|5(?:[034]\\d|2[024-9]|5[0-46-9])|6(?:0[1-9]|[2-9]\\d)|9(?:[05-9]\\d|2[0-5]|49)))\\d{4}|52[34][2-9]1[02-9]\\d{4}|5(?:00|2[125-9]|3[23]|44|66|77|88)[2-9]\\d{6}"]]], "UY": ["598", "0(?:0|1[3-9]\\d)", "0004\\d{2,9}|[1249]\\d{7}|2\\d{3,4}|(?:[49]\\d|80)\\d{5}", [4, 5, 6, 7, 8, 9, 10, 11, 12, 13], [["(\\d{4,5})", "$1", ["21"]], ["(\\d{3})(\\d{3,4})", "$1 $2", ["0"]], ["(\\d{3})(\\d{4})", "$1 $2", ["[49]0|8"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["9"], "0$1"], ["(\\d{4})(\\d{4})", "$1 $2", ["[124]"]], ["(\\d{3})(\\d{3})(\\d{2,4})", "$1 $2 $3", ["0"]], ["(\\d{3})(\\d{3})(\\d{3})(\\d{2,4})", "$1 $2 $3 $4", ["0"]]], "0", 0, 0, 0, 0, 0, 0, "00", " int. "], "UZ": ["998", "00", "(?:20|33|[5-9]\\d)\\d{7}", [9], [["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["[235-9]"]]]], "VA": ["39", "00", "0\\d{5,10}|3[0-8]\\d{7,10}|55\\d{8}|8\\d{5}(?:\\d{2,4})?|(?:1\\d|39)\\d{7,8}", [6, 7, 8, 9, 10, 11, 12], 0, 0, 0, 0, 0, 0, "06698"], "VC": ["1", "011", "(?:[58]\\d\\d|784|900)\\d{7}", [10], 0, "1", 0, "([2-7]\\d{6})$|1", "784$1", 0, "784"], "VE": ["58", "00", "[68]00\\d{7}|(?:[24]\\d|[59]0)\\d{8}", [10], [["(\\d{3})(\\d{7})", "$1-$2", ["[24-689]"], "0$1"]], "0"], "VG": ["1", "011", "(?:284|[58]\\d\\d|900)\\d{7}", [10], 0, "1", 0, "([2-578]\\d{6})$|1", "284$1", 0, "284"], "VI": ["1", "011", "[58]\\d{9}|(?:34|90)0\\d{7}", [10], 0, "1", 0, "([2-9]\\d{6})$|1", "340$1", 0, "340"], "VN": ["84", "00", "[12]\\d{9}|[135-9]\\d{8}|[16]\\d{6,7}|7\\d{6}", [7, 8, 9, 10], [["(\\d{4})(\\d{4,6})", "$1 $2", ["1(?:2[02]|[89])"], 0, 1], ["(\\d{2})(\\d{3})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["1[26]|6"], "0$1", 1], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[1357-9]"], "0$1", 1], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["2[48]"], "0$1", 1], ["(\\d{3})(\\d{4})(\\d{3})", "$1 $2 $3", ["2"], "0$1", 1]], "0"], "VU": ["678", "00", "[57-9]\\d{6}|(?:[238]\\d|48)\\d{3}", [5, 7], [["(\\d{3})(\\d{4})", "$1 $2", ["[57-9]"]]]], "WF": ["681", "00", "(?:40|72|8\\d{4})\\d{4}|[89]\\d{5}", [6, 9], [["(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3", ["[47-9]"]], ["(\\d{3})(\\d{2})(\\d{2})(\\d{2})", "$1 $2 $3 $4", ["8"]]]], "WS": ["685", "0", "(?:[2-6]|8\\d{5})\\d{4}|[78]\\d{6}|[68]\\d{5}", [5, 6, 7, 10], [["(\\d{5})", "$1", ["[2-5]|6[1-9]"]], ["(\\d{3})(\\d{3,7})", "$1 $2", ["[68]"]], ["(\\d{2})(\\d{5})", "$1 $2", ["7"]]]], "XK": ["383", "00", "2\\d{7,8}|3\\d{7,11}|(?:4\\d\\d|[89]00)\\d{5}", [8, 9, 10, 11, 12], [["(\\d{3})(\\d{5})", "$1 $2", ["[89]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3})", "$1 $2 $3", ["[2-4]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["2|39"], "0$1"], ["(\\d{2})(\\d{7,10})", "$1 $2", ["3"], "0$1"]], "0"], "YE": ["967", "00", "(?:1|7\\d)\\d{7}|[1-7]\\d{6}", [7, 8, 9], [["(\\d)(\\d{3})(\\d{3,4})", "$1 $2 $3", ["[1-6]|7(?:[24-6]|8[0-7])"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["7"], "0$1"]], "0"], "YT": ["262", "00", "(?:639\\d|7093)\\d{5}|(?:26|80|9\\d)\\d{7}", [9], 0, "0", 0, 0, 0, 0, 0, [["26(?:89\\d|9(?:0[0-467]|15|5[0-4]|6\\d|[78]0))\\d{4}"], ["(?:639(?:0[0-79]|1[019]|[267]\\d|3[09]|40|5[05-9]|9[04-79])|7093[5-7])\\d{4}"], ["80\\d{7}"], 0, 0, 0, 0, 0, ["9(?:(?:39|47)8[01]|769\\d)\\d{4}"]]], "ZA": ["27", "00", "[1-79]\\d{8}|8\\d{4,9}", [5, 6, 7, 8, 9, 10], [["(\\d{2})(\\d{3,4})", "$1 $2", ["8[1-4]"], "0$1"], ["(\\d{2})(\\d{3})(\\d{2,3})", "$1 $2 $3", ["8[1-4]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["860"], "0$1"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["[1-9]"], "0$1"], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["8"], "0$1"]], "0"], "ZM": ["260", "00", "800\\d{6}|(?:21|[579]\\d|63)\\d{7}", [9], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[28]"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["[579]"], "0$1"]], "0"], "ZW": ["263", "00", "(?:13|8\\d{4})\\d{5}|[235-8]\\d{8}|[23568]\\d{6}", [7, 9, 10], [["(\\d{2})(\\d{3,5})", "$1 $2", ["1|2(?:0[0-36-9]|29|58)|67[0-46-9]|(?:55|68)[0-69]"], "0$1"], ["(\\d{3})(\\d{3,5})", "$1 $2", ["2(?:0[45]|[27]|48)|37|675|(?:55|68)[78]"], "0$1"], ["(\\d{3})(\\d{4})", "$1 $2", ["80"], "0$1"], ["(\\d{4})(\\d{3,5})", "$1 $2", ["548"], "0$1"], ["(\\d{2})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["29[013-9]"], "0$1"], ["(\\d{2})(\\d{7})", "$1 $2", ["[256]|39|8[13-59]"], "(0$1)"], ["(\\d{2})(\\d{3})(\\d{4})", "$1 $2 $3", ["7"], "0$1"], ["(\\d{3})(\\d{3})(\\d{3,4})", "$1 $2 $3", ["3"], "0$1"], ["(\\d{4})(\\d{6})", "$1 $2", ["8"], "0$1"]], "0"] }, "nonGeographic": { "800": ["800", 0, "(?:00|[1-9]\\d)\\d{6}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["\\d"]]], 0, 0, 0, 0, 0, 0, [0, 0, ["(?:00|[1-9]\\d)\\d{6}"]]], "808": ["808", 0, "[1-9]\\d{7}", [8], [["(\\d{4})(\\d{4})", "$1 $2", ["[1-9]"]]], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, 0, ["[1-9]\\d{7}"]]], "870": ["870", 0, "7\\d{11}|[235-7]\\d{8}", [9, 12], [["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["[235-7]"]]], 0, 0, 0, 0, 0, 0, [0, ["(?:[356]|774[45])\\d{8}|7[6-8]\\d{7}"], 0, 0, 0, 0, 0, 0, ["2\\d{8}", [9]]]], "878": ["878", 0, "10\\d{10}", [12], [["(\\d{2})(\\d{5})(\\d{5})", "$1 $2 $3", ["1"]]], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, ["10\\d{10}"]]], "881": ["881", 0, "6\\d{9}|[0-36-9]\\d{8}", [9, 10], [["(\\d)(\\d{3})(\\d{5})", "$1 $2 $3", ["[0-37-9]"]], ["(\\d)(\\d{3})(\\d{5,6})", "$1 $2 $3", ["6"]]], 0, 0, 0, 0, 0, 0, [0, ["6\\d{9}|[0-36-9]\\d{8}"]]], "882": ["882", 0, "[13]\\d{6}(?:\\d{2,5})?|[19]\\d{7}|(?:[25]\\d\\d|4)\\d{7}(?:\\d{2})?", [7, 8, 9, 10, 11, 12], [["(\\d{2})(\\d{5})", "$1 $2", ["16|342"]], ["(\\d{2})(\\d{6})", "$1 $2", ["49"]], ["(\\d{2})(\\d{2})(\\d{4})", "$1 $2 $3", ["1[36]|9"]], ["(\\d{2})(\\d{4})(\\d{3})", "$1 $2 $3", ["3[23]"]], ["(\\d{2})(\\d{3,4})(\\d{4})", "$1 $2 $3", ["16"]], ["(\\d{2})(\\d{4})(\\d{4})", "$1 $2 $3", ["10|23|3(?:[15]|4[57])|4|5[12]"]], ["(\\d{3})(\\d{4})(\\d{4})", "$1 $2 $3", ["34"]], ["(\\d{2})(\\d{4,5})(\\d{5})", "$1 $2 $3", ["[1-35]"]]], 0, 0, 0, 0, 0, 0, [0, ["342\\d{4}|(?:337|49)\\d{6}|(?:3(?:2|47|7\\d{3})|5(?:0\\d{3}|2[0-2]))\\d{7}", [7, 8, 9, 10, 12]], 0, 0, 0, ["348[57]\\d{7}", [11]], 0, 0, ["1(?:3(?:0[0347]|[13][0139]|2[035]|4[013568]|6[0459]|7[06]|8[15-8]|9[0689])\\d{4}|6\\d{5,10})|(?:345\\d|9[89])\\d{6}|(?:10|2(?:3|85\\d)|3(?:[15]|[69]\\d\\d)|4[15-8]|51)\\d{8}"]]], "883": ["883", 0, "(?:[1-4]\\d|51)\\d{6,10}", [8, 9, 10, 11, 12], [["(\\d{3})(\\d{3})(\\d{2,8})", "$1 $2 $3", ["[14]|2[24-689]|3[02-689]|51[24-9]"]], ["(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3", ["510"]], ["(\\d{3})(\\d{3})(\\d{4})", "$1 $2 $3", ["21"]], ["(\\d{4})(\\d{4})(\\d{4})", "$1 $2 $3", ["51[13]"]], ["(\\d{3})(\\d{3})(\\d{3})(\\d{3})", "$1 $2 $3 $4", ["[235]"]]], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, 0, 0, ["(?:2(?:00\\d\\d|10)|(?:370[1-9]|51\\d0)\\d)\\d{7}|51(?:00\\d{5}|[24-9]0\\d{4,7})|(?:1[0-79]|2[24-689]|3[02-689]|4[0-4])0\\d{5,9}"]]], "888": ["888", 0, "\\d{11}", [11], [["(\\d{3})(\\d{3})(\\d{5})", "$1 $2 $3"]], 0, 0, 0, 0, 0, 0, [0, 0, 0, 0, 0, 0, ["\\d{11}"]]], "979": ["979", 0, "[1359]\\d{8}", [9], [["(\\d)(\\d{4})(\\d{4})", "$1 $2 $3", ["[1359]"]]], 0, 0, 0, 0, 0, 0, [0, 0, 0, ["[1359]\\d{8}"]]] } };

  // node_modules/libphonenumber-js/min/exports/withMetadataArgument.js
  function withMetadataArgument(func, _arguments) {
    var args = Array.prototype.slice.call(_arguments);
    args.push(metadata_min_json_default);
    return func.apply(this, args);
  }

  // node_modules/libphonenumber-js/es6/tools/semver-compare.js
  function semver_compare_default(a, b) {
    a = a.split("-");
    b = b.split("-");
    var pa = a[0].split(".");
    var pb = b[0].split(".");
    for (var i = 0; i < 3; i++) {
      var na = Number(pa[i]);
      var nb = Number(pb[i]);
      if (na > nb) return 1;
      if (nb > na) return -1;
      if (!isNaN(na) && isNaN(nb)) return 1;
      if (isNaN(na) && !isNaN(nb)) return -1;
    }
    if (a[1] && b[1]) {
      return a[1] > b[1] ? 1 : a[1] < b[1] ? -1 : 0;
    }
    return !a[1] && b[1] ? 1 : a[1] && !b[1] ? -1 : 0;
  }

  // node_modules/libphonenumber-js/es6/helpers/isObject.js
  var objectConstructor = {}.constructor;
  function isObject(object2) {
    return object2 !== void 0 && object2 !== null && object2.constructor === objectConstructor;
  }

  // node_modules/libphonenumber-js/es6/helpers/isCallingCode.js
  var CALLING_CODE_REG_EXP = /^\d+$/;
  function isCallingCode(string2) {
    return CALLING_CODE_REG_EXP.test(string2);
  }

  // node_modules/libphonenumber-js/es6/metadata.js
  function _typeof(o) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof(o);
  }
  function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
  }
  function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
  }
  function _toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  var V3 = "1.2.0";
  var V4 = "1.7.35";
  var DEFAULT_EXT_PREFIX = " ext. ";
  var Metadata = /* @__PURE__ */ (function() {
    function Metadata2(metadata3) {
      _classCallCheck(this, Metadata2);
      validateMetadata(metadata3);
      this.metadata = metadata3;
      setVersion.call(this, metadata3);
    }
    return _createClass(Metadata2, [{
      key: "getCountries",
      value: function getCountries3() {
        return Object.keys(this.metadata.countries).filter(function(_) {
          return _ !== "001";
        });
      }
    }, {
      key: "getCountryMetadata",
      value: function getCountryMetadata(countryCode) {
        return this.metadata.countries[countryCode];
      }
    }, {
      key: "nonGeographic",
      value: function nonGeographic() {
        if (this.v1 || this.v2 || this.v3) return;
        return this.metadata.nonGeographic || this.metadata.nonGeographical;
      }
    }, {
      key: "hasCountry",
      value: function hasCountry(country) {
        return this.getCountryMetadata(country) !== void 0;
      }
    }, {
      key: "hasCallingCode",
      value: function hasCallingCode(callingCode) {
        if (this.getCountryCodesForCallingCode(callingCode)) {
          return true;
        }
        if (this.nonGeographic()) {
          if (this.nonGeographic()[callingCode]) {
            return true;
          }
        } else {
          var countryCodes = this.countryCallingCodes()[callingCode];
          if (countryCodes && countryCodes.length === 1 && countryCodes[0] === "001") {
            return true;
          }
        }
      }
    }, {
      key: "isNonGeographicCallingCode",
      value: function isNonGeographicCallingCode(callingCode) {
        if (this.nonGeographic()) {
          return this.nonGeographic()[callingCode] ? true : false;
        } else {
          return this.getCountryCodesForCallingCode(callingCode) ? false : true;
        }
      }
      // Deprecated.
    }, {
      key: "country",
      value: function country(countryCode) {
        return this.selectNumberingPlan(countryCode);
      }
      /**
       * Selects a telephone numbering plan based on either a country code or a calling code.
       * @param {string} argument — Country code or calling code.
       * @param {string} legacyArgumentCallingCode — Legacy argument: calling code, if the first argument is not passed.
       */
    }, {
      key: "selectNumberingPlan",
      value: function selectNumberingPlan(argument, legacyArgumentCallingCode) {
        var countryCode;
        var callingCode;
        if (argument) {
          if (isCallingCode(argument)) {
            callingCode = argument;
          } else {
            countryCode = argument;
          }
        }
        if (legacyArgumentCallingCode) {
          callingCode = legacyArgumentCallingCode;
        }
        if (countryCode && countryCode !== "001") {
          var countryMetadata = this.getCountryMetadata(countryCode);
          if (!countryMetadata) {
            throw new Error("Unknown country: ".concat(countryCode));
          }
          this.numberingPlan = new NumberingPlan(countryMetadata, this);
        } else if (callingCode) {
          if (!this.hasCallingCode(callingCode)) {
            throw new Error("Unknown calling code: ".concat(callingCode));
          }
          this.numberingPlan = new NumberingPlan(this.getNumberingPlanMetadata(callingCode), this);
        } else {
          this.numberingPlan = void 0;
        }
        return this;
      }
    }, {
      key: "getCountryCodesForCallingCode",
      value: function getCountryCodesForCallingCode(callingCode) {
        var countryCodes = this.countryCallingCodes()[callingCode];
        if (countryCodes) {
          if (countryCodes.length === 1 && countryCodes[0].length === 3) {
            return;
          }
          return countryCodes;
        }
      }
    }, {
      key: "getCountryCodeForCallingCode",
      value: function getCountryCodeForCallingCode(callingCode) {
        var countryCodes = this.getCountryCodesForCallingCode(callingCode);
        if (countryCodes) {
          return countryCodes[0];
        }
      }
    }, {
      key: "getNumberingPlanMetadata",
      value: function getNumberingPlanMetadata(callingCode) {
        var countryCode = this.getCountryCodeForCallingCode(callingCode);
        if (countryCode) {
          return this.getCountryMetadata(countryCode);
        }
        if (this.nonGeographic()) {
          var metadata3 = this.nonGeographic()[callingCode];
          if (metadata3) {
            return metadata3;
          }
        } else {
          var countryCodes = this.countryCallingCodes()[callingCode];
          if (countryCodes && countryCodes.length === 1 && countryCodes[0] === "001") {
            return this.metadata.countries["001"];
          }
        }
      }
      // Deprecated.
    }, {
      key: "countryCallingCode",
      value: function countryCallingCode() {
        return this.numberingPlan.callingCode();
      }
      // Deprecated.
    }, {
      key: "IDDPrefix",
      value: function IDDPrefix() {
        return this.numberingPlan.IDDPrefix();
      }
      // Deprecated.
    }, {
      key: "defaultIDDPrefix",
      value: function defaultIDDPrefix() {
        return this.numberingPlan.defaultIDDPrefix();
      }
      // Deprecated.
    }, {
      key: "nationalNumberPattern",
      value: function nationalNumberPattern() {
        return this.numberingPlan.nationalNumberPattern();
      }
      // Deprecated.
    }, {
      key: "possibleLengths",
      value: function possibleLengths() {
        return this.numberingPlan.possibleLengths();
      }
      // Deprecated.
    }, {
      key: "formats",
      value: function formats() {
        return this.numberingPlan.formats();
      }
      // Deprecated.
    }, {
      key: "nationalPrefixForParsing",
      value: function nationalPrefixForParsing() {
        return this.numberingPlan.nationalPrefixForParsing();
      }
      // Deprecated.
    }, {
      key: "nationalPrefixTransformRule",
      value: function nationalPrefixTransformRule() {
        return this.numberingPlan.nationalPrefixTransformRule();
      }
      // Deprecated.
    }, {
      key: "leadingDigits",
      value: function leadingDigits() {
        return this.numberingPlan.leadingDigits();
      }
      // Deprecated.
    }, {
      key: "hasTypes",
      value: function hasTypes() {
        return this.numberingPlan.hasTypes();
      }
      // Deprecated.
    }, {
      key: "type",
      value: function type(_type) {
        return this.numberingPlan.type(_type);
      }
      // Deprecated.
    }, {
      key: "ext",
      value: function ext() {
        return this.numberingPlan.ext();
      }
    }, {
      key: "countryCallingCodes",
      value: function countryCallingCodes() {
        if (this.v1) return this.metadata.country_phone_code_to_countries;
        return this.metadata.country_calling_codes;
      }
      // Deprecated.
    }, {
      key: "chooseCountryByCountryCallingCode",
      value: function chooseCountryByCountryCallingCode(callingCode) {
        return this.selectNumberingPlan(callingCode);
      }
    }, {
      key: "hasSelectedNumberingPlan",
      value: function hasSelectedNumberingPlan() {
        return this.numberingPlan !== void 0;
      }
    }]);
  })();
  var NumberingPlan = /* @__PURE__ */ (function() {
    function NumberingPlan2(metadata3, globalMetadataObject) {
      _classCallCheck(this, NumberingPlan2);
      this.globalMetadataObject = globalMetadataObject;
      this.metadata = metadata3;
      setVersion.call(this, globalMetadataObject.metadata);
    }
    return _createClass(NumberingPlan2, [{
      key: "callingCode",
      value: function callingCode() {
        return this.metadata[0];
      }
      // When multiple countries share the same calling code,
      // all phone number formatting rules are included in the metadata
      // of the "default" country for that calling code.
      // Any other countries' metdata doesn't include any formatting rules.
      // Google developers said that such storage architecture was chosen for performance reasons.
      //
      // For example, for NANPA region ("North American Numbering Plan Administration",
      // which includes USA, Canada, Cayman Islands, Bahamas, etc) all formatting rules
      // are contained in the metadata of `US` country.
      //
      // This is not public API.
      //
    }, {
      key: "_getDefaultCountryMetadataForThisCallingCode",
      value: function _getDefaultCountryMetadataForThisCallingCode() {
        return this.globalMetadataObject.getNumberingPlanMetadata(this.callingCode());
      }
      // Deprecated.
    }, {
      key: "getDefaultCountryMetadataForRegion",
      value: function getDefaultCountryMetadataForRegion() {
        return this._getDefaultCountryMetadataForThisCallingCode();
      }
      // Is always present.
    }, {
      key: "IDDPrefix",
      value: function IDDPrefix() {
        if (this.v1 || this.v2) return;
        return this.metadata[1];
      }
      // Is only present when a country supports multiple IDD prefixes.
    }, {
      key: "defaultIDDPrefix",
      value: function defaultIDDPrefix() {
        if (this.v1 || this.v2) return;
        return this.metadata[12];
      }
    }, {
      key: "nationalNumberPattern",
      value: function nationalNumberPattern() {
        if (this.v1 || this.v2) return this.metadata[1];
        return this.metadata[2];
      }
      // "possible length" data is always present in Google's metadata.
    }, {
      key: "possibleLengths",
      value: function possibleLengths() {
        if (this.v1) return;
        return this.metadata[this.v2 ? 2 : 3];
      }
    }, {
      key: "_getFormats",
      value: function _getFormats(metadata3) {
        return metadata3[this.v1 ? 2 : this.v2 ? 3 : 4];
      }
      // For countries of the same region (e.g. NANPA)
      // formats are all stored in the "main" country for that region.
      // E.g. "RU" and "KZ", "US" and "CA".
    }, {
      key: "formats",
      value: function formats() {
        var _this = this;
        var formats2 = this._getFormats(this.metadata) || this._getFormats(this._getDefaultCountryMetadataForThisCallingCode()) || [];
        return formats2.map(function(_) {
          return new Format(_, _this);
        });
      }
    }, {
      key: "nationalPrefix",
      value: function nationalPrefix() {
        return this.metadata[this.v1 ? 3 : this.v2 ? 4 : 5];
      }
    }, {
      key: "_getNationalPrefixFormattingRule",
      value: function _getNationalPrefixFormattingRule(metadata3) {
        return metadata3[this.v1 ? 4 : this.v2 ? 5 : 6];
      }
      // For countries of the same region (e.g. NANPA)
      // national prefix formatting rule is stored in the "main" country for that region.
      // E.g. "RU" and "KZ", "US" and "CA".
    }, {
      key: "nationalPrefixFormattingRule",
      value: function nationalPrefixFormattingRule() {
        return this._getNationalPrefixFormattingRule(this.metadata) || this._getNationalPrefixFormattingRule(this._getDefaultCountryMetadataForThisCallingCode());
      }
    }, {
      key: "_nationalPrefixForParsing",
      value: function _nationalPrefixForParsing() {
        return this.metadata[this.v1 ? 5 : this.v2 ? 6 : 7];
      }
    }, {
      key: "nationalPrefixForParsing",
      value: function nationalPrefixForParsing() {
        return this._nationalPrefixForParsing() || this.nationalPrefix();
      }
    }, {
      key: "nationalPrefixTransformRule",
      value: function nationalPrefixTransformRule() {
        return this.metadata[this.v1 ? 6 : this.v2 ? 7 : 8];
      }
    }, {
      key: "_getNationalPrefixIsOptionalWhenFormatting",
      value: function _getNationalPrefixIsOptionalWhenFormatting() {
        return !!this.metadata[this.v1 ? 7 : this.v2 ? 8 : 9];
      }
      // For countries of the same region (e.g. NANPA)
      // "national prefix is optional when formatting" flag is
      // stored in the "main" country for that region.
      // E.g. "RU" and "KZ", "US" and "CA".
    }, {
      key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
      value: function nationalPrefixIsOptionalWhenFormattingInNationalFormat() {
        return this._getNationalPrefixIsOptionalWhenFormatting(this.metadata) || this._getNationalPrefixIsOptionalWhenFormatting(this._getDefaultCountryMetadataForThisCallingCode());
      }
    }, {
      key: "leadingDigits",
      value: function leadingDigits() {
        return this.metadata[this.v1 ? 8 : this.v2 ? 9 : 10];
      }
    }, {
      key: "types",
      value: function types() {
        return this.metadata[this.v1 ? 9 : this.v2 ? 10 : 11];
      }
    }, {
      key: "hasTypes",
      value: function hasTypes() {
        if (this.types() && this.types().length === 0) {
          return false;
        }
        return !!this.types();
      }
    }, {
      key: "type",
      value: function type(_type2) {
        if (this.hasTypes() && getType(this.types(), _type2)) {
          return new Type(getType(this.types(), _type2), this);
        }
      }
    }, {
      key: "ext",
      value: function ext() {
        if (this.v1 || this.v2) return DEFAULT_EXT_PREFIX;
        return this.metadata[13] || DEFAULT_EXT_PREFIX;
      }
    }]);
  })();
  var Format = /* @__PURE__ */ (function() {
    function Format2(format, metadata3) {
      _classCallCheck(this, Format2);
      this._format = format;
      this.metadata = metadata3;
    }
    return _createClass(Format2, [{
      key: "pattern",
      value: function pattern() {
        return this._format[0];
      }
    }, {
      key: "format",
      value: function format() {
        return this._format[1];
      }
    }, {
      key: "leadingDigitsPatterns",
      value: function leadingDigitsPatterns() {
        return this._format[2] || [];
      }
    }, {
      key: "nationalPrefixFormattingRule",
      value: function nationalPrefixFormattingRule() {
        return this._format[3] || this.metadata.nationalPrefixFormattingRule();
      }
    }, {
      key: "nationalPrefixIsOptionalWhenFormattingInNationalFormat",
      value: function nationalPrefixIsOptionalWhenFormattingInNationalFormat() {
        return !!this._format[4] || this.metadata.nationalPrefixIsOptionalWhenFormattingInNationalFormat();
      }
    }, {
      key: "nationalPrefixIsMandatoryWhenFormattingInNationalFormat",
      value: function nationalPrefixIsMandatoryWhenFormattingInNationalFormat() {
        return this.usesNationalPrefix() && !this.nationalPrefixIsOptionalWhenFormattingInNationalFormat();
      }
      // Checks whether national prefix formatting rule contains national prefix.
    }, {
      key: "usesNationalPrefix",
      value: function usesNationalPrefix() {
        return this.nationalPrefixFormattingRule() && // Check that national prefix formatting rule is not a "dummy" one.
        !FIRST_GROUP_ONLY_PREFIX_PATTERN.test(this.nationalPrefixFormattingRule()) ? true : false;
      }
    }, {
      key: "internationalFormat",
      value: function internationalFormat() {
        return this._format[5] || this.format();
      }
    }]);
  })();
  var FIRST_GROUP_ONLY_PREFIX_PATTERN = /^\(?\$1\)?$/;
  var Type = /* @__PURE__ */ (function() {
    function Type2(type, metadata3) {
      _classCallCheck(this, Type2);
      this.type = type;
      this.metadata = metadata3;
    }
    return _createClass(Type2, [{
      key: "pattern",
      value: function pattern() {
        if (this.metadata.v1) return this.type;
        return this.type[0];
      }
    }, {
      key: "possibleLengths",
      value: function possibleLengths() {
        if (this.metadata.v1) return;
        return this.type[1] || this.metadata.possibleLengths();
      }
    }]);
  })();
  function getType(types, type) {
    switch (type) {
      case "FIXED_LINE":
        return types[0];
      case "MOBILE":
        return types[1];
      case "TOLL_FREE":
        return types[2];
      case "PREMIUM_RATE":
        return types[3];
      case "PERSONAL_NUMBER":
        return types[4];
      case "VOICEMAIL":
        return types[5];
      case "UAN":
        return types[6];
      case "PAGER":
        return types[7];
      case "VOIP":
        return types[8];
      case "SHARED_COST":
        return types[9];
    }
  }
  function validateMetadata(metadata3) {
    if (!metadata3) {
      throw new Error("[libphonenumber-js] `metadata` argument not passed. Check your arguments.");
    }
    if (!isObject(metadata3) || !isObject(metadata3.countries)) {
      throw new Error("[libphonenumber-js] `metadata` argument was passed but it's not a valid metadata. Must be an object having `.countries` child object property. Got ".concat(isObject(metadata3) ? "an object of shape: { " + Object.keys(metadata3).join(", ") + " }" : "a " + typeOf(metadata3) + ": " + metadata3, "."));
    }
  }
  var typeOf = function typeOf2(_) {
    return _typeof(_);
  };
  function getCountryCallingCode(country, metadataJson) {
    var metadata3 = new Metadata(metadataJson);
    if (metadata3.hasCountry(country)) {
      return metadata3.selectNumberingPlan(country).countryCallingCode();
    }
    throw new Error("Unknown country: ".concat(country));
  }
  function isSupportedCountry(country, metadataJson) {
    return metadataJson.countries.hasOwnProperty(country);
  }
  function setVersion(metadata3) {
    var version = metadata3.version;
    if (typeof version === "number") {
      this.v1 = version === 1;
      this.v2 = version === 2;
      this.v3 = version === 3;
      this.v4 = version === 4;
    } else {
      if (!version) {
        this.v1 = true;
      } else if (semver_compare_default(version, V3) === -1) {
        this.v2 = true;
      } else if (semver_compare_default(version, V4) === -1) {
        this.v3 = true;
      } else {
        this.v4 = true;
      }
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/mergeArrays.js
  function _createForOfIteratorHelperLoose(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
      t && (r = t);
      var o = 0;
      return function() {
        return o >= r.length ? { done: true } : { done: false, value: r[o++] };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }
  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function mergeArrays(a, b) {
    var merged = a.slice();
    for (var _iterator = _createForOfIteratorHelperLoose(b), _step; !(_step = _iterator()).done; ) {
      var element = _step.value;
      if (a.indexOf(element) < 0) {
        merged.push(element);
      }
    }
    return merged.sort(function(a2, b2) {
      return a2 - b2;
    });
  }

  // node_modules/libphonenumber-js/es6/helpers/checkNumberLength.js
  function checkNumberLength(nationalNumber, country, metadata3) {
    return checkNumberLengthForType(nationalNumber, void 0, country, metadata3);
  }
  function checkNumberLengthForType(nationalNumber, type, country, metadata3) {
    if (country) {
      metadata3 = new Metadata(metadata3.metadata);
      metadata3.selectNumberingPlan(country);
    }
    var type_info = metadata3.type(type);
    var possible_lengths = type_info && type_info.possibleLengths() || metadata3.possibleLengths();
    if (!possible_lengths) {
      return "IS_POSSIBLE";
    }
    if (type === "FIXED_LINE_OR_MOBILE") {
      if (!metadata3.type("FIXED_LINE")) {
        return checkNumberLengthForType(nationalNumber, "MOBILE", country, metadata3);
      }
      var mobile_type = metadata3.type("MOBILE");
      if (mobile_type) {
        possible_lengths = mergeArrays(possible_lengths, mobile_type.possibleLengths());
      }
    } else if (type && !type_info) {
      return "INVALID_LENGTH";
    }
    var actual_length = nationalNumber.length;
    var minimum_length = possible_lengths[0];
    if (minimum_length === actual_length) {
      return "IS_POSSIBLE";
    }
    if (minimum_length > actual_length) {
      return "TOO_SHORT";
    }
    if (possible_lengths[possible_lengths.length - 1] < actual_length) {
      return "TOO_LONG";
    }
    return possible_lengths.indexOf(actual_length, 1) >= 0 ? "IS_POSSIBLE" : "INVALID_LENGTH";
  }

  // node_modules/libphonenumber-js/es6/isPossible.js
  function isPossiblePhoneNumber(input, options, metadataJson) {
    if (options === void 0) {
      options = {};
    }
    var metadata3 = new Metadata(metadataJson);
    if (options.v2) {
      if (!input.countryCallingCode) {
        throw new Error("Invalid phone number object passed");
      }
      metadata3.selectNumberingPlan(input.country || input.countryCallingCode);
    } else {
      if (!input.phone) {
        return false;
      }
      if (input.country) {
        if (!metadata3.hasCountry(input.country)) {
          throw new Error("Unknown country: ".concat(input.country));
        }
        metadata3.selectNumberingPlan(input.country);
      } else {
        if (!input.countryCallingCode) {
          throw new Error("Invalid phone number object passed");
        }
        metadata3.selectNumberingPlan(input.countryCallingCode);
      }
    }
    if (metadata3.possibleLengths()) {
      return isPossibleNumber(input.phone || input.nationalNumber, metadata3);
    }
    if (input.countryCallingCode && metadata3.isNonGeographicCallingCode(input.countryCallingCode)) {
      return true;
    }
    throw new Error('Missing "possibleLengths" in metadata. Perhaps the metadata has been generated before v1.0.18.');
  }
  function isPossibleNumber(nationalNumber, metadata3) {
    switch (checkNumberLength(nationalNumber, void 0, metadata3)) {
      case "IS_POSSIBLE":
        return true;
      // This library ignores "local-only" phone numbers (for simplicity).
      // See the readme for more info on what are "local-only" phone numbers.
      // case 'IS_POSSIBLE_LOCAL_ONLY':
      // 	return !isInternational
      default:
        return false;
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/matchesEntirely.js
  function matchesEntirely(text5, regularExpressionText) {
    text5 = text5 || "";
    return new RegExp("^(?:" + regularExpressionText + ")$").test(text5);
  }

  // node_modules/libphonenumber-js/es6/helpers/getNumberType.js
  function _createForOfIteratorHelperLoose2(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray2(r)) || e && r && "number" == typeof r.length) {
      t && (r = t);
      var o = 0;
      return function() {
        return o >= r.length ? { done: true } : { done: false, value: r[o++] };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray2(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray2(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray2(r, a) : void 0;
    }
  }
  function _arrayLikeToArray2(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  var NON_FIXED_LINE_PHONE_TYPES = ["MOBILE", "PREMIUM_RATE", "TOLL_FREE", "SHARED_COST", "VOIP", "PERSONAL_NUMBER", "PAGER", "UAN", "VOICEMAIL"];
  function getNumberType(input, options, metadataJson) {
    options = options || {};
    if (!input.country && !input.countryCallingCode) {
      return;
    }
    var metadata3 = new Metadata(metadataJson);
    metadata3.selectNumberingPlan(input.country || input.countryCallingCode);
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    if (!matchesEntirely(nationalNumber, metadata3.nationalNumberPattern())) {
      return;
    }
    if (isNumberTypeEqualTo(nationalNumber, "FIXED_LINE", metadata3)) {
      if (metadata3.type("MOBILE") && metadata3.type("MOBILE").pattern() === "") {
        return "FIXED_LINE_OR_MOBILE";
      }
      if (!metadata3.type("MOBILE")) {
        return "FIXED_LINE_OR_MOBILE";
      }
      if (isNumberTypeEqualTo(nationalNumber, "MOBILE", metadata3)) {
        return "FIXED_LINE_OR_MOBILE";
      }
      return "FIXED_LINE";
    }
    for (var _iterator = _createForOfIteratorHelperLoose2(NON_FIXED_LINE_PHONE_TYPES), _step; !(_step = _iterator()).done; ) {
      var type = _step.value;
      if (isNumberTypeEqualTo(nationalNumber, type, metadata3)) {
        return type;
      }
    }
  }
  function isNumberTypeEqualTo(nationalNumber, type, metadata3) {
    var typeDefinition = metadata3.type(type);
    if (!typeDefinition || !typeDefinition.pattern()) {
      return false;
    }
    if (typeDefinition.possibleLengths() && typeDefinition.possibleLengths().indexOf(nationalNumber.length) < 0) {
      return false;
    }
    return matchesEntirely(nationalNumber, typeDefinition.pattern());
  }

  // node_modules/libphonenumber-js/es6/isValid.js
  function isValidNumber(input, options, metadataJson) {
    options = options || {};
    var metadata3 = new Metadata(metadataJson);
    metadata3.selectNumberingPlan(input.country || input.countryCallingCode);
    if (metadata3.hasTypes()) {
      return getNumberType(input, options, metadata3.metadata) !== void 0;
    }
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    return matchesEntirely(nationalNumber, metadata3.nationalNumberPattern());
  }

  // node_modules/libphonenumber-js/es6/helpers/isCountryCode.js
  var COUNTRY_CODE_REG_EXP = /^[A-Z]{2}$/;
  function isCountryCode(string2) {
    return COUNTRY_CODE_REG_EXP.test(string2);
  }

  // node_modules/libphonenumber-js/es6/helpers/getCountryAndCallingCodeFromOneOfThem.js
  var USE_NON_GEOGRAPHIC_COUNTRY_CODE = false;
  function getCountryAndCallingCodeFromOneOfThem(countryOrCallingCode, metadataJson) {
    var country;
    var callingCode;
    var metadata3 = new Metadata(metadataJson);
    if (isCountryCode(countryOrCallingCode)) {
      country = countryOrCallingCode;
      metadata3.selectNumberingPlan(country);
      callingCode = metadata3.countryCallingCode();
    } else {
      callingCode = countryOrCallingCode;
      if (USE_NON_GEOGRAPHIC_COUNTRY_CODE) {
        if (metadata3.isNonGeographicCallingCode(callingCode)) {
          country = "001";
        }
      }
    }
    return {
      country,
      callingCode
    };
  }

  // node_modules/libphonenumber-js/es6/helpers/getPossibleCountriesForNumber.js
  function getPossibleCountriesForNumber(callingCode, nationalNumber, metadata3) {
    var _metadata = new Metadata(metadata3);
    var possibleCountries = _metadata.getCountryCodesForCallingCode(callingCode);
    if (!possibleCountries) {
      return [];
    }
    return possibleCountries.filter(function(country) {
      return couldNationalNumberBelongToCountry(nationalNumber, country, metadata3);
    });
  }
  function couldNationalNumberBelongToCountry(nationalNumber, country, metadataJson) {
    var metadata3 = new Metadata(metadataJson);
    metadata3.selectNumberingPlan(country);
    return metadata3.numberingPlan.possibleLengths().indexOf(nationalNumber.length) >= 0;
  }

  // node_modules/libphonenumber-js/es6/constants.js
  var MIN_LENGTH_FOR_NSN = 2;
  var MAX_LENGTH_FOR_NSN = 17;
  var MAX_LENGTH_COUNTRY_CODE = 3;
  var VALID_DIGITS = "0-9\uFF10-\uFF19\u0660-\u0669\u06F0-\u06F9";
  var DASHES = "-\u2010-\u2015\u2212\u30FC\uFF0D";
  var SLASHES = "\uFF0F/";
  var DOTS = "\uFF0E.";
  var WHITESPACE = " \xA0\xAD\u200B\u2060\u3000";
  var BRACKETS = "()\uFF08\uFF09\uFF3B\uFF3D\\[\\]";
  var TILDES = "~\u2053\u223C\uFF5E";
  var VALID_PUNCTUATION = "".concat(DASHES).concat(SLASHES).concat(DOTS).concat(WHITESPACE).concat(BRACKETS).concat(TILDES);
  var PLUS_CHARS = "+\uFF0B";

  // node_modules/libphonenumber-js/es6/helpers/stripIddPrefix.js
  var CAPTURING_DIGIT_PATTERN = new RegExp("([" + VALID_DIGITS + "])");
  function stripIddPrefix(number, country, callingCode, metadataJson) {
    if (!country) {
      return;
    }
    var metadata3 = new Metadata(metadataJson);
    metadata3.selectNumberingPlan(country || callingCode);
    var IDDPrefixPattern = new RegExp(metadata3.IDDPrefix());
    if (number.search(IDDPrefixPattern) !== 0) {
      return;
    }
    number = number.slice(number.match(IDDPrefixPattern)[0].length);
    var matchedGroups = number.match(CAPTURING_DIGIT_PATTERN);
    if (matchedGroups && matchedGroups[1] != null && matchedGroups[1].length > 0) {
      if (matchedGroups[1] === "0") {
        return;
      }
    }
    return number;
  }

  // node_modules/libphonenumber-js/es6/helpers/extractNationalNumberFromPossiblyIncompleteNumber.js
  function extractNationalNumberFromPossiblyIncompleteNumber(number, metadata3) {
    if (number && metadata3.numberingPlan.nationalPrefixForParsing()) {
      var prefixPattern = new RegExp("^(?:" + metadata3.numberingPlan.nationalPrefixForParsing() + ")");
      var prefixMatch = prefixPattern.exec(number);
      if (prefixMatch) {
        var nationalNumber;
        var carrierCode;
        var capturedGroupsCount = prefixMatch.length - 1;
        var hasCapturedGroups = capturedGroupsCount > 0 && prefixMatch[capturedGroupsCount];
        if (metadata3.nationalPrefixTransformRule() && hasCapturedGroups) {
          nationalNumber = number.replace(prefixPattern, metadata3.nationalPrefixTransformRule());
          if (capturedGroupsCount > 1) {
            carrierCode = prefixMatch[1];
          }
        } else {
          var prefixBeforeNationalNumber = prefixMatch[0];
          nationalNumber = number.slice(prefixBeforeNationalNumber.length);
          if (hasCapturedGroups) {
            carrierCode = prefixMatch[1];
          }
        }
        var nationalPrefix;
        if (hasCapturedGroups) {
          var possiblePositionOfTheFirstCapturedGroup = number.indexOf(prefixMatch[1]);
          var possibleNationalPrefix = number.slice(0, possiblePositionOfTheFirstCapturedGroup);
          if (possibleNationalPrefix === metadata3.numberingPlan.nationalPrefix()) {
            nationalPrefix = metadata3.numberingPlan.nationalPrefix();
          }
        } else {
          nationalPrefix = prefixMatch[0];
        }
        return {
          nationalNumber,
          nationalPrefix,
          carrierCode
        };
      }
    }
    return {
      nationalNumber: number
    };
  }

  // node_modules/libphonenumber-js/es6/helpers/getCountryByNationalNumber.js
  function _createForOfIteratorHelperLoose3(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray3(r)) || e && r && "number" == typeof r.length) {
      t && (r = t);
      var o = 0;
      return function() {
        return o >= r.length ? { done: true } : { done: false, value: r[o++] };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray3(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray3(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray3(r, a) : void 0;
    }
  }
  function _arrayLikeToArray3(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function getCountryByNationalNumber(nationalNumber, countries, metadataJson) {
    var metadata3 = new Metadata(metadataJson);
    for (var _iterator = _createForOfIteratorHelperLoose3(countries), _step; !(_step = _iterator()).done; ) {
      var country = _step.value;
      metadata3.selectNumberingPlan(country);
      if (metadata3.leadingDigits()) {
        if (nationalNumber && nationalNumber.search(metadata3.leadingDigits()) === 0) {
          return country;
        }
      } else if (getNumberType({
        phone: nationalNumber,
        country
      }, void 0, metadata3.metadata)) {
        return country;
      }
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/getCountryByCallingCode.js
  var USE_NON_GEOGRAPHIC_COUNTRY_CODE2 = false;
  function getCountryByCallingCode(callingCode, _ref) {
    var nationalNumber = _ref.nationalNumber, metadata3 = _ref.metadata;
    if (USE_NON_GEOGRAPHIC_COUNTRY_CODE2) {
      if (metadata3.isNonGeographicCallingCode(callingCode)) {
        return "001";
      }
    }
    var possibleCountries = metadata3.getCountryCodesForCallingCode(callingCode);
    if (!possibleCountries) {
      return;
    }
    if (possibleCountries.length === 1) {
      return possibleCountries[0];
    }
    return getCountryByNationalNumber(nationalNumber, possibleCountries, metadata3.metadata);
  }

  // node_modules/libphonenumber-js/es6/helpers/extractNationalNumber.js
  function extractNationalNumber(number, country, metadata3) {
    var _extractNationalNumbe = extractNationalNumberFromPossiblyIncompleteNumber(number, metadata3), carrierCode = _extractNationalNumbe.carrierCode, nationalNumber = _extractNationalNumbe.nationalNumber;
    if (nationalNumber !== number) {
      if (!shouldHaveExtractedNationalPrefix(number, nationalNumber, metadata3)) {
        return {
          nationalNumber: number
        };
      }
      if (metadata3.numberingPlan.possibleLengths()) {
        if (!country) {
          country = getCountryByCallingCode(metadata3.numberingPlan.callingCode(), {
            nationalNumber,
            metadata: metadata3
          });
        }
        if (!isPossibleIncompleteNationalNumber(nationalNumber, country, metadata3)) {
          return {
            nationalNumber: number
          };
        }
      }
    }
    return {
      nationalNumber,
      carrierCode
    };
  }
  function shouldHaveExtractedNationalPrefix(nationalNumberBefore, nationalNumberAfter, metadata3) {
    if (matchesEntirely(nationalNumberBefore, metadata3.nationalNumberPattern()) && !matchesEntirely(nationalNumberAfter, metadata3.nationalNumberPattern())) {
      return false;
    }
    return true;
  }
  function isPossibleIncompleteNationalNumber(nationalNumber, country, metadata3) {
    switch (checkNumberLength(nationalNumber, country, metadata3)) {
      case "TOO_SHORT":
      case "INVALID_LENGTH":
        return false;
      default:
        return true;
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCodeFromInternationalNumberWithoutPlusSign.js
  function extractCountryCallingCodeFromInternationalNumberWithoutPlusSign(number, country, defaultCountry, defaultCallingCode, metadataJson) {
    if (!(country || defaultCountry || defaultCallingCode)) {
      return {
        number
      };
    }
    var countryCallingCode = country || defaultCountry ? getCountryCallingCode(country || defaultCountry, metadataJson) : defaultCallingCode;
    if (number.indexOf(countryCallingCode) === 0) {
      var metadata3 = new Metadata(metadataJson);
      metadata3.selectNumberingPlan(country || defaultCountry || defaultCallingCode);
      var possibleShorterNumber = number.slice(countryCallingCode.length);
      var _extractNationalNumbe = extractNationalNumber(possibleShorterNumber, void 0, metadata3), possibleShorterNationalNumber = _extractNationalNumbe.nationalNumber;
      var _extractNationalNumbe2 = extractNationalNumber(number, void 0, metadata3), nationalNumber = _extractNationalNumbe2.nationalNumber;
      if (!matchesEntirely(nationalNumber, metadata3.nationalNumberPattern()) && matchesEntirely(possibleShorterNationalNumber, metadata3.nationalNumberPattern()) || checkNumberLength(nationalNumber, void 0, metadata3) === "TOO_LONG") {
        return {
          countryCallingCode,
          number: possibleShorterNumber
        };
      }
    }
    return {
      number
    };
  }

  // node_modules/libphonenumber-js/es6/helpers/extractCountryCallingCode.js
  function extractCountryCallingCode(number, country, defaultCountry, defaultCallingCode, metadataJson) {
    if (!number) {
      return {};
    }
    var isNumberWithIddPrefix;
    if (number[0] !== "+") {
      var numberWithoutIDD = stripIddPrefix(number, country || defaultCountry, defaultCallingCode, metadataJson);
      if (numberWithoutIDD && numberWithoutIDD !== number) {
        isNumberWithIddPrefix = true;
        number = "+" + numberWithoutIDD;
      } else {
        if (country || defaultCountry || defaultCallingCode) {
          var _extractCountryCallin = extractCountryCallingCodeFromInternationalNumberWithoutPlusSign(number, country, defaultCountry, defaultCallingCode, metadataJson), countryCallingCode = _extractCountryCallin.countryCallingCode, shorterNumber = _extractCountryCallin.number;
          if (countryCallingCode) {
            return {
              countryCallingCodeSource: "FROM_NUMBER_WITHOUT_PLUS_SIGN",
              countryCallingCode,
              number: shorterNumber
            };
          }
        }
        return {
          // No need to set it to `UNSPECIFIED`. It can be just `undefined`.
          // countryCallingCodeSource: 'UNSPECIFIED',
          number
        };
      }
    }
    if (number[1] === "0") {
      return {};
    }
    var metadata3 = new Metadata(metadataJson);
    var i = 2;
    while (i - 1 <= MAX_LENGTH_COUNTRY_CODE && i <= number.length) {
      var _countryCallingCode = number.slice(1, i);
      if (metadata3.hasCallingCode(_countryCallingCode)) {
        metadata3.selectNumberingPlan(_countryCallingCode);
        return {
          countryCallingCodeSource: isNumberWithIddPrefix ? "FROM_NUMBER_WITH_IDD" : "FROM_NUMBER_WITH_PLUS_SIGN",
          countryCallingCode: _countryCallingCode,
          number: number.slice(i)
        };
      }
      i++;
    }
    return {};
  }

  // node_modules/libphonenumber-js/es6/helpers/applyInternationalSeparatorStyle.js
  function applyInternationalSeparatorStyle(formattedNumber) {
    return formattedNumber.replace(new RegExp("[".concat(VALID_PUNCTUATION, "]+"), "g"), " ").trim();
  }

  // node_modules/libphonenumber-js/es6/helpers/formatNationalNumberUsingFormat.js
  var FIRST_GROUP_PATTERN = /(\$\d)/;
  function formatNationalNumberUsingFormat(number, format, _ref) {
    var useInternationalFormat = _ref.useInternationalFormat, withNationalPrefix = _ref.withNationalPrefix, carrierCode = _ref.carrierCode, metadata3 = _ref.metadata;
    var formattedNumber = number.replace(new RegExp(format.pattern()), useInternationalFormat ? format.internationalFormat() : (
      // This library doesn't use `domestic_carrier_code_formatting_rule`,
      // because that one is only used when formatting phone numbers
      // for dialing from a mobile phone, and this is not a dialing library.
      // carrierCode && format.domesticCarrierCodeFormattingRule()
      // 	// First, replace the $CC in the formatting rule with the desired carrier code.
      // 	// Then, replace the $FG in the formatting rule with the first group
      // 	// and the carrier code combined in the appropriate way.
      // 	? format.format().replace(FIRST_GROUP_PATTERN, format.domesticCarrierCodeFormattingRule().replace('$CC', carrierCode))
      // 	: (
      // 		withNationalPrefix && format.nationalPrefixFormattingRule()
      // 			? format.format().replace(FIRST_GROUP_PATTERN, format.nationalPrefixFormattingRule())
      // 			: format.format()
      // 	)
      withNationalPrefix && format.nationalPrefixFormattingRule() ? format.format().replace(FIRST_GROUP_PATTERN, format.nationalPrefixFormattingRule()) : format.format()
    ));
    if (useInternationalFormat) {
      return applyInternationalSeparatorStyle(formattedNumber);
    }
    return formattedNumber;
  }

  // node_modules/libphonenumber-js/es6/helpers/getIddPrefix.js
  var SINGLE_IDD_PREFIX_REG_EXP = /^[\d]+(?:[~\u2053\u223C\uFF5E][\d]+)?$/;
  function getIddPrefix(country, callingCode, metadata3) {
    var countryMetadata = new Metadata(metadata3);
    countryMetadata.selectNumberingPlan(country || callingCode);
    if (countryMetadata.defaultIDDPrefix()) {
      return countryMetadata.defaultIDDPrefix();
    }
    if (SINGLE_IDD_PREFIX_REG_EXP.test(countryMetadata.IDDPrefix())) {
      return countryMetadata.IDDPrefix();
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/extension/createExtensionPattern.js
  var RFC3966_EXTN_PREFIX = ";ext=";
  var getExtensionDigitsPattern = function getExtensionDigitsPattern2(maxLength) {
    return "([".concat(VALID_DIGITS, "]{1,").concat(maxLength, "})");
  };
  function createExtensionPattern(purpose) {
    var extLimitAfterExplicitLabel = "20";
    var extLimitAfterLikelyLabel = "15";
    var extLimitAfterAmbiguousChar = "9";
    var extLimitWhenNotSure = "6";
    var possibleSeparatorsBetweenNumberAndExtLabel = "[ \xA0\\t,]*";
    var possibleCharsAfterExtLabel = "[:\\.\uFF0E]?[ \xA0\\t,-]*";
    var optionalExtnSuffix = "#?";
    var explicitExtLabels = "(?:e?xt(?:ensi(?:o\u0301?|\xF3))?n?|\uFF45?\uFF58\uFF54\uFF4E?|\u0434\u043E\u0431|anexo)";
    var ambiguousExtLabels = "(?:[x\uFF58#\uFF03~\uFF5E]|int|\uFF49\uFF4E\uFF54)";
    var ambiguousSeparator = "[- ]+";
    var possibleSeparatorsNumberExtLabelNoComma = "[ \xA0\\t]*";
    var autoDiallingAndExtLabelsFound = "(?:,{2}|;)";
    var rfcExtn = RFC3966_EXTN_PREFIX + getExtensionDigitsPattern(extLimitAfterExplicitLabel);
    var explicitExtn = possibleSeparatorsBetweenNumberAndExtLabel + explicitExtLabels + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterExplicitLabel) + optionalExtnSuffix;
    var ambiguousExtn = possibleSeparatorsBetweenNumberAndExtLabel + ambiguousExtLabels + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterAmbiguousChar) + optionalExtnSuffix;
    var americanStyleExtnWithSuffix = ambiguousSeparator + getExtensionDigitsPattern(extLimitWhenNotSure) + "#";
    var autoDiallingExtn = possibleSeparatorsNumberExtLabelNoComma + autoDiallingAndExtLabelsFound + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterLikelyLabel) + optionalExtnSuffix;
    var onlyCommasExtn = possibleSeparatorsNumberExtLabelNoComma + "(?:,)+" + possibleCharsAfterExtLabel + getExtensionDigitsPattern(extLimitAfterAmbiguousChar) + optionalExtnSuffix;
    return rfcExtn + "|" + explicitExtn + "|" + ambiguousExtn + "|" + americanStyleExtnWithSuffix + "|" + autoDiallingExtn + "|" + onlyCommasExtn;
  }

  // node_modules/libphonenumber-js/es6/helpers/isViablePhoneNumber.js
  var MIN_LENGTH_PHONE_NUMBER_PATTERN = "[" + VALID_DIGITS + "]{" + MIN_LENGTH_FOR_NSN + "}";
  var VALID_PHONE_NUMBER = "[" + PLUS_CHARS + "]{0,1}(?:[" + VALID_PUNCTUATION + "]*[" + VALID_DIGITS + "]){3,}[" + VALID_PUNCTUATION + VALID_DIGITS + "]*";
  var VALID_PHONE_NUMBER_START_REG_EXP = new RegExp("^[" + PLUS_CHARS + "]{0,1}(?:[" + VALID_PUNCTUATION + "]*[" + VALID_DIGITS + "]){1,2}$", "i");
  var VALID_PHONE_NUMBER_WITH_EXTENSION = VALID_PHONE_NUMBER + // Phone number extensions
  "(?:" + createExtensionPattern() + ")?";
  var VALID_PHONE_NUMBER_PATTERN = new RegExp(
    // Either a short two-digit-only phone number
    "^" + MIN_LENGTH_PHONE_NUMBER_PATTERN + "$|^" + VALID_PHONE_NUMBER_WITH_EXTENSION + "$",
    "i"
  );
  function isViablePhoneNumber(number) {
    return number.length >= MIN_LENGTH_FOR_NSN && VALID_PHONE_NUMBER_PATTERN.test(number);
  }
  function isViablePhoneNumberStart(number) {
    return VALID_PHONE_NUMBER_START_REG_EXP.test(number);
  }

  // node_modules/libphonenumber-js/es6/helpers/RFC3966.js
  function formatRFC3966(_ref) {
    var number = _ref.number, ext = _ref.ext;
    if (!number) {
      return "";
    }
    if (number[0] !== "+") {
      throw new Error('"formatRFC3966()" expects "number" to be in E.164 format.');
    }
    return "tel:".concat(number).concat(ext ? ";ext=" + ext : "");
  }

  // node_modules/libphonenumber-js/es6/format.js
  var DEFAULT_OPTIONS = {
    formatExtension: function formatExtension(formattedNumber, extension, metadata3) {
      return "".concat(formattedNumber).concat(metadata3.ext()).concat(extension);
    }
  };
  function formatNumber(input, format, options, metadataJson) {
    if (options) {
      options = merge({}, DEFAULT_OPTIONS, options);
    } else {
      options = DEFAULT_OPTIONS;
    }
    var metadata3 = new Metadata(metadataJson);
    if (input.country && input.country !== "001") {
      if (!metadata3.hasCountry(input.country)) {
        throw new Error("Unknown country: ".concat(input.country));
      }
      metadata3.selectNumberingPlan(input.country);
    } else if (input.countryCallingCode) {
      metadata3.selectNumberingPlan(input.countryCallingCode);
    } else return input.phone || "";
    var countryCallingCode = metadata3.countryCallingCode();
    var nationalNumber = options.v2 ? input.nationalNumber : input.phone;
    var number;
    switch (format) {
      case "NATIONAL":
        if (!nationalNumber) {
          return "";
        }
        number = formatNationalNumber(nationalNumber, input.carrierCode, "NATIONAL", metadata3, options);
        return addExtension(number, input.ext, metadata3, options.formatExtension);
      case "INTERNATIONAL":
        if (!nationalNumber) {
          return "+".concat(countryCallingCode);
        }
        number = formatNationalNumber(nationalNumber, null, "INTERNATIONAL", metadata3, options);
        number = "+".concat(countryCallingCode, " ").concat(number);
        return addExtension(number, input.ext, metadata3, options.formatExtension);
      case "E.164":
        return "+".concat(countryCallingCode).concat(nationalNumber);
      case "RFC3966":
        return formatRFC3966({
          number: "+".concat(countryCallingCode).concat(nationalNumber),
          ext: input.ext
        });
      // For reference, here's Google's IDD formatter:
      // https://github.com/google/libphonenumber/blob/32719cf74e68796788d1ca45abc85dcdc63ba5b9/java/libphonenumber/src/com/google/i18n/phonenumbers/PhoneNumberUtil.java#L1546
      // Not saying that this IDD formatter replicates it 1:1, but it seems to work.
      // Who would even need to format phone numbers in IDD format anyway?
      case "IDD":
        if (!options.fromCountry) {
          return;
        }
        var formattedNumber = formatIDD(nationalNumber, input.carrierCode, countryCallingCode, options.fromCountry, metadata3);
        if (!formattedNumber) {
          return;
        }
        return addExtension(formattedNumber, input.ext, metadata3, options.formatExtension);
      default:
        throw new Error('Unknown "format" argument passed to "formatNumber()": "'.concat(format, '"'));
    }
  }
  function formatNationalNumber(number, carrierCode, formatAs, metadata3, options) {
    var format = chooseFormatForNumber(metadata3.formats(), number);
    if (!format) {
      return number;
    }
    return formatNationalNumberUsingFormat(number, format, {
      useInternationalFormat: formatAs === "INTERNATIONAL",
      withNationalPrefix: format.nationalPrefixIsOptionalWhenFormattingInNationalFormat() && options && options.nationalPrefix === false ? false : true,
      carrierCode,
      metadata: metadata3
    });
  }
  function chooseFormatForNumber(availableFormats, nationalNumber) {
    return pickFirstMatchingElement(availableFormats, function(format) {
      if (format.leadingDigitsPatterns().length > 0) {
        var lastLeadingDigitsPattern = format.leadingDigitsPatterns()[format.leadingDigitsPatterns().length - 1];
        if (nationalNumber.search(lastLeadingDigitsPattern) !== 0) {
          return false;
        }
      }
      return matchesEntirely(nationalNumber, format.pattern());
    });
  }
  function addExtension(formattedNumber, ext, metadata3, formatExtension2) {
    return ext ? formatExtension2(formattedNumber, ext, metadata3) : formattedNumber;
  }
  function formatIDD(nationalNumber, carrierCode, countryCallingCode, fromCountry, metadata3) {
    var fromCountryCallingCode = getCountryCallingCode(fromCountry, metadata3.metadata);
    if (fromCountryCallingCode === countryCallingCode) {
      var formattedNumber = formatNationalNumber(nationalNumber, carrierCode, "NATIONAL", metadata3);
      if (countryCallingCode === "1") {
        return countryCallingCode + " " + formattedNumber;
      }
      return formattedNumber;
    }
    var iddPrefix = getIddPrefix(fromCountry, void 0, metadata3.metadata);
    if (iddPrefix) {
      return "".concat(iddPrefix, " ").concat(countryCallingCode, " ").concat(formatNationalNumber(nationalNumber, null, "INTERNATIONAL", metadata3));
    }
  }
  function merge() {
    var i = 1;
    for (var _len = arguments.length, objects = new Array(_len), _key = 0; _key < _len; _key++) {
      objects[_key] = arguments[_key];
    }
    while (i < objects.length) {
      if (objects[i]) {
        for (var key in objects[i]) {
          objects[0][key] = objects[i][key];
        }
      }
      i++;
    }
    return objects[0];
  }
  function pickFirstMatchingElement(elements, testFunction) {
    var i = 0;
    while (i < elements.length) {
      if (testFunction(elements[i])) {
        return elements[i];
      }
      i++;
    }
  }

  // node_modules/libphonenumber-js/es6/PhoneNumber.js
  function _typeof2(o) {
    "@babel/helpers - typeof";
    return _typeof2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof2(o);
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function(r2) {
        return Object.getOwnPropertyDescriptor(e, r2).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
        _defineProperty(e, r2, t[r2]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
        Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
      });
    }
    return e;
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey2(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
  }
  function _classCallCheck2(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties2(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey2(o.key), o);
    }
  }
  function _createClass2(e, r, t) {
    return r && _defineProperties2(e.prototype, r), t && _defineProperties2(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
  }
  function _toPropertyKey2(t) {
    var i = _toPrimitive2(t, "string");
    return "symbol" == _typeof2(i) ? i : i + "";
  }
  function _toPrimitive2(t, r) {
    if ("object" != _typeof2(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof2(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  var PhoneNumber = /* @__PURE__ */ (function() {
    function PhoneNumber2(countryOrCountryCallingCode, nationalNumber, metadata3) {
      _classCallCheck2(this, PhoneNumber2);
      if (!countryOrCountryCallingCode) {
        throw new TypeError("First argument is required");
      }
      if (typeof countryOrCountryCallingCode !== "string") {
        throw new TypeError("First argument must be a string");
      }
      if (countryOrCountryCallingCode[0] === "+" && !nationalNumber) {
        throw new TypeError("`metadata` argument not passed");
      }
      if (isObject(nationalNumber) && isObject(nationalNumber.countries)) {
        metadata3 = nationalNumber;
        var e164Number = countryOrCountryCallingCode;
        if (!E164_NUMBER_REGEXP.test(e164Number)) {
          throw new Error('Invalid `number` argument passed: must consist of a "+" followed by digits');
        }
        var _extractCountryCallin = extractCountryCallingCode(e164Number, void 0, void 0, void 0, metadata3), _countryCallingCode = _extractCountryCallin.countryCallingCode, number = _extractCountryCallin.number;
        nationalNumber = number;
        countryOrCountryCallingCode = _countryCallingCode;
        if (!nationalNumber) {
          throw new Error("Invalid `number` argument passed: too short");
        }
      }
      if (!nationalNumber) {
        throw new TypeError("`nationalNumber` argument is required");
      }
      if (typeof nationalNumber !== "string") {
        throw new TypeError("`nationalNumber` argument must be a string");
      }
      validateMetadata(metadata3);
      var _getCountryAndCalling = getCountryAndCallingCodeFromOneOfThem(countryOrCountryCallingCode, metadata3), country = _getCountryAndCalling.country, countryCallingCode = _getCountryAndCalling.callingCode;
      this.country = country;
      this.countryCallingCode = countryCallingCode;
      this.nationalNumber = nationalNumber;
      this.number = "+" + this.countryCallingCode + this.nationalNumber;
      this.getMetadata = function() {
        return metadata3;
      };
    }
    return _createClass2(PhoneNumber2, [{
      key: "setExt",
      value: function setExt(ext) {
        this.ext = ext;
      }
    }, {
      key: "getPossibleCountries",
      value: function getPossibleCountries() {
        if (this.country) {
          return [this.country];
        }
        return getPossibleCountriesForNumber(this.countryCallingCode, this.nationalNumber, this.getMetadata());
      }
    }, {
      key: "isPossible",
      value: function isPossible() {
        return isPossiblePhoneNumber(this, {
          v2: true
        }, this.getMetadata());
      }
    }, {
      key: "isValid",
      value: function isValid() {
        return isValidNumber(this, {
          v2: true
        }, this.getMetadata());
      }
    }, {
      key: "isNonGeographic",
      value: function isNonGeographic() {
        var metadata3 = new Metadata(this.getMetadata());
        return metadata3.isNonGeographicCallingCode(this.countryCallingCode);
      }
    }, {
      key: "isEqual",
      value: function isEqual(phoneNumber) {
        return this.number === phoneNumber.number && this.ext === phoneNumber.ext;
      }
      // `validateLength()` method was originally meant to be an equivalent for `validatePhoneNumberLength()`.
      //
      // Later, it became apparent that it's not really a true equivalent.
      // The reason is that a `PhoneNumber` instance is not created
      // when the phone number string is too short for it to be considered a valid phone number:
      // * When there must be at least 2 national (significant) number digits: `"1"`.
      // * When the country calling code part of an international number is incomplete: `"+12"`.
      //
      // So leaving this `validateLength()` method here would suggest a hidden anti-pattern
      // of using it instead of `validatePhoneNumberLength()` while ignoring
      // the "too short to be even possible" case from phone number length validation.
      // And ignoring that case wouldn't make any sense in a real-world application
      // because it would still be a valid case that should be handled.
      //
      // Because of that, this method was eventually commented out in order to not introduce
      // that kind of an anti-pattern.
      //
      // validateLength() {
      // 	const result = checkNumberLength(
      // 		this.nationalNumber,
      // 		undefined,
      // 		this.getMetadata()
      // 	)
      // 	if (result !== 'IS_POSSIBLE') {
      // 		return result
      // 	}
      // }
    }, {
      key: "getType",
      value: function getType2() {
        return getNumberType(this, {
          v2: true
        }, this.getMetadata());
      }
    }, {
      key: "format",
      value: function format(_format, options) {
        return formatNumber(this, _format, options ? _objectSpread(_objectSpread({}, options), {}, {
          v2: true
        }) : {
          v2: true
        }, this.getMetadata());
      }
    }, {
      key: "formatNational",
      value: function formatNational(options) {
        return this.format("NATIONAL", options);
      }
    }, {
      key: "formatInternational",
      value: function formatInternational(options) {
        return this.format("INTERNATIONAL", options);
      }
    }, {
      key: "getURI",
      value: function getURI(options) {
        return this.format("RFC3966", options);
      }
    }]);
  })();
  var E164_NUMBER_REGEXP = /^\+\d+$/;

  // node_modules/libphonenumber-js/es6/ParseError.js
  function _typeof3(o) {
    "@babel/helpers - typeof";
    return _typeof3 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof3(o);
  }
  function _defineProperties3(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey3(o.key), o);
    }
  }
  function _createClass3(e, r, t) {
    return r && _defineProperties3(e.prototype, r), t && _defineProperties3(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
  }
  function _toPropertyKey3(t) {
    var i = _toPrimitive3(t, "string");
    return "symbol" == _typeof3(i) ? i : i + "";
  }
  function _toPrimitive3(t, r) {
    if ("object" != _typeof3(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof3(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _classCallCheck3(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _possibleConstructorReturn(t, e) {
    if (e && ("object" == _typeof3(e) || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return _assertThisInitialized(t);
  }
  function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: true, configurable: true } }), Object.defineProperty(t, "prototype", { writable: false }), e && _setPrototypeOf(t, e);
  }
  function _wrapNativeSuper(t) {
    var r = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
    return _wrapNativeSuper = function _wrapNativeSuper2(t2) {
      if (null === t2 || !_isNativeFunction(t2)) return t2;
      if ("function" != typeof t2) throw new TypeError("Super expression must either be null or a function");
      if (void 0 !== r) {
        if (r.has(t2)) return r.get(t2);
        r.set(t2, Wrapper);
      }
      function Wrapper() {
        return _construct(t2, arguments, _getPrototypeOf(this).constructor);
      }
      return Wrapper.prototype = Object.create(t2.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }), _setPrototypeOf(Wrapper, t2);
    }, _wrapNativeSuper(t);
  }
  function _construct(t, e, r) {
    if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
    var o = [null];
    o.push.apply(o, e);
    var p = new (t.bind.apply(t, o))();
    return r && _setPrototypeOf(p, r.prototype), p;
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
      }));
    } catch (t2) {
    }
    return (_isNativeReflectConstruct = function _isNativeReflectConstruct2() {
      return !!t;
    })();
  }
  function _isNativeFunction(t) {
    try {
      return -1 !== Function.toString.call(t).indexOf("[native code]");
    } catch (n) {
      return "function" == typeof t;
    }
  }
  function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t2, e2) {
      return t2.__proto__ = e2, t2;
    }, _setPrototypeOf(t, e);
  }
  function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t2) {
      return t2.__proto__ || Object.getPrototypeOf(t2);
    }, _getPrototypeOf(t);
  }
  var ParseError = /* @__PURE__ */ (function(_Error) {
    function ParseError2(code) {
      var _this;
      _classCallCheck3(this, ParseError2);
      _this = _callSuper(this, ParseError2, [code]);
      Object.setPrototypeOf(_this, ParseError2.prototype);
      _this.name = _this.constructor.name;
      return _this;
    }
    _inherits(ParseError2, _Error);
    return _createClass3(ParseError2);
  })(/* @__PURE__ */ _wrapNativeSuper(Error));

  // node_modules/libphonenumber-js/es6/helpers/extension/extractExtension.js
  var EXTN_PATTERN = new RegExp("(?:" + createExtensionPattern() + ")$", "i");
  function extractExtension(number) {
    var start = number.search(EXTN_PATTERN);
    if (start < 0) {
      return {};
    }
    var numberWithoutExtension = number.slice(0, start);
    var matches = number.match(EXTN_PATTERN);
    var i = 1;
    while (i < matches.length) {
      if (matches[i]) {
        return {
          number: numberWithoutExtension,
          ext: matches[i]
        };
      }
      i++;
    }
  }

  // node_modules/libphonenumber-js/es6/helpers/parseDigits.js
  var DIGITS = {
    "0": "0",
    "1": "1",
    "2": "2",
    "3": "3",
    "4": "4",
    "5": "5",
    "6": "6",
    "7": "7",
    "8": "8",
    "9": "9",
    "\uFF10": "0",
    // Fullwidth digit 0
    "\uFF11": "1",
    // Fullwidth digit 1
    "\uFF12": "2",
    // Fullwidth digit 2
    "\uFF13": "3",
    // Fullwidth digit 3
    "\uFF14": "4",
    // Fullwidth digit 4
    "\uFF15": "5",
    // Fullwidth digit 5
    "\uFF16": "6",
    // Fullwidth digit 6
    "\uFF17": "7",
    // Fullwidth digit 7
    "\uFF18": "8",
    // Fullwidth digit 8
    "\uFF19": "9",
    // Fullwidth digit 9
    "\u0660": "0",
    // Arabic-indic digit 0
    "\u0661": "1",
    // Arabic-indic digit 1
    "\u0662": "2",
    // Arabic-indic digit 2
    "\u0663": "3",
    // Arabic-indic digit 3
    "\u0664": "4",
    // Arabic-indic digit 4
    "\u0665": "5",
    // Arabic-indic digit 5
    "\u0666": "6",
    // Arabic-indic digit 6
    "\u0667": "7",
    // Arabic-indic digit 7
    "\u0668": "8",
    // Arabic-indic digit 8
    "\u0669": "9",
    // Arabic-indic digit 9
    "\u06F0": "0",
    // Eastern-Arabic digit 0
    "\u06F1": "1",
    // Eastern-Arabic digit 1
    "\u06F2": "2",
    // Eastern-Arabic digit 2
    "\u06F3": "3",
    // Eastern-Arabic digit 3
    "\u06F4": "4",
    // Eastern-Arabic digit 4
    "\u06F5": "5",
    // Eastern-Arabic digit 5
    "\u06F6": "6",
    // Eastern-Arabic digit 6
    "\u06F7": "7",
    // Eastern-Arabic digit 7
    "\u06F8": "8",
    // Eastern-Arabic digit 8
    "\u06F9": "9"
    // Eastern-Arabic digit 9
  };
  function parseDigit(character) {
    return DIGITS[character];
  }

  // node_modules/libphonenumber-js/es6/parseIncompletePhoneNumber.js
  function _createForOfIteratorHelperLoose4(r, e) {
    var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (t) return (t = t.call(r)).next.bind(t);
    if (Array.isArray(r) || (t = _unsupportedIterableToArray4(r)) || e && r && "number" == typeof r.length) {
      t && (r = t);
      var o = 0;
      return function() {
        return o >= r.length ? { done: true } : { done: false, value: r[o++] };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray4(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray4(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray4(r, a) : void 0;
    }
  }
  function _arrayLikeToArray4(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function parseIncompletePhoneNumber(string2) {
    var result2 = "";
    for (var _iterator = _createForOfIteratorHelperLoose4(string2.split("")), _step; !(_step = _iterator()).done; ) {
      var character = _step.value;
      result2 += parsePhoneNumberCharacter(character, result2) || "";
    }
    return result2;
  }
  function parsePhoneNumberCharacter(character, prevParsedCharacters, eventListener) {
    if (character === "+") {
      if (prevParsedCharacters) {
        if (typeof eventListener === "function") {
          eventListener("end");
        }
        return;
      }
      return "+";
    }
    return parseDigit(character);
  }

  // node_modules/libphonenumber-js/es6/helpers/extractPhoneContext.js
  var PLUS_SIGN = "+";
  var RFC3966_VISUAL_SEPARATOR_ = "[\\-\\.\\(\\)]?";
  var RFC3966_PHONE_DIGIT_ = "([" + VALID_DIGITS + "]|" + RFC3966_VISUAL_SEPARATOR_ + ")";
  var RFC3966_GLOBAL_NUMBER_DIGITS_ = "^\\" + PLUS_SIGN + RFC3966_PHONE_DIGIT_ + "*[" + VALID_DIGITS + "]" + RFC3966_PHONE_DIGIT_ + "*$";
  var RFC3966_GLOBAL_NUMBER_DIGITS_PATTERN_ = new RegExp(RFC3966_GLOBAL_NUMBER_DIGITS_, "g");
  var ALPHANUM_ = VALID_DIGITS;
  var RFC3966_DOMAINLABEL_ = "[" + ALPHANUM_ + "]+((\\-)*[" + ALPHANUM_ + "])*";
  var VALID_ALPHA_ = "a-zA-Z";
  var RFC3966_TOPLABEL_ = "[" + VALID_ALPHA_ + "]+((\\-)*[" + ALPHANUM_ + "])*";
  var RFC3966_DOMAINNAME_ = "^(" + RFC3966_DOMAINLABEL_ + "\\.)*" + RFC3966_TOPLABEL_ + "\\.?$";
  var RFC3966_DOMAINNAME_PATTERN_ = new RegExp(RFC3966_DOMAINNAME_, "g");
  var RFC3966_PREFIX_ = "tel:";
  var RFC3966_PHONE_CONTEXT_ = ";phone-context=";
  var RFC3966_ISDN_SUBADDRESS_ = ";isub=";
  function extractPhoneContext(numberToExtractFrom) {
    var indexOfPhoneContext = numberToExtractFrom.indexOf(RFC3966_PHONE_CONTEXT_);
    if (indexOfPhoneContext < 0) {
      return null;
    }
    var phoneContextStart = indexOfPhoneContext + RFC3966_PHONE_CONTEXT_.length;
    if (phoneContextStart >= numberToExtractFrom.length) {
      return "";
    }
    var phoneContextEnd = numberToExtractFrom.indexOf(";", phoneContextStart);
    if (phoneContextEnd >= 0) {
      return numberToExtractFrom.substring(phoneContextStart, phoneContextEnd);
    } else {
      return numberToExtractFrom.substring(phoneContextStart);
    }
  }
  function isPhoneContextValid(phoneContext) {
    if (phoneContext === null) {
      return true;
    }
    if (phoneContext.length === 0) {
      return false;
    }
    return RFC3966_GLOBAL_NUMBER_DIGITS_PATTERN_.test(phoneContext) || RFC3966_DOMAINNAME_PATTERN_.test(phoneContext);
  }

  // node_modules/libphonenumber-js/es6/helpers/extractFormattedPhoneNumberFromPossibleRfc3966NumberUri.js
  function extractFormattedPhoneNumberFromPossibleRfc3966NumberUri(numberToParse, _ref) {
    var extractFormattedPhoneNumber = _ref.extractFormattedPhoneNumber;
    var phoneContext = extractPhoneContext(numberToParse);
    if (!isPhoneContextValid(phoneContext)) {
      throw new ParseError("NOT_A_NUMBER");
    }
    var phoneNumberString;
    if (phoneContext === null) {
      phoneNumberString = extractFormattedPhoneNumber(numberToParse) || "";
    } else {
      phoneNumberString = "";
      if (phoneContext.charAt(0) === PLUS_SIGN) {
        phoneNumberString += phoneContext;
      }
      var indexOfRfc3966Prefix = numberToParse.indexOf(RFC3966_PREFIX_);
      var indexOfNationalNumber;
      if (indexOfRfc3966Prefix >= 0) {
        indexOfNationalNumber = indexOfRfc3966Prefix + RFC3966_PREFIX_.length;
      } else {
        indexOfNationalNumber = 0;
      }
      var indexOfPhoneContext = numberToParse.indexOf(RFC3966_PHONE_CONTEXT_);
      phoneNumberString += numberToParse.substring(indexOfNationalNumber, indexOfPhoneContext);
    }
    var indexOfIsdn = phoneNumberString.indexOf(RFC3966_ISDN_SUBADDRESS_);
    if (indexOfIsdn > 0) {
      phoneNumberString = phoneNumberString.substring(0, indexOfIsdn);
    }
    if (phoneNumberString !== "") {
      return phoneNumberString;
    }
  }

  // node_modules/libphonenumber-js/es6/parse.js
  var MAX_INPUT_STRING_LENGTH = 250;
  var PHONE_NUMBER_START_PATTERN = new RegExp("[" + PLUS_CHARS + VALID_DIGITS + "]");
  var AFTER_PHONE_NUMBER_END_PATTERN = new RegExp("[^" + VALID_DIGITS + "#]+$");
  var USE_NON_GEOGRAPHIC_COUNTRY_CODE3 = false;
  function parse(text5, options, metadataJson) {
    options = options || {};
    var metadata3 = new Metadata(metadataJson);
    if (options.defaultCountry && !metadata3.hasCountry(options.defaultCountry)) {
      if (options.v2) {
        throw new ParseError("INVALID_COUNTRY");
      }
      throw new Error("Unknown country: ".concat(options.defaultCountry));
    }
    var _parseInput = parseInput(text5, options.v2, options.extract), formattedPhoneNumber = _parseInput.number, ext = _parseInput.ext, error = _parseInput.error;
    if (!formattedPhoneNumber) {
      if (options.v2) {
        if (error === "TOO_SHORT") {
          throw new ParseError("TOO_SHORT");
        }
        throw new ParseError("NOT_A_NUMBER");
      }
      return {};
    }
    var _parsePhoneNumber = parsePhoneNumber(
      formattedPhoneNumber,
      options.defaultCountry,
      options.defaultCallingCode,
      // If `country` is returned, its numbering plan will also be selected in `metadata`.
      // Otherwise, if `countryCallingCode` is returned, its numbering plan will also be selected in `metadata`.
      // Otherwise, if neither `country` nor `countryCallingCode` are returned, no numbering plan will be selected in `metadata`.
      metadata3
    ), country = _parsePhoneNumber.country, nationalNumber = _parsePhoneNumber.nationalNumber, countryCallingCode = _parsePhoneNumber.countryCallingCode, countryCallingCodeSource = _parsePhoneNumber.countryCallingCodeSource, carrierCode = _parsePhoneNumber.carrierCode;
    if (!metadata3.hasSelectedNumberingPlan()) {
      if (options.v2) {
        throw new ParseError("INVALID_COUNTRY");
      }
      return {};
    }
    if (!nationalNumber || nationalNumber.length < MIN_LENGTH_FOR_NSN) {
      if (options.v2) {
        throw new ParseError("TOO_SHORT");
      }
      return {};
    }
    if (nationalNumber.length > MAX_LENGTH_FOR_NSN) {
      if (options.v2) {
        throw new ParseError("TOO_LONG");
      }
      return {};
    }
    if (options.v2) {
      var phoneNumber = new PhoneNumber(countryCallingCode, nationalNumber, metadata3.metadata);
      if (country) {
        phoneNumber.country = country;
      }
      if (carrierCode) {
        phoneNumber.carrierCode = carrierCode;
      }
      if (ext) {
        phoneNumber.ext = ext;
      }
      phoneNumber.__countryCallingCodeSource = countryCallingCodeSource;
      return phoneNumber;
    }
    var valid = (options.extended ? metadata3.hasSelectedNumberingPlan() : country) ? matchesEntirely(nationalNumber, metadata3.nationalNumberPattern()) : false;
    if (!options.extended) {
      return valid ? result(country, nationalNumber, ext) : {};
    }
    return {
      country,
      countryCallingCode,
      carrierCode,
      valid,
      possible: valid ? true : options.extended === true && metadata3.possibleLengths() && isPossibleNumber(nationalNumber, metadata3) ? true : false,
      phone: nationalNumber,
      ext
    };
  }
  function _extractFormattedPhoneNumber(text5, extract, throwOnError) {
    if (!text5) {
      return;
    }
    if (text5.length > MAX_INPUT_STRING_LENGTH) {
      if (throwOnError) {
        throw new ParseError("TOO_LONG");
      }
      return;
    }
    if (extract === false) {
      return text5;
    }
    var startsAt = text5.search(PHONE_NUMBER_START_PATTERN);
    if (startsAt < 0) {
      return;
    }
    return text5.slice(startsAt).replace(AFTER_PHONE_NUMBER_END_PATTERN, "");
  }
  function parseInput(text5, v2, extract) {
    var number = extractFormattedPhoneNumberFromPossibleRfc3966NumberUri(text5, {
      extractFormattedPhoneNumber: function extractFormattedPhoneNumber(text6) {
        return _extractFormattedPhoneNumber(text6, extract, v2);
      }
    });
    if (!number) {
      return {};
    }
    if (!isViablePhoneNumber(number)) {
      if (isViablePhoneNumberStart(number)) {
        return {
          error: "TOO_SHORT"
        };
      }
      return {};
    }
    var withExtensionStripped = extractExtension(number);
    if (withExtensionStripped.ext) {
      return withExtensionStripped;
    }
    return {
      number
    };
  }
  function result(country, nationalNumber, ext) {
    var result2 = {
      country,
      phone: nationalNumber
    };
    if (ext) {
      result2.ext = ext;
    }
    return result2;
  }
  function parsePhoneNumber(formattedPhoneNumber, defaultCountry, defaultCallingCode, metadata3) {
    var _extractCountryCallin = extractCountryCallingCode(
      parseIncompletePhoneNumber(formattedPhoneNumber),
      void 0,
      // `defaultCountry` and `defaultCallingCode` are only used to detect
      // if it's an "international" phone number or not. They won't be used
      // to derive the resulting `countryCallingCode` from them, or anything like that.
      defaultCountry,
      defaultCallingCode,
      metadata3.metadata
    ), countryCallingCodeSource = _extractCountryCallin.countryCallingCodeSource, countryCallingCode = _extractCountryCallin.countryCallingCode, number = _extractCountryCallin.number;
    var country;
    if (countryCallingCode) {
      metadata3.selectNumberingPlan(countryCallingCode);
    } else if (number && (defaultCountry || defaultCallingCode)) {
      if (defaultCountry) {
        country = defaultCountry;
        metadata3.selectNumberingPlan(defaultCountry);
        countryCallingCode = metadata3.numberingPlan.callingCode();
      } else {
        metadata3.selectNumberingPlan(defaultCallingCode);
        countryCallingCode = defaultCallingCode;
        if (USE_NON_GEOGRAPHIC_COUNTRY_CODE3) {
          if (metadata3.isNonGeographicCallingCode(countryCallingCode)) {
            country = "001";
          }
        }
      }
    } else return {};
    if (!number) {
      return {
        countryCallingCodeSource,
        countryCallingCode
      };
    }
    var _extractNationalNumbe = extractNationalNumber(parseIncompletePhoneNumber(number), void 0, metadata3), nationalNumber = _extractNationalNumbe.nationalNumber, carrierCode = _extractNationalNumbe.carrierCode;
    var exactCountry = getCountryByCallingCode(countryCallingCode, {
      nationalNumber,
      metadata: metadata3
    });
    if (exactCountry) {
      country = exactCountry;
      if (exactCountry === "001") {
      } else {
        metadata3.selectNumberingPlan(country);
      }
    }
    return {
      country,
      countryCallingCode,
      countryCallingCodeSource,
      nationalNumber,
      carrierCode
    };
  }

  // node_modules/libphonenumber-js/es6/parsePhoneNumberWithError_.js
  function _typeof4(o) {
    "@babel/helpers - typeof";
    return _typeof4 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof4(o);
  }
  function ownKeys2(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function(r2) {
        return Object.getOwnPropertyDescriptor(e, r2).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys2(Object(t), true).forEach(function(r2) {
        _defineProperty2(e, r2, t[r2]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys2(Object(t)).forEach(function(r2) {
        Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
      });
    }
    return e;
  }
  function _defineProperty2(e, r, t) {
    return (r = _toPropertyKey4(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
  }
  function _toPropertyKey4(t) {
    var i = _toPrimitive4(t, "string");
    return "symbol" == _typeof4(i) ? i : i + "";
  }
  function _toPrimitive4(t, r) {
    if ("object" != _typeof4(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof4(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function parsePhoneNumberWithError(text5, options, metadata3) {
    return parse(text5, _objectSpread2(_objectSpread2({}, options), {}, {
      v2: true
    }), metadata3);
  }

  // node_modules/libphonenumber-js/es6/normalizeArguments.js
  function _typeof5(o) {
    "@babel/helpers - typeof";
    return _typeof5 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof5(o);
  }
  function ownKeys3(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function(r2) {
        return Object.getOwnPropertyDescriptor(e, r2).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread3(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys3(Object(t), true).forEach(function(r2) {
        _defineProperty3(e, r2, t[r2]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys3(Object(t)).forEach(function(r2) {
        Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
      });
    }
    return e;
  }
  function _defineProperty3(e, r, t) {
    return (r = _toPropertyKey5(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
  }
  function _toPropertyKey5(t) {
    var i = _toPrimitive5(t, "string");
    return "symbol" == _typeof5(i) ? i : i + "";
  }
  function _toPrimitive5(t, r) {
    if ("object" != _typeof5(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof5(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray5(r, e) || _nonIterableRest();
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray5(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray5(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray5(r, a) : void 0;
    }
  }
  function _arrayLikeToArray5(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
      var e, n, i, u, a = [], f = true, o = false;
      try {
        if (i = (t = t.call(r)).next, 0 === l) {
          if (Object(t) !== t) return;
          f = false;
        } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = true) ;
      } catch (r2) {
        o = true, n = r2;
      } finally {
        try {
          if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
        } finally {
          if (o) throw n;
        }
      }
      return a;
    }
  }
  function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
  }
  function normalizeArguments(args) {
    var _Array$prototype$slic = Array.prototype.slice.call(args), _Array$prototype$slic2 = _slicedToArray(_Array$prototype$slic, 4), arg_1 = _Array$prototype$slic2[0], arg_2 = _Array$prototype$slic2[1], arg_3 = _Array$prototype$slic2[2], arg_4 = _Array$prototype$slic2[3];
    var text5;
    var options;
    var metadata3;
    if (typeof arg_1 === "string") {
      text5 = arg_1;
    } else throw new TypeError("A text for parsing must be a string.");
    if (!arg_2 || typeof arg_2 === "string") {
      if (arg_4) {
        options = arg_3;
        metadata3 = arg_4;
      } else {
        options = void 0;
        metadata3 = arg_3;
      }
      if (arg_2) {
        options = _objectSpread3({
          defaultCountry: arg_2
        }, options);
      }
    } else if (isObject(arg_2)) {
      if (arg_3) {
        options = arg_2;
        metadata3 = arg_3;
      } else {
        metadata3 = arg_2;
      }
    } else throw new Error("Invalid second argument: ".concat(arg_2));
    return {
      text: text5,
      options,
      metadata: metadata3
    };
  }

  // node_modules/libphonenumber-js/es6/parsePhoneNumber_.js
  function _typeof6(o) {
    "@babel/helpers - typeof";
    return _typeof6 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
      return typeof o2;
    } : function(o2) {
      return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
    }, _typeof6(o);
  }
  function ownKeys4(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function(r2) {
        return Object.getOwnPropertyDescriptor(e, r2).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread4(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys4(Object(t), true).forEach(function(r2) {
        _defineProperty4(e, r2, t[r2]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys4(Object(t)).forEach(function(r2) {
        Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
      });
    }
    return e;
  }
  function _defineProperty4(e, r, t) {
    return (r = _toPropertyKey6(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: true, configurable: true, writable: true }) : e[r] = t, e;
  }
  function _toPropertyKey6(t) {
    var i = _toPrimitive6(t, "string");
    return "symbol" == _typeof6(i) ? i : i + "";
  }
  function _toPrimitive6(t, r) {
    if ("object" != _typeof6(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != _typeof6(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function parsePhoneNumber2(text5, options, metadata3) {
    if (options && options.defaultCountry && !isSupportedCountry(options.defaultCountry, metadata3)) {
      options = _objectSpread4(_objectSpread4({}, options), {}, {
        defaultCountry: void 0
      });
    }
    try {
      return parsePhoneNumberWithError(text5, options, metadata3);
    } catch (error) {
      if (error instanceof ParseError) {
      } else {
        throw error;
      }
    }
  }

  // node_modules/libphonenumber-js/es6/parsePhoneNumber.js
  function parsePhoneNumber3() {
    var _normalizeArguments = normalizeArguments(arguments), text5 = _normalizeArguments.text, options = _normalizeArguments.options, metadata3 = _normalizeArguments.metadata;
    return parsePhoneNumber2(text5, options, metadata3);
  }

  // node_modules/libphonenumber-js/es6/getCountries.js
  function getCountries(metadata3) {
    return new Metadata(metadata3).getCountries();
  }

  // node_modules/libphonenumber-js/min/exports/parsePhoneNumber.js
  function parsePhoneNumber4() {
    return withMetadataArgument(parsePhoneNumber3, arguments);
  }

  // node_modules/libphonenumber-js/min/exports/getCountries.js
  function getCountries2() {
    return withMetadataArgument(getCountries, arguments);
  }

  // src/profile-fields.ts
  function record(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function text(value) {
    return typeof value === "string" ? value.trim() : "";
  }
  function items(value) {
    return Array.isArray(value) ? value.map(record) : [];
  }
  function unique(values) {
    return [...new Set(values.filter(Boolean))];
  }
  var COUNTRY_EQUIVALENTS = {
    US: ["United States", "United States of America", "USA", "U.S.", "U.S.A."],
    GB: ["United Kingdom", "Great Britain", "UK", "U.K."],
    KR: ["South Korea", "Korea, Republic of", "Republic of Korea"],
    KP: ["North Korea", "Korea, Democratic People's Republic of"],
    RU: ["Russia", "Russian Federation"],
    TW: ["Taiwan", "Taiwan, Province of China"],
    VN: ["Vietnam", "Viet Nam"],
    TZ: ["Tanzania", "Tanzania, United Republic of"],
    BO: ["Bolivia", "Bolivia, Plurinational State of"],
    IR: ["Iran", "Iran, Islamic Republic of"],
    VE: ["Venezuela", "Venezuela, Bolivarian Republic of"],
    MD: ["Moldova", "Moldova, Republic of"],
    SY: ["Syria", "Syrian Arab Republic"],
    LA: ["Laos", "Lao People's Democratic Republic"],
    TR: ["Turkey", "T\xFCrkiye"],
    CZ: ["Czechia", "Czech Republic"],
    CI: ["Ivory Coast", "C\xF4te d\u2019Ivoire", "C\xF4te d'Ivoire"]
  };
  var countryKey = (value) => value.normalize("NFKC").toLocaleLowerCase("en").replace(/[.,’']/g, "").replace(/\s+/g, " ").trim();
  function countryValueAliases(value) {
    const key = countryKey(value);
    if (!key) return [];
    const names = new Intl.DisplayNames(["en"], { type: "region" });
    const code = getCountries2().find(
      (code2) => [code2, names.of(code2) || "", ...COUNTRY_EQUIVALENTS[code2] || []].some(
        (alias) => countryKey(alias) === key
      )
    );
    return code ? unique([value, code, names.of(code) || "", ...COUNTRY_EQUIVALENTS[code] || []]) : [value];
  }
  var OTHER_PERSON = [
    "referrer",
    "referral",
    "referred by",
    "reference",
    "recruiter",
    "emergency",
    "manager",
    "supervisor",
    "parent",
    "guardian"
  ];
  var OTHER_ADDRESS = [
    ...OTHER_PERSON,
    "company",
    "employer",
    "office",
    "school",
    "university",
    "institution",
    "billing",
    "shipping",
    "previous",
    "former",
    "preferred",
    "desired",
    "job location"
  ];
  function profileAutofillFields(profile) {
    const contact = record(profile.contactData);
    const address = record(profile.addressData);
    const websites = record(profile.websiteData);
    const result2 = [];
    const add = (id2, label, value, aliases, exclude = [], autocomplete = [], valueAliases = []) => {
      if (!value) return;
      result2.push({
        id: `profile:${id2}`,
        label,
        value,
        aliases: unique(aliases),
        exclude: unique(exclude),
        category: "Saved profile",
        enabled: true,
        matchMode: "phrase",
        scope: "",
        ...autocomplete.length ? { autocomplete } : {},
        ...valueAliases.length ? { valueAliases: unique(valueAliases) } : {}
      });
    };
    add(
      "email",
      "Email",
      text(contact.email),
      [
        "email address",
        "e-mail",
        "e-mail address",
        "electronic mail",
        "contact email",
        "confirm email",
        "email confirmation"
      ],
      [...OTHER_PERSON, "company", "employer", "work email", "business email"],
      ["email"]
    );
    add(
      "address-line1",
      "Address line 1",
      text(address.line1),
      [
        "address 1",
        "address1",
        "addressline1",
        "street address",
        "address street",
        "street",
        "home address",
        "residential address",
        "address"
      ],
      [
        ...OTHER_ADDRESS,
        "email",
        "e mail",
        "web",
        "linkedin",
        "github",
        "line 2",
        "line2",
        "address 2",
        "address2",
        "apartment",
        "suite",
        "unit",
        "full address",
        "complete address"
      ],
      ["address-line1"]
    );
    add(
      "address-line2",
      "Address line 2",
      text(address.line2),
      [
        "address 2",
        "address2",
        "addressline2",
        "apartment",
        "suite",
        "unit number",
        "apt suite",
        "apt"
      ],
      OTHER_ADDRESS,
      ["address-line2"]
    );
    const street = [text(address.line1), text(address.line2)].filter(Boolean).join("\n");
    add(
      "street-address",
      "Complete street address",
      street,
      ["street mailing address"],
      [...OTHER_ADDRESS, "email", "e mail"],
      ["street-address"]
    );
    const fullAddress = [
      text(address.line1),
      text(address.line2),
      text(address.city),
      text(address.state),
      text(address.postalCode),
      text(address.country)
    ].filter(Boolean).join(", ");
    add(
      "full-address",
      "Full address",
      fullAddress,
      ["complete address", "full mailing address", "complete mailing address"],
      [...OTHER_ADDRESS, "email", "e mail"]
    );
    add(
      "city",
      "City",
      text(address.city),
      ["city of residence", "current city", "town", "city town", "residential city"],
      [...OTHER_ADDRESS, "birth", "born"],
      ["address-level2"]
    );
    add(
      "state",
      "State",
      text(address.state),
      ["province", "state province", "state or province", "region of residence"],
      [
        ...OTHER_ADDRESS,
        "birth",
        "born",
        "state your",
        "state whether",
        "state why",
        "state how",
        "state the"
      ],
      ["address-level1"]
    );
    add(
      "postal-code",
      "Postal code",
      text(address.postalCode),
      ["postcode", "post code", "zip", "zip code", "zip postal code", "pin code", "pincode"],
      OTHER_ADDRESS,
      ["postal-code"]
    );
    add(
      "country",
      "Country",
      text(address.country),
      [
        "country region",
        "country of residence",
        "residence country",
        "residential country",
        "current country"
      ],
      [
        ...OTHER_ADDRESS,
        "citizenship",
        "nationality",
        "birth",
        "born",
        "country code",
        "calling code",
        "dial code",
        "work authorization",
        "authorized",
        "eligible",
        "sponsorship"
      ],
      ["country", "country-name"],
      countryValueAliases(text(address.country))
    );
    add(
      "linkedin",
      "LinkedIn",
      text(websites.linkedin),
      ["linkedin url", "linkedin profile", "linkedin link", "linkedin profile url"],
      OTHER_PERSON
    );
    add(
      "github",
      "GitHub",
      text(websites.github),
      ["github url", "github profile", "github link", "github profile url"],
      OTHER_PERSON
    );
    add(
      "website",
      "Personal website",
      text(websites.personal),
      [
        "portfolio",
        "portfolio url",
        "portfolio link",
        "personal site",
        "personal website url",
        "website",
        "website url",
        "website link"
      ],
      [
        ...OTHER_PERSON,
        "company",
        "employer",
        "linkedin",
        "github",
        "twitter",
        "facebook",
        "source",
        "how did you hear"
      ],
      ["url"]
    );
    const skills = Array.isArray(profile.skillsData) ? unique(
      profile.skillsData.filter((value) => typeof value === "string").map((value) => value.trim())
    ) : [];
    add(
      "skills",
      "Skills",
      skills.join(", "),
      ["technical skills", "relevant skills", "skill set", "skills list"],
      ["years", "experience in", "proficiency", "rating", "level", "required", "preferred"]
    );
    const currentJobs = items(profile.jobData).filter((job) => job.currentlyWorkHere === true);
    if (currentJobs.length === 1) {
      const current = currentJobs[0];
      add(
        "current-company",
        "Current company",
        text(current.company),
        ["current employer", "present employer", "present company", "current organization"],
        [...OTHER_PERSON, "previous", "former", "expected", "desired"]
      );
      add(
        "current-title",
        "Current job title",
        text(current.jobTitle),
        [
          "current title",
          "current position",
          "current role",
          "present job title",
          "current designation"
        ],
        [...OTHER_PERSON, "previous", "former", "expected", "desired", "applying"]
      );
    }
    const education = items(profile.educationData);
    if (education.length === 1) {
      const entry = education[0];
      add(
        "recent-school",
        "Most recent school",
        text(entry.school),
        [
          "most recent university",
          "most recent institution",
          "most recent college",
          "last attended school",
          "last attended university",
          "last attended college"
        ],
        [...OTHER_PERSON, "high school", "secondary school"]
      );
      add(
        "recent-degree",
        "Most recent degree",
        text(entry.degree),
        ["degree from most recent institution"],
        [...OTHER_PERSON, "high school"]
      );
      add(
        "recent-major",
        "Most recent field of study",
        text(entry.fieldOfStudy),
        ["major from most recent institution"],
        OTHER_PERSON
      );
    }
    return result2;
  }

  // src/storage.ts
  var emptyProfile = () => ({ fields: [], autoFill: true });
  var SHORTCUT_IDS = new Set(
    [
      "first",
      "middle",
      "middle-initial",
      "last",
      "full",
      "phone-local",
      "phone-international",
      "dial-code",
      "phone-formatted"
    ].map((id2) => `builtin:${id2}`)
  );
  function object(value) {
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  function string(value) {
    return typeof value === "string" ? value : "";
  }
  function contextFrom(data) {
    const profile = object(data.profile);
    const names = object(profile.nameData);
    const contact = object(profile.contactData);
    const synced = object(data.lastSyncProfile);
    return {
      id: string(synced.id) || "local",
      name: [names.firstName, names.lastName].filter(Boolean).join(" ") || "Your profile",
      personal: { ...names, ...contact, country: object(profile.addressData).country }
    };
  }
  function validateProfile(input) {
    const data = object(input);
    if (!Array.isArray(data.fields) || data.fields.length > 2e3 || typeof data.autoFill !== "boolean") {
      throw new Error(
        "Choose a custom-fields export with a fields list and an automatic-fill setting (up to 2,000 fields)."
      );
    }
    const validateFields = (values, shortcuts = false) => {
      const seen = /* @__PURE__ */ new Set();
      return values.map((raw) => {
        const field = object(raw);
        const id2 = string(field.id);
        const label = string(field.label).trim();
        const value = string(field.value);
        if (!id2 || (shortcuts ? !SHORTCUT_IDS.has(id2) : id2.startsWith("builtin:")) || seen.has(id2) || !label || label.length > 200 || value.length > 3e4) {
          throw new Error(
            "Every field needs a unique ID, a label (up to 200 characters), and an answer under 30,000 characters."
          );
        }
        seen.add(id2);
        const list = (key) => {
          if (!Array.isArray(field[key]) || field[key].length > 100 || field[key].some((v) => typeof v !== "string" || v.length > 300)) {
            throw new Error(
              "Matching phrases and exclusions must be text lists (up to 100 phrases, 300 characters each)."
            );
          }
          return [...new Set(field[key].map((s) => s.trim()).filter(Boolean))];
        };
        let scope = string(field.scope).trim().toLowerCase();
        if (scope) {
          try {
            const parsed = new URL(scope.includes("://") ? scope : `https://${scope}`);
            if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash || parsed.port)
              throw new Error();
            scope = parsed.hostname;
          } catch {
            throw new Error(
              "Site scope must be a hostname, such as linkedin.com. Leave it empty for every site."
            );
          }
        }
        if (!["exact", "phrase"].includes(string(field.matchMode)) || typeof field.enabled !== "boolean") {
          throw new Error("Each field needs an exact/phrase match mode and an enabled setting.");
        }
        return {
          id: id2,
          label,
          value,
          aliases: list("aliases"),
          exclude: list("exclude"),
          category: string(field.category).trim().slice(0, 100) || "Personal questions",
          enabled: field.enabled,
          matchMode: field.matchMode,
          scope
        };
      });
    };
    const fields = validateFields(data.fields);
    if (data.profileOverrides !== void 0 && (!Array.isArray(data.profileOverrides) || data.profileOverrides.length > SHORTCUT_IDS.size))
      throw new Error("Profile edits must be a list of valid profile shortcuts.");
    const profileOverrides = data.profileOverrides === void 0 ? void 0 : validateFields(data.profileOverrides, true);
    const hidden = data.hiddenBuiltIns;
    if (hidden !== void 0 && (!Array.isArray(hidden) || hidden.length > 100 || hidden.some((id2) => typeof id2 !== "string" || !/^builtin:[a-z-]{1,80}$/.test(id2)))) {
      throw new Error("Hidden profile shortcuts must be a list of valid shortcut IDs.");
    }
    const order = data.fieldOrder;
    if (order !== void 0 && (!Array.isArray(order) || order.length > 2200 || order.some((id2) => typeof id2 !== "string" || !id2.trim() || id2.length > 200))) {
      throw new Error(
        "Field order must be a list of up to 2,200 nonempty field IDs, each at most 200 characters."
      );
    }
    return {
      fields,
      autoFill: data.autoFill,
      ...hidden === void 0 ? {} : { hiddenBuiltIns: [...new Set(hidden)] },
      ...order === void 0 ? {} : { fieldOrder: [...new Set(order)] },
      ...profileOverrides === void 0 ? {} : { profileOverrides }
    };
  }
  function phoneVariants(personal) {
    const raw = string(personal.phoneNumber).trim();
    const countryName = string(personal.country).trim();
    const countryNames = new Intl.DisplayNames(["en"], { type: "region" });
    const country = getCountries2().find(
      (code) => code.toLowerCase() === countryName.toLowerCase() || countryNames.of(code)?.toLowerCase() === countryName.toLowerCase()
    );
    const legacyCode = string(personal.phoneCountryCode).replace(/\D/g, "");
    const candidate = raw.startsWith("+") || !legacyCode || country ? raw : `+${legacyCode}${raw.replace(/\D/g, "")}`;
    const parsed = parsePhoneNumber4(candidate, country);
    if (parsed?.isPossible())
      return {
        national: parsed.nationalNumber,
        international: parsed.number,
        code: `+${parsed.countryCallingCode}`,
        formatted: parsed.formatInternational()
      };
    return {
      national: raw.startsWith("+") ? "" : raw.replace(/\D/g, ""),
      international: raw.startsWith("+") ? raw : "",
      code: "",
      formatted: raw
    };
  }
  function builtInFields(context) {
    const p = context.personal;
    const phone = phoneVariants(p);
    const create = (id2, label, value, aliases, exclude = []) => ({
      id: `builtin:${id2}`,
      label,
      value,
      aliases,
      exclude,
      category: "Name & phone",
      enabled: true,
      matchMode: "phrase",
      scope: ""
    });
    return [
      create(
        "first",
        "First name",
        string(p.firstName),
        ["given name", "forename"],
        ["last", "middle", "surname"]
      ),
      create("middle", "Middle name", string(p.middleName), []),
      create("middle-initial", "Middle initial", string(p.middleName).trim().slice(0, 1), []),
      create(
        "last",
        "Last name",
        string(p.lastName),
        ["family name", "surname"],
        ["first", "middle"]
      ),
      create("full", "Full name", [p.firstName, p.middleName, p.lastName].filter(Boolean).join(" "), [
        "legal name",
        "full legal name"
      ]),
      create(
        "phone-local",
        "Phone number only",
        phone.national,
        [
          "mobile number",
          "phone",
          "phone number",
          "mobile",
          "telephone number",
          "contact number",
          "phone without country code",
          "mobile without country code",
          "phone national number"
        ],
        [
          "phone country code",
          "dial code",
          "international",
          "including country code",
          "with country code",
          "extension",
          "alternate",
          "alternative",
          "secondary",
          "emergency",
          "reference"
        ]
      ),
      create("phone-international", "Phone with country code", phone.international, [
        "international phone",
        "phone including country code",
        "mobile with country code",
        "international mobile"
      ]),
      create("dial-code", "Phone country code", phone.code, [
        "dial code",
        "dialing code",
        "phone dialling code"
      ]),
      { ...create("phone-formatted", "Phone formatted", phone.formatted, []), enabled: false }
    ];
  }
  function profileShortcuts(context, profile) {
    const hidden = new Set(profile.hiddenBuiltIns || []);
    const overrides = new Map(profile.profileOverrides?.map((field) => [field.id, field]));
    return builtInFields(context).filter((field) => !hidden.has(field.id)).map((field) => ({ ...field, ...overrides.get(field.id) }));
  }
  async function getAutofillData() {
    const data = await chrome.storage.local.get([
      "profile",
      "lastSyncProfile",
      STORAGE_KEY,
      "autofillEnabled"
    ]);
    const context = contextFrom(data);
    const store = data[STORAGE_KEY];
    const saved = store?.version === 1 && store.profiles?.[context.id] ? validateProfile(store.profiles[context.id]) : emptyProfile();
    const semantics = {
      "builtin:first": ["given-name"],
      "builtin:middle": ["additional-name"],
      "builtin:last": ["family-name"],
      "builtin:full": ["name"],
      "builtin:phone-local": ["tel-national"],
      "builtin:phone-international": ["tel"],
      "builtin:dial-code": ["tel-country-code"]
    };
    const shortcuts = profileShortcuts(context, saved).map((field) => ({
      ...field,
      autocomplete: semantics[field.id]
    }));
    const profile = object(data.profile);
    const resume = object(profile.resumeData);
    return {
      ...saved,
      autoFill: saved.autoFill && data.autofillEnabled !== false,
      profileId: context.id,
      fields: [...saved.fields, ...shortcuts, ...profileAutofillFields(profile)],
      ...string(resume.fileName) && string(resume.resumeBase64) ? { resume: { fileName: string(resume.fileName), resumeBase64: string(resume.resumeBase64) } } : {}
    };
  }

  // src/dropdown.ts
  function normalizeOption(value) {
    return value.normalize("NFKC").toLocaleLowerCase("en").replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/\s+/g, " ");
  }
  function isDropdownPlaceholder(label) {
    const text5 = normalizeOption(label || "");
    return !text5 || /^(?:(?:please|kindly) )?(?:(?:select|choose|pick)(?: (?:one|(?:a|an|your) (?:option|value|selection)|option|value))?|make (?:a |your )?selection|search(?: and select| or select| for an option)?|select or search|none selected|no (?:option|value|selection) selected)$/.test(
      text5
    );
  }

  // src/widgets.ts
  function clean2(value) {
    return (value || "").replace(/\s+/g, " ").trim();
  }
  function parent(element) {
    return element.parentElement || element.getRootNode().host || null;
  }
  function visible(element) {
    if (!element.isConnected) return false;
    for (let node = element; node; node = parent(node)) {
      if (node.hasAttribute("hidden") || node.hasAttribute("inert") || node.getAttribute("aria-hidden") === "true")
        return false;
      const style = element.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden") return false;
    }
    return true;
  }
  function inputOf(element) {
    return element.tagName === "INPUT" ? element : element.querySelector('input:not([type="hidden"])');
  }
  function backingSelect(element) {
    const contained = element.querySelector("select");
    if (contained) return contained;
    const sibling = element.previousElementSibling;
    const label = normalize(element.getAttribute("aria-label") || "");
    return sibling?.tagName === "SELECT" && !visible(sibling) && label && normalize(sibling.getAttribute("aria-label") || "") === label ? sibling : null;
  }
  function committedValue(element) {
    const select = backingSelect(element);
    if (select) {
      const option = select.selectedOptions[0];
      if (option?.value && !option.disabled && !isDropdownPlaceholder(option.textContent))
        return clean2(option.textContent) || option.value;
      return "";
    }
    const ariaValue = clean2(element.getAttribute("aria-valuetext"));
    if (ariaValue && !isDropdownPlaceholder(ariaValue)) return ariaValue;
    const scope = element.closest('[class*="-control"],[class*="__control"]') || element;
    const selected = scope.querySelector(
      '[class*="singleValue"],[class*="single-value"],[class*="__single-value"],.choices__list--single [data-item]'
    );
    return selected && visible(selected) && !selected.closest('[role="listbox"]') && !isDropdownPlaceholder(selected.textContent) ? clean2(selected.textContent) : "";
  }
  function rootsOf(element) {
    const root = element.getRootNode();
    return root === element.ownerDocument ? [root] : [root, element.ownerDocument];
  }
  function popupNodes(element) {
    const input = inputOf(element);
    const controls = [element, input].filter((node) => !!node);
    const ids = [
      ...new Set(
        controls.flatMap((node) => [node.getAttribute("aria-controls"), node.getAttribute("aria-owns")]).flatMap((value) => (value || "").split(/\s+/).filter(Boolean))
      )
    ];
    const nodes = [];
    for (const id2 of ids)
      for (const root of rootsOf(element)) {
        const node = root.getElementById(id2);
        if (node && (node.matches('[role="listbox"]') || node.querySelector('[role="option"]')) && visible(node))
          nodes.push(node);
      }
    for (const control of controls) {
      const activeId = control.getAttribute("aria-activedescendant");
      if (!activeId) continue;
      for (const root of rootsOf(element)) {
        const option = root.getElementById(activeId);
        const list = option?.matches('[role="option"]') ? option.closest('[role="listbox"]') : null;
        if (list && visible(list)) nodes.push(list);
      }
    }
    for (const sibling of [element.previousElementSibling, element.nextElementSibling]) {
      if (!sibling?.hasAttribute("aria-expanded") || sibling.querySelector("label")) continue;
      for (const id2 of (sibling.getAttribute("aria-owns") || "").split(/\s+/).filter(Boolean)) {
        const list = sibling.getRootNode();
        const node = list.getElementById(id2);
        if (node?.matches('[role="listbox"]') && sibling.contains(node) && visible(node))
          nodes.push(node);
      }
    }
    for (const node of element.querySelectorAll('[role="listbox"]'))
      if (visible(node)) nodes.push(node);
    return [...new Set(nodes)];
  }
  function comboboxValue(element) {
    const input = inputOf(element);
    if (input?.value.trim()) return input.value.trim();
    const committed = committedValue(element);
    if (committed) return committed;
    if (input) return "";
    const clone = element.cloneNode(true);
    clone.querySelectorAll('[role="listbox"],[role="option"],svg,[aria-hidden="true"]').forEach((node) => node.remove());
    const value = clean2(clone.textContent);
    const placeholder = clean2(
      element.getAttribute("data-placeholder") || element.getAttribute("aria-placeholder")
    );
    return value === placeholder || isDropdownPlaceholder(value) ? "" : value;
  }
  function setInput(input, value) {
    const win = input.ownerDocument.defaultView;
    Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, "value")?.set?.call(input, value);
    input.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(
      new win.KeyboardEvent("keyup", {
        key: value.at(-1) || "Backspace",
        bubbles: true,
        composed: true
      })
    );
  }
  function activate(element) {
    const win = element.ownerDocument.defaultView;
    if (typeof win.PointerEvent === "function")
      element.dispatchEvent(
        new win.PointerEvent("pointerdown", {
          pointerId: 1,
          pointerType: "mouse",
          isPrimary: true,
          button: 0,
          buttons: 1,
          bubbles: true,
          composed: true,
          cancelable: true
        })
      );
    if (!element.isConnected) return;
    element.dispatchEvent(
      new win.MouseEvent("mousedown", {
        button: 0,
        buttons: 1,
        bubbles: true,
        composed: true,
        cancelable: true
      })
    );
    if (!element.isConnected) return;
    if (typeof win.PointerEvent === "function")
      element.dispatchEvent(
        new win.PointerEvent("pointerup", {
          pointerId: 1,
          pointerType: "mouse",
          isPrimary: true,
          button: 0,
          buttons: 0,
          bubbles: true,
          composed: true,
          cancelable: true
        })
      );
    element.dispatchEvent(
      new win.MouseEvent("mouseup", {
        button: 0,
        buttons: 0,
        bubbles: true,
        composed: true,
        cancelable: true
      })
    );
    if (element.isConnected) element.click();
  }
  function wait(document2, milliseconds) {
    return new Promise((resolve) => document2.defaultView.setTimeout(resolve, milliseconds));
  }
  function answersMatch(value, answers) {
    return answers.has(normalizeOption(value));
  }
  function optionValues(option) {
    return [
      clean2(option.textContent),
      clean2(option.getAttribute("aria-label")),
      clean2(option.getAttribute("data-value"))
    ].filter(Boolean);
  }
  async function fillCombobox(element, answer, valueAliases = [], signal) {
    const fail = (reason) => ({ filled: false, reason });
    if (signal?.aborted) return fail("Automatic filling was stopped");
    if (!answer.trim()) return fail("Saved answer is empty");
    if (!visible(element) || element.getAttribute("aria-disabled") === "true" || element.hasAttribute("disabled"))
      return fail("Dropdown is not available");
    if (element.tagName === "SELECT") return fail("Use the native dropdown adapter");
    if (element.closest('[aria-multiselectable="true"]') || element.getAttribute("aria-multiselectable") === "true" || element.getAttribute("data-type") === "select-multiple" || backingSelect(element)?.multiple)
      return fail("Multiple-choice dropdown requires manual selection");
    const input = inputOf(element);
    if (input && (input.disabled || ["password", "file", "checkbox", "radio", "submit", "hidden"].includes(input.type)))
      return fail("Dropdown input is not editable");
    if (comboboxValue(element)) return fail("Existing dropdown answer preserved");
    if (element.tagName === "BUTTON" && element.form && element.type !== "button")
      return fail("Dropdown trigger could submit the form; select it manually");
    const answers = new Set([answer, ...valueAliases].map(normalizeOption).filter(Boolean));
    const original = input?.value || "";
    let typed = false;
    let userChanged = false;
    let selected;
    const onUserChange = (event) => {
      if (event.isTrusted) userChanged = true;
    };
    element.addEventListener("input", onUserChange, true);
    element.addEventListener("change", onUserChange, true);
    function rollback() {
      if (input && typed && !userChanged && input.value === answer) setInput(input, original);
      element.dispatchEvent(
        new element.ownerDocument.defaultView.KeyboardEvent("keydown", {
          key: "Escape",
          code: "Escape",
          bubbles: true
        })
      );
    }
    try {
      element.focus();
      activate(element);
      for (let attempt = 0; attempt < 40; attempt++) {
        if (signal?.aborted) {
          rollback();
          return fail("Automatic filling was stopped");
        }
        if (userChanged) return fail("Your dropdown edit was preserved");
        if (!element.isConnected) return fail("Dropdown changed while opening; try again");
        const current = comboboxValue(element);
        if (current && !(typed && input?.value === answer && current === answer))
          return fail("A new dropdown answer appeared while opening; preserved it");
        const popups = popupNodes(element);
        if (popups.some((popup) => popup.getAttribute("aria-multiselectable") === "true")) {
          rollback();
          return fail("Multiple-choice dropdown requires manual selection");
        }
        const options = [
          ...new Set(
            popups.flatMap((popup) => [...popup.querySelectorAll('[role="option"]')])
          )
        ].filter(
          (option) => visible(option) && !isDropdownPlaceholder(option.getAttribute("aria-label") || option.textContent) && option.getAttribute("aria-disabled") !== "true" && !option.hasAttribute("disabled")
        );
        const matches = options.filter(
          (option) => optionValues(option).some((value) => answersMatch(value, answers))
        );
        if (matches.length > 1) {
          rollback();
          return fail("More than one dropdown option matches; choose manually");
        }
        if (matches.length === 1) {
          selected = matches[0];
          break;
        }
        if (attempt === 1 && input && !input.readOnly && visible(input)) {
          typed = true;
          setInput(input, answer);
        }
        await wait(element.ownerDocument, 50);
      }
      if (!selected) {
        rollback();
        return fail("No matching option in the dropdown; choose manually");
      }
      if (signal?.aborted) {
        rollback();
        return fail("Automatic filling was stopped");
      }
      if (selected.closest("a[href]") || selected.tagName === "BUTTON" && selected.form && selected.type !== "button" || selected.tagName === "INPUT" && ["submit", "image"].includes(selected.type)) {
        rollback();
        return fail("Dropdown option could submit or navigate the page; select it manually");
      }
      const beforeClick = comboboxValue(element);
      const wasSelected = selected.getAttribute("aria-selected") === "true";
      const wasExpanded = element.getAttribute("aria-expanded") === "true" || input?.getAttribute("aria-expanded") === "true";
      activate(selected);
      for (let attempt = 0; attempt < 6; attempt++) {
        await wait(element.ownerDocument, 40);
        if (userChanged) return fail("Your dropdown edit was preserved");
        if (!element.isConnected)
          return fail("Dropdown changed during selection; review the current step");
        const value = comboboxValue(element);
        const selectedState = !wasSelected && selected.getAttribute("aria-selected") === "true";
        const collapsed = wasExpanded && (element.getAttribute("aria-expanded") === "false" || input?.getAttribute("aria-expanded") === "false");
        const acceptedText = answersMatch(value, answers) && (value !== beforeClick || collapsed);
        const committed = answersMatch(committedValue(element), answers);
        if (committed || !backingSelect(element) && (selectedState || acceptedText))
          return {
            filled: true,
            reason: "Selected the matching dropdown option; review before submitting"
          };
      }
      rollback();
      return fail("The dropdown did not confirm the selected option; review manually");
    } catch {
      rollback();
      return fail("This dropdown needs manual selection");
    } finally {
      element.removeEventListener("input", onUserChange, true);
      element.removeEventListener("change", onUserChange, true);
    }
  }

  // src/resume.ts
  var MAX_BYTES = 20 * 1024 * 1024;
  var TYPES = {
    pdf: "application/pdf",
    doc: "application/msword",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    txt: "text/plain",
    rtf: "application/rtf",
    odt: "application/vnd.oasis.opendocument.text"
  };
  var identities = /* @__PURE__ */ new WeakMap();
  var identityCount = 0;
  var attachments = [];
  function id(element) {
    let value = identities.get(element);
    if (!value) {
      value = `resume-${++identityCount}`;
      identities.set(element, value);
    }
    return value;
  }
  function text2(element) {
    return (element?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 600);
  }
  function parent2(element) {
    return element.parentElement || element.getRootNode().host || null;
  }
  function visible2(element) {
    if (!element.isConnected) return false;
    for (let node = element; node; node = parent2(node)) {
      const style = element.ownerDocument.defaultView?.getComputedStyle(node);
      if (node.hasAttribute("hidden") || node.getAttribute("aria-hidden") === "true" || node.hasAttribute("inert") || style?.display === "none" || style?.visibility === "hidden")
        return false;
    }
    return true;
  }
  function roots(root) {
    return [
      root,
      ...[...root.querySelectorAll("*")].flatMap(
        (element) => element.shadowRoot ? roots(element.shadowRoot) : []
      )
    ];
  }
  function clean3(value) {
    return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_-]+/g, " ").toLowerCase();
  }
  function labelledBy(element) {
    const root = element.getRootNode();
    return (element.getAttribute("aria-labelledby") || "").split(/\s+/).filter(Boolean).map((key) => text2(root.getElementById(key))).join(" ");
  }
  function description(input) {
    const direct = [
      labelledBy(input),
      input.getAttribute("aria-label"),
      ...[...input.labels || []].map(text2)
    ].filter(Boolean).join(" ");
    let context = null;
    let nearby = "";
    for (let node = input.parentElement, level = 0; node && level < 4; node = node.parentElement, level++) {
      if (node.matches("form,body,html") || node.querySelectorAll('input[type="file"]').length !== 1)
        break;
      if (node.matches(
        'fieldset,[data-automation-id*="upload"],[data-testid*="upload"],[class*="upload"],[class*="Upload"],[class*="dropzone"],[class*="field"],[class*="Field"]'
      )) {
        const candidate = text2(node);
        if (candidate.length <= 500) {
          context = node;
          nearby = candidate;
          break;
        }
      }
    }
    return {
      label: [direct, nearby, input.name, input.id, input.getAttribute("data-automation-id")].filter(Boolean).join(" ").trim(),
      context,
      labelled: !!direct
    };
  }
  function scanResumeInputs(document2) {
    return roots(document2).flatMap(
      (root) => [...root.querySelectorAll('input[type="file"]')].map((element) => {
        const info = description(element);
        const label = info.label || "Unlabelled file upload";
        const normalized = clean3(label);
        let reason;
        if (!/\b(resume|cv|curriculum vitae)\b/.test(normalized))
          reason = "Upload is not explicitly identified as a resume or CV";
        if (/\b(cover letter|coverletter|photo|photograph|picture|certificate|certification|transcript|passport|identity|portfolio)\b/.test(
          normalized
        ))
          reason = "This upload asks for a different or ambiguous document";
        if (element.files?.length) reason = "Existing attachment preserved";
        if (element.disabled || element.getAttribute("aria-disabled") === "true")
          reason = "Resume upload is disabled";
        if (!visible2(element) && !(info.context && visible2(info.context)) && ![...element.labels || []].some(visible2))
          reason = "Upload is hidden without a visible upload control";
        return { element, label, ...reason ? { reason } : {} };
      })
    );
  }
  function decode(saved, document2) {
    const name = typeof saved.fileName === "string" ? saved.fileName.split(/[\\/]/).at(-1)?.trim() || "" : "";
    const extension = name.split(".").at(-1)?.toLowerCase() || "";
    if (!name || !TYPES[extension])
      throw new Error("Save a PDF, DOC, DOCX, TXT, RTF or ODT resume in your profile first.");
    if (typeof saved.resumeBase64 !== "string" || !saved.resumeBase64.trim())
      throw new Error("No saved resume is available in your profile.");
    let data = saved.resumeBase64.trim();
    if (data.startsWith("data:")) {
      const match = /^data:[^;,]*;base64,([\s\S]*)$/.exec(data);
      if (!match)
        throw new Error("The saved resume data URL is invalid. Replace the resume in your profile.");
      data = match[1];
    }
    data = data.replace(/\s/g, "");
    if (!data || data.length > Math.ceil(MAX_BYTES / 3) * 4 + 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data) || data.length % 4 === 1)
      throw new Error("The saved resume is invalid or larger than the 20 MB local limit.");
    let binary;
    try {
      binary = document2.defaultView.atob(data);
    } catch {
      throw new Error("The saved resume could not be decoded. Replace it in your profile.");
    }
    if (!binary.length || binary.length > MAX_BYTES)
      throw new Error("The saved resume is empty or larger than the 20 MB local limit.");
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    return new document2.defaultView.File([bytes], name, { type: TYPES[extension] });
  }
  function accepted(input, file) {
    const patterns = input.accept.toLowerCase().split(",").map((value) => value.trim()).filter(Boolean);
    return !patterns.length || patterns.some(
      (pattern) => pattern === "*/*" || pattern.startsWith(".") && file.name.toLowerCase().endsWith(pattern) || pattern.endsWith("/*") && file.type.startsWith(pattern.slice(0, -1)) || pattern === file.type
    );
  }
  function events(input) {
    const win = input.ownerDocument.defaultView;
    input.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
  }
  function sameFile(left, right) {
    return !!left && left.name === right.name && left.size === right.size && left.type === right.type && left.lastModified === right.lastModified;
  }
  async function attachResume(document2, saved) {
    const report = { filled: 0, skipped: 0, questions: [] };
    const targets = scanResumeInputs(document2);
    let file;
    try {
      file = decode(saved, document2);
    } catch (error) {
      return {
        ...report,
        error: error instanceof Error ? error.message : "Unable to read saved resume."
      };
    }
    for (const target of targets) {
      const input = target.element;
      let reason = target.reason;
      let filled = false;
      if (!reason && !accepted(input, file))
        reason = "This upload does not accept the saved resume file type";
      if (!reason) {
        try {
          const transfer = new document2.defaultView.DataTransfer();
          transfer.items.add(file);
          input.files = transfer.files;
          events(input);
          if (sameFile(input.files?.[0], file)) {
            attachments.push({ element: input, file });
            filled = true;
            reason = "Resume attached to the file input; check the website upload status";
          } else reason = "The page did not retain the resume attachment; upload it manually";
        } catch {
          reason = "This upload needs a manual file selection";
        }
      }
      if (filled) report.filled++;
      else report.skipped++;
      report.questions.push({
        id: id(input),
        label: target.label,
        kind: "file",
        filled: filled || !!input.files?.length,
        reason
      });
    }
    if (!targets.length)
      report.error = "No file upload inputs found. Open the resume upload step and try again.";
    return report;
  }

  // src/panel-dock.ts
  function mountPanelDock() {
    if (window.top !== window) return () => {
    };
    let host;
    let stopped = false;
    let panelHidden = false;
    let enabled = false;
    let stateVersion = 0;
    let preferenceVersion = 0;
    function hide() {
      host?.remove();
      host = void 0;
    }
    function show() {
      if (host?.isConnected) return;
      host = document.createElement("div");
      host.id = "ezeapply-panel-restore";
      const shadow = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = ":host{all:initial;position:fixed;z-index:2147483000;right:10px;bottom:24px;display:block}button{font:600 12px/1.2 -apple-system,BlinkMacSystemFont,sans-serif;color:white;background:linear-gradient(120deg,#167f70,#3b9f8b);border:1px solid #a4c5dc;border-radius:20px;padding:10px 13px;box-shadow:0 3px 16px #0004;cursor:pointer}button:focus-visible{outline:3px solid #89bdd4;outline-offset:3px}";
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "\u2039 EZEapply";
      button.title = "Show EZEapply side panel";
      button.setAttribute("aria-label", "Show EZEapply side panel");
      button.addEventListener("click", () => {
        button.disabled = true;
        chrome.runtime.sendMessage({ type: "eze-custom:show-panel" }).then((result2) => {
          if (result2?.ok) hide();
          else {
            button.disabled = false;
            button.title = result2?.error || "Open EZEapply from the Chrome toolbar";
          }
        }).catch(() => {
          button.disabled = false;
          button.title = "Open EZEapply from the Chrome toolbar";
        });
      });
      shadow.append(style, button);
      document.documentElement.append(host);
    }
    function render() {
      if (!stopped && panelHidden && enabled) show();
      else hide();
    }
    const receive = (message, _sender, respond) => {
      if (message?.type !== "eze-custom:panel-hidden") return;
      stateVersion++;
      panelHidden = message.hidden === true;
      render();
      respond({ ok: true });
    };
    const preferenceChanged = (changes, area) => {
      if (area !== "local" || !changes[PANEL_RESTORE_KEY]) return;
      preferenceVersion++;
      enabled = changes[PANEL_RESTORE_KEY].newValue === true;
      render();
    };
    chrome.runtime.onMessage.addListener(receive);
    chrome.storage.onChanged.addListener(preferenceChanged);
    const initialState = stateVersion;
    chrome.runtime.sendMessage({ type: "eze-custom:panel-state" }).then((result2) => {
      if (stopped || stateVersion !== initialState) return;
      panelHidden = result2?.hidden === true;
      render();
    }).catch(() => {
    });
    const initialPreference = preferenceVersion;
    chrome.storage.local.get(PANEL_RESTORE_KEY).then((data) => {
      if (stopped || preferenceVersion !== initialPreference) return;
      enabled = data[PANEL_RESTORE_KEY] === true;
      render();
    }).catch(() => {
    });
    return () => {
      stopped = true;
      hide();
      chrome.runtime.onMessage.removeListener(receive);
      chrome.storage.onChanged.removeListener(preferenceChanged);
    };
  }

  // src/linkedin-follow.ts
  var APPLICATION_DIALOG_SELECTOR = 'dialog,.jobs-easy-apply-modal,[role="dialog"]';
  function visible3(element) {
    for (let node = element; node; node = node.parentElement) {
      if (node.hasAttribute("hidden") || node.hasAttribute("inert") || node.getAttribute("aria-hidden") === "true")
        return false;
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return element.isConnected;
  }
  function checked(element) {
    return element.tagName === "INPUT" ? element.checked : element.getAttribute("aria-checked") === "true";
  }
  function applicationFollowChoices(root) {
    const result2 = /* @__PURE__ */ new Set();
    for (const dialog of root.querySelectorAll(APPLICATION_DIALOG_SELECTOR)) {
      if (!visible3(dialog)) continue;
      const description2 = `${ariaLabel(dialog)} ${dialog.getAttribute("aria-label") || ""} ${(dialog.textContent || "").slice(0, 16e3)}`;
      if (!dialog.matches(".jobs-easy-apply-modal") && !/\b(?:apply to|easy apply|review your application|job application|submit application)\b/i.test(
        description2
      ))
        continue;
      for (const control of dialog.querySelectorAll(
        'input[type="checkbox"],[role="checkbox"]'
      )) {
        if (!checked(control) || control.hasAttribute("disabled") || control.closest('[aria-disabled="true"],fieldset[disabled]'))
          continue;
        if (control.tagName === "A" && control.hasAttribute("href") || control.tagName === "BUTTON" && control.form && control.type !== "button")
          continue;
        const labels = control.tagName === "INPUT" ? [...control.labels || []] : [...root.querySelectorAll("label[for]")].filter(
          (label2) => !!control.id && label2.getAttribute("for") === control.id
        );
        const enclosing = control.closest("label");
        if (enclosing && !labels.includes(enclosing)) labels.push(enclosing);
        if (!visible3(control) && !labels.some(visible3)) continue;
        const label = normalize(
          [
            ariaLabel(control),
            control.getAttribute("aria-label") || "",
            ...labels.map((label2) => label2.textContent || "")
          ].join(" ")
        );
        const knownIdentity = [control.id, control.getAttribute("name") || ""].some(
          (value) => /^follow company(?: checkbox)?$/.test(normalize(value))
        );
        if (!/\bfollow\b/.test(label) && !knownIdentity) continue;
        if (/\b(?:agree|consent|terms|privacy|polic(?:y|ies)|rules|instructions|guidelines|practices|certify|attest|follow up|unfollow|do not follow|don t follow|stop following|disable follow)\b/.test(
          label
        ))
          continue;
        const offer = /\b(?:do you want to|would you like to|opt in to) follow\b/.test(label);
        if (!offer && /^(?:do|does|did|have|has|are|is|which|what|how|when|why|can|could|will)\b/.test(label))
          continue;
        result2.add(control);
      }
    }
    return [...result2];
  }
  function isLinkedInHost(hostname) {
    return hostname === "linkedin.com" || hostname.endsWith(".linkedin.com");
  }
  function mountLinkedInFollow() {
    if (!isLinkedInHost(location.hostname)) return () => {
    };
    let stopped = false, enabled = false, revision = 0, queued = false, poll;
    const attempts = /* @__PURE__ */ new WeakMap();
    function scan() {
      if (stopped || !enabled || document.visibilityState === "hidden") return;
      for (const control of applicationFollowChoices(document)) {
        const dialog = control.closest(APPLICATION_DIALOG_SELECTOR);
        const question2 = normalize(
          `${ariaLabel(control)} ${control.getAttribute("aria-label") || ""} ${control.closest("label")?.textContent || ""} ${control.tagName === "INPUT" ? [...control.labels || []].map((label) => label.textContent).join(" ") : ""} ${dialog?.getAttribute("aria-label") || ""} ${dialog?.querySelector('h2,[role="heading"]')?.textContent || ""}`
        );
        const now = Date.now(), previous = attempts.get(control), count = previous && previous.until > now && previous.question === question2 ? previous.count : 0;
        if (count >= 3) continue;
        attempts.set(control, { count: count + 1, until: now + 3e4, question: question2 });
        try {
          control.click();
        } catch {
        }
      }
    }
    function schedule() {
      if (stopped || !enabled || queued) return;
      queued = true;
      queueMicrotask(() => {
        queued = false;
        scan();
      });
    }
    const observer = new MutationObserver(schedule);
    function watch() {
      observer.disconnect();
      if (poll) clearInterval(poll);
      poll = void 0;
      if (!stopped && enabled) {
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: [
            "open",
            "checked",
            "aria-checked",
            "aria-label",
            "aria-labelledby",
            "hidden",
            "aria-hidden",
            "disabled",
            "class",
            "style"
          ]
        });
        poll = setInterval(scan, 1e3);
        scan();
      }
    }
    const changed = (changes, area) => {
      if (stopped || area !== "local" || !changes[LINKEDIN_NOFOLLOW_KEY]) return;
      revision++;
      enabled = changes[LINKEDIN_NOFOLLOW_KEY].newValue === true;
      watch();
    };
    chrome.storage.onChanged.addListener(changed);
    const initial = revision;
    chrome.storage.local.get(LINKEDIN_NOFOLLOW_KEY).then((data) => {
      if (stopped || revision !== initial) return;
      enabled = data[LINKEDIN_NOFOLLOW_KEY] === true;
      watch();
    }).catch(() => {
    });
    document.addEventListener("change", schedule, true);
    document.addEventListener("visibilitychange", schedule);
    return () => {
      stopped = true;
      observer.disconnect();
      if (poll) clearInterval(poll);
      chrome.storage.onChanged.removeListener(changed);
      document.removeEventListener("change", schedule, true);
      document.removeEventListener("visibilitychange", schedule);
    };
  }

  // src/field-format.ts
  function visible4(element) {
    for (let node = element; node; node = parentOf(node)) {
      if (node.hasAttribute("hidden") || node.hasAttribute("inert") || node.getAttribute("aria-hidden") === "true")
        return false;
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return element.isConnected;
  }
  function generatedText(content) {
    if (!/^(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')$/.test(content.trim())) return "";
    return content.trim().slice(1, -1).replace(/\\([\da-f]{1,6})\s?/gi, (_match, hex) => {
      const point = parseInt(hex, 16);
      return point > 0 && point <= 1114111 ? String.fromCodePoint(point) : "";
    }).replace(/\\(.)/g, "$1");
  }
  function fieldFormatHints(control) {
    const hints = /* @__PURE__ */ new Set();
    const add = (value) => {
      const text5 = value?.replace(/\s+/g, " ").trim();
      if (text5 && text5.length <= 500) hints.add(text5);
    };
    add(fieldInstructions(control));
    add(control.getAttribute("placeholder"));
    add(control.getAttribute("aria-description"));
    let scope = control;
    for (let depth = 0; depth < 5; depth++) {
      const parent3 = parentOf(scope);
      if (!parent3 || parent3.matches('form,body,html,main,section,dialog,[role="dialog"]') || controlsWithin(parent3) !== 1)
        break;
      scope = parent3;
      if (scope.matches(
        '[data-automation-id^="formField"],.form-group,.form-field,.field,.application-question,[data-testid="field"]'
      ))
        break;
    }
    const win = control.ownerDocument.defaultView;
    const supportsPseudo = !!win.CSS?.supports?.("selector(::after)");
    const nodes = [scope, ...scope.querySelectorAll("*")].slice(0, 80);
    for (const node of nodes) {
      if (node !== control && node.matches(`${CONTROL_SELECTOR},button,a,script,style,[role="option"]`))
        continue;
      if (!visible4(node)) continue;
      add(
        [...node.childNodes].filter((child) => child.nodeType === 3).map((child) => child.textContent || "").join(" ")
      );
      for (const attribute of ["data-unit", "data-suffix", "data-prefix"])
        add(node.getAttribute(attribute));
      if (supportsPseudo)
        for (const pseudo of ["::before", "::after"]) {
          const style = win.getComputedStyle(node, pseudo);
          if (style.display !== "none" && style.visibility !== "hidden" && style.visibility !== "collapse")
            add(generatedText(style.content));
        }
    }
    return [...hints];
  }
  function fieldMatchingLabels(control, labels) {
    const primary = labels[0];
    if (!primary || !matchingTerms(primary).compensation) return { labels };
    const signals = [primary, ...fieldFormatHints(control)].map(monetaryFormat);
    const currencies = [...new Set(signals.flatMap((signal) => signal.currencies))];
    const scales = [...new Set(signals.flatMap((signal) => signal.scales))];
    const periods = [...new Set(signals.flatMap((signal) => signal.periods))];
    if (currencies.length > 1 || scales.length > 1 || periods.length > 1)
      return {
        labels,
        blocked: "The field shows conflicting currency, amount-scale or pay-period hints; review its required format"
      };
    const periodText = {
      year: "per annum",
      month: "per month",
      week: "per week",
      day: "per day",
      hour: "per hour"
    };
    const hint = [currencies[0], scales[0], periods[0] && periodText[periods[0]]].filter(Boolean).join(" ");
    if (!hint) return { labels };
    const full = `${primary} \xB7 ${hint}`, before = matchingTerms(primary), after = matchingTerms(full);
    if (before.currency === after.currency && before.amountUnit === after.amountUnit && before.payPeriod === after.payPeriod)
      return { labels };
    return { labels: [full, ...labels] };
  }

  // src/application-context.ts
  var APPLICATION_ID = /\b(?:job application|employment application|candidate application|internship application|candidate form|hiring form|recruitment form)\b/;
  var APPLICATION_TEXT = /\b(?:job application|employment application|candidate application|internship application|candidate information|applicant details|review your application|submit (?:your )?application|cover letter)\b/i;
  var APPLICATION_HEADING = /\b(?:job|employment|internship|recruitment|hiring) (?:application|form|questionnaire)\b|\b(?:engineer|engineering|developer|designer|analyst|intern|scientist|manager|specialist|associate)\b.{0,80}\bapplication (?:form|questionnaire)\b/i;
  var APPLICATION_ACTION = /\b(?:apply (?:to|for)|application for|application form|apply form)\b/i;
  var JOB_QUESTION = /\b(?:this (?:job|role|position)|ctc|notice period|work authorization|visa sponsorship|professional experience|work experience|linkedin profile)\b/i;
  var RESUME = /\b(?:resume|cv)\b|résumé/i;
  var APPLICATION_ROUTE = /(?:^|\/)(?:apply|application|applications|candidatev?\d*|candidate-application)(?:[\/._-]|$)/i;
  var CAREER_ROUTE = /(?:^|[./_-])(?:careers?|jobs?|recruitment)(?:[./_-]|$)/i;
  var ATS_HOST = /(?:^|\.)(?:myworkdayjobs\.com|greenhouse\.io|lever\.co|ashbyhq\.com|workable\.com|icims\.com|smartrecruiters\.com|successfactors\.com|taleo\.net|breezy\.hr|recruitee\.com|personio\.(?:com|de)|jobvite\.com|applytojob\.com|bamboohr\.com|teamtailor\.com|pinpointhq\.com|oraclecloud\.com|avature\.net|darwinbox\.(?:in|com))$/i;
  var COMMUNICATION = /\b(?:chat|chatbox|messaging|conversation|conversations|composer|compose|reply|replies|comment|comments|newsletter|subscribe|subscription|feedback|search)\b/;
  var OTHER_FORM = /\b(?:contact us|contact form|support form|send (?:us )?a message|newsletter|subscribe|feedback|search|sign in|log in)\b/i;
  var FORM_SCOPE = 'form,[role="form"]';
  var DIALOG_SCOPE = 'dialog,[role="dialog"],.jobs-easy-apply-modal';
  function visible5(element) {
    if (!element.isConnected) return false;
    for (let node = element; node; node = parentOf(node)) {
      if (node.hasAttribute("hidden") || node.hasAttribute("inert") || node.getAttribute("aria-hidden") === "true")
        return false;
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function effectiveURL(root) {
    const url = new URL(root.location?.href || "about:blank");
    return /^about:(?:blank|srcdoc)$/.test(url.href) && /^https?:/.test(root.referrer || "") ? new URL(root.referrer) : url;
  }
  var hostIs = (hostname, domain) => hostname === domain || hostname.endsWith(`.${domain}`);
  function isCommunicationPage(url) {
    const host = url.hostname.toLowerCase();
    if ([
      "mail.google.com",
      "outlook.live.com",
      "outlook.office.com",
      "outlook.office365.com",
      "mail.yahoo.com",
      "web.whatsapp.com",
      "web.telegram.org",
      "teams.microsoft.com",
      "teams.live.com",
      "messenger.com"
    ].some((domain) => hostIs(host, domain)))
      return true;
    if (hostIs(host, "discord.com") || hostIs(host, "discordapp.com") || hostIs(host, "slack.com"))
      return !CAREER_ROUTE.test(url.pathname);
    return false;
  }
  function metadata(element) {
    return normalize(
      [
        element.id,
        element.getAttribute("class"),
        element.getAttribute("name"),
        element.getAttribute("data-testid"),
        element.getAttribute("data-automation-id")
      ].filter(Boolean).join(" ")
    );
  }
  function heading(scope) {
    return [
      scope.getAttribute("aria-label") || "",
      ...(scope.getAttribute("aria-labelledby") || "").split(/\s+/).filter(Boolean).map((id2) => scope.ownerDocument.getElementById(id2)?.textContent || ""),
      ...[...scope.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')].filter(visible5).slice(0, 12).map((node) => node.textContent || "")
    ].join(" ").slice(0, 2500);
  }
  function scopeText(scope) {
    const walker = scope.ownerDocument.createTreeWalker(scope, 4);
    let text5 = "", node;
    while ((node = walker.nextNode()) && text5.length < 16e3) {
      if (node.parentElement?.closest('script,style,template,[hidden],[aria-hidden="true"]'))
        continue;
      text5 += ` ${node.textContent || ""}`;
    }
    return text5.slice(0, 16e3);
  }
  function communicationField(control) {
    if (control.matches('input[type="search"],[role="searchbox"]')) return true;
    const labels = fieldLabels(control).slice(0, 3).map(normalize);
    if (labels.some(
      (label) => /^(?:search\b|message\b|reply\b|comment$|write (?:a |your )?(?:message|reply|comment)|type (?:a |your )?message)/.test(
        label
      )
    ))
      return true;
    for (let node = control; node && !node.matches("body,html"); node = parentOf(node)) {
      if (node.matches(
        'nav,header,footer,[role="navigation"],[role="search"],[role="log"],[role="feed"]'
      ))
        return true;
      if (COMMUNICATION.test(metadata(node))) return true;
      if (node !== control && node.matches(FORM_SCOPE)) break;
    }
    return false;
  }
  function applicationScope(scope, url) {
    if (!visible5(scope) || COMMUNICATION.test(metadata(scope))) return false;
    const title = heading(scope), identity3 = metadata(scope), body = scopeText(scope);
    if (hostIs(url.hostname, "linkedin.com"))
      return scope.matches(".jobs-easy-apply-modal") || scope.matches('dialog,[role="dialog"]') && /\b(?:apply to|easy apply|review your application)\b/i.test(title);
    if (OTHER_FORM.test(title)) return false;
    if (APPLICATION_ID.test(identity3) || APPLICATION_ID.test(normalize(title)) || APPLICATION_TEXT.test(title) || APPLICATION_HEADING.test(title))
      return true;
    const resume = RESUME.test(body);
    const careerSite = ATS_HOST.test(url.hostname) || CAREER_ROUTE.test(`${url.hostname}${url.pathname}`);
    if (APPLICATION_ACTION.test(`${title} ${identity3}`) && (resume || careerSite || JOB_QUESTION.test(body)))
      return true;
    if (resume && (/\bapply (?:to|for)\b/i.test(title) || APPLICATION_TEXT.test(body) || /\bupload (?:your |new )?(?:resume|cv)\b/i.test(body)))
      return true;
    return scope.matches(FORM_SCOPE) && careerSite && (resume || APPLICATION_TEXT.test(body) || JOB_QUESTION.test(body));
  }
  function isApplicationField(control, url = effectiveURL(control.ownerDocument)) {
    if (isCommunicationPage(url) || !visible5(control) || communicationField(control)) return false;
    const scopes2 = [];
    for (let node = parentOf(control); node && !node.matches("body,html"); node = parentOf(node)) {
      if (node.matches(`${FORM_SCOPE},${DIALOG_SCOPE},main,[role="main"]`)) scopes2.push(node);
    }
    const form = scopes2.find((scope) => scope.matches(FORM_SCOPE));
    if (form && OTHER_FORM.test(`${heading(form)} ${metadata(form)}`)) return false;
    const localScopes = scopes2.filter(
      (scope) => !form || scope === form || [...scope.querySelectorAll(FORM_SCOPE)].every((candidate) => candidate === form)
    );
    if (localScopes.some((scope) => applicationScope(scope, url))) return true;
    if (hostIs(url.hostname, "linkedin.com")) return false;
    const root = control.ownerDocument;
    const soleForm = !form || [...root.querySelectorAll(FORM_SCOPE)].every((candidate) => candidate === form);
    const jobApplicationRoute = APPLICATION_ROUTE.test(url.pathname) && (ATS_HOST.test(url.hostname) || CAREER_ROUTE.test(`${url.hostname}${url.pathname}`));
    return soleForm && (jobApplicationRoute || APPLICATION_ID.test(normalize(root.title)) || APPLICATION_HEADING.test(root.title));
  }

  // src/submission-capture.ts
  var DIALOG = 'dialog,[role="dialog"],.jobs-easy-apply-modal';
  var FORM = `form,[role="form"],${DIALOG}`;
  var TTL = 30 * 60 * 1e3;
  var EXCLUDED = /\b(?:chat|conversation|messaging|composer|comment|newsletter|subscribe|search|feedback|support|contact us|sign in|log in)\b/i;
  var SUCCESS = /\b(?:(?:your (?:job )?)?application (?:has been |was |is )?(?:successfully )?(?:submitted|sent|received)|we (?:have |successfully )?received your (?:job )?application|thank(?:s| you) for (?:applying|your (?:job )?application)|your (?:response|responses) (?:has|have) been recorded)\b/i;
  var LINKEDIN_SUCCESS = /^(?:application (?:sent|submitted)|your application (?:was |has been )?(?:sent|submitted))(?:[.!\s]|$)/i;
  var FAILURE = /\b(?:unable to|failed to|could not|couldn.t|cannot|can.t|was not|wasn.t|has not|hasn.t|not successfully|not (?:submitted|sent|received)|error (?:sending|submitting)|already (?:applied|submitted))\b/i;
  var METADATA_ATTRIBUTES = ["id", "class", "name", "data-testid", "data-test-id"];
  function text3(node) {
    const walk = node.ownerDocument.createTreeWalker(node, 4);
    let result2 = "", child;
    while ((child = walk.nextNode()) && result2.length < 6e3) {
      if (child.parentElement?.closest('script,style,template,[hidden],[aria-hidden="true"]'))
        continue;
      result2 += ` ${child.textContent || ""}`;
    }
    return result2.replace(/\s+/g, " ").trim().slice(0, 6e3);
  }
  function visible6(element) {
    if (!element.isConnected) return false;
    for (let node = element; node; node = parentOf(node)) {
      if (node.hasAttribute("hidden") || node.hasAttribute("inert") || node.getAttribute("aria-hidden") === "true")
        return false;
      if (node.tagName === "DIALOG" && !node.hasAttribute("open")) return false;
      const style = node.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function identity(node) {
    return METADATA_ATTRIBUTES.map((name) => node.getAttribute(name) || "").join(" ").replace(/[_-]+/g, " ");
  }
  function excluded(node) {
    for (let item = node; item && !item.matches("body,html"); item = parentOf(item)) {
      if (item.matches('nav,footer,[role="log"],[role="feed"],[role="search"]') || EXCLUDED.test(identity(item)))
        return true;
      if (item !== node && item.matches(FORM)) break;
    }
    return false;
  }
  function heading2(scope) {
    return [scope.getAttribute("aria-label"), ...scope.querySelectorAll('h1,h2,h3,[role="heading"]')].map((item) => typeof item === "string" ? item : item?.textContent || "").join(" ").replace(/\s+/g, " ").trim();
  }
  function linkedIn(url) {
    return url.hostname === "linkedin.com" || url.hostname.endsWith(".linkedin.com");
  }
  function submissionScope(control, url = new URL(control.ownerDocument.location.href)) {
    if (isCommunicationPage(url) || excluded(control)) return;
    for (let node = control; node && !node.matches("body,html"); node = parentOf(node)) {
      if (!node.matches(FORM) || !visible6(node)) continue;
      if (EXCLUDED.test(`${identity(node)} ${heading2(node)}`)) return;
      if (linkedIn(url)) {
        if (node.matches(DIALOG) && /\b(?:easy apply|apply to|review your application|submit application)\b/i.test(
          `${heading2(node)} ${text3(node).slice(0, 2500)}`
        ))
          return node;
      } else if (isApplicationField(control, url)) return node;
    }
    if (!linkedIn(url) && isApplicationField(control, url))
      return control.closest('main,[role="main"]') || void 0;
  }
  function finalButton(button, source) {
    if (button.matches('a[href],input[type="image"]') || button.hasAttribute("disabled") || button.getAttribute("aria-disabled") === "true")
      return false;
    const label = (button.getAttribute("aria-label") || ("value" in button ? button.value : "") || text3(button)).replace(/\s+/g, " ").trim();
    if (/\b(?:next|continue|review|save|back|previous|cancel|upload|sign in|log in)\b/i.test(label))
      return false;
    if (/^(?:submit|send|finish|complete) (?:my |your |the )?(?:job )?application(?: now)?[.!]?$/i.test(
      label
    ))
      return true;
    return source === "external" && /^(?:submit|send|finish|complete|apply|apply now)[.!]?$/i.test(label);
  }
  function metadata2(scope, url) {
    const root = scope.ownerDocument;
    const scopeHeading = heading2(scope);
    const title = root.querySelector(
      "[data-test-job-title],.job-details-jobs-unified-top-card__job-title,.jobs-unified-top-card__job-title,h1"
    );
    let jobTitle = (title?.textContent || "").trim();
    if (!jobTitle || /^(?:apply to|review your application|job application)$/i.test(jobTitle))
      jobTitle = root.title.replace(/\s*[|–—]\s*(?:LinkedIn|careers?).*$/i, "").trim();
    const company = root.querySelector(
      "[data-test-company-name],.job-details-jobs-unified-top-card__company-name,.jobs-unified-top-card__company-name"
    );
    const applyTo = /\bapply to\s+(.+?)(?=\s+(?:review your|contact info|step \d)|$)/i.exec(
      scopeHeading
    );
    return {
      url: url.href,
      jobTitle: jobTitle.slice(0, 250),
      company: (company?.textContent?.trim() || applyTo?.[1] || "").slice(0, 200),
      source: linkedIn(url) ? "linkedin" : "external"
    };
  }
  function scopes(root) {
    const found = [root];
    for (let index = 0; index < found.length; index++)
      for (const node of found[index].querySelectorAll("*"))
        if (node.shadowRoot && node.localName !== "ezeapply-ai") found.push(node.shadowRoot);
    return found;
  }
  function successCandidates(root, source) {
    const results = /* @__PURE__ */ new Map();
    const consider = (node) => {
      if (!visible6(node) || excluded(node) || node.closest('input,textarea,[contenteditable="true"]'))
        return;
      const value = text3(node);
      if (!value || value.length > 1200 || FAILURE.test(value)) return;
      const match = SUCCESS.exec(value) || (source === "linkedin" ? LINKEDIN_SUCCESS.exec(value) : null);
      if (match) results.set(node, value);
    };
    for (const scope of scopes(root)) {
      for (const node2 of scope.querySelectorAll(
        'h1,h2,h3,h4,[role="heading"],[role="status"],[role="alert"],[class*="success"],[id*="success"],[id*="confirmation"],main,dialog,[role="dialog"]'
      ))
        consider(node2);
      const walker = root.createTreeWalker(scope, 4);
      let node, count = 0;
      while ((node = walker.nextNode()) && count++ < 6e3) {
        if (node.parentElement && (SUCCESS.test(node.textContent || "") || source === "linkedin" && LINKEDIN_SUCCESS.test((node.textContent || "").trim())))
          consider(node.parentElement);
      }
    }
    return results;
  }
  function relevant(node, original, root) {
    if (original?.isConnected && visible6(original)) {
      if (original.contains(node)) return true;
      if (node.contains(original)) return false;
      const other = node.closest(FORM);
      if (other && !other.contains(original) && !original.contains(other))
        return node.matches('dialog,[role="dialog"]') && /application|applying/i.test(text3(node));
      if (node.closest('[role="alert"],[role="status"],.artdeco-toast-item')) return true;
      const originalMain = original.closest('main,[role="main"]');
      return !!originalMain && originalMain.contains(node) && !node.closest('form,[role="form"]');
    }
    const container = node.closest('form,[role="form"]');
    if (container && [...container.querySelectorAll('input:not([type="hidden"]),textarea,select')].some(visible6))
      return false;
    return node.ownerDocument === root;
  }
  function mountSubmissionCapture(options = {}) {
    const root = options.root || document;
    const currentURL = options.url || (() => new URL(root.location.href));
    if (isCommunicationPage(currentURL())) return () => {
    };
    let stopped = false, queued = false, busy = false, original, pending;
    let prepared = false, preparePromise, startedAt = 0, revision = 0, failures = 0;
    let baseline = /* @__PURE__ */ new Map();
    let retry;
    const observed = /* @__PURE__ */ new WeakSet();
    const observer = new MutationObserver(schedule);
    const completed = /* @__PURE__ */ new Set();
    function observe() {
      for (const scope of scopes(root))
        if (!observed.has(scope)) {
          observer.observe(scope, {
            subtree: true,
            childList: true,
            characterData: true,
            attributes: true,
            attributeFilter: ["open", "hidden", "aria-hidden", "class", "style"]
          });
          observed.add(scope);
        }
    }
    function prepare(scope) {
      const url = currentURL();
      if (isCommunicationPage(url)) return;
      if (pending && original === scope && Date.now() - startedAt < 2e3) return;
      const intent = { id: crypto.randomUUID(), ...metadata2(scope, url) };
      pending = intent;
      original = scope;
      prepared = false;
      startedAt = Date.now();
      failures = 0;
      baseline = successCandidates(root, intent.source);
      const request = ++revision;
      preparePromise = chrome.runtime.sendMessage({ type: "eze-tracking:prepare", intent }).then((result2) => {
        if (stopped || request !== revision) return;
        if (!result2?.ok) throw new Error("Tracking intent was not saved");
        prepared = true;
        schedule();
      }).catch(() => {
        if (!stopped && request === revision) {
          pending = void 0;
          prepared = false;
        }
      });
    }
    async function scan() {
      if (stopped || busy || !pending || !prepared || completed.has(pending.id)) return;
      const url = currentURL();
      if (isCommunicationPage(url) || Date.now() - startedAt > TTL || url.origin !== new URL(pending.url).origin)
        return;
      const evidence = [...successCandidates(root, pending.source)].find(
        ([node, value]) => baseline.get(node) !== value && relevant(node, original, root)
      );
      if (!evidence) return;
      const intent = pending, request = revision;
      busy = true;
      try {
        const clause = (SUCCESS.exec(evidence[1]) || LINKEDIN_SUCCESS.exec(evidence[1]))?.[0].trim();
        const result2 = await chrome.runtime.sendMessage({
          type: "eze-tracking:confirm",
          intentId: intent.id,
          evidence: clause
        });
        if (!result2?.ok) throw new Error("Confirmation was not saved");
        completed.add(intent.id);
        if (request === revision) {
          pending = void 0;
          prepared = false;
        }
      } catch {
        if (!stopped && request === revision && ++failures < 4)
          retry = setTimeout(schedule, Math.min(4e3, 500 * 2 ** failures));
      } finally {
        busy = false;
      }
    }
    function schedule() {
      if (stopped || queued || !pending || !prepared) return;
      queued = true;
      queueMicrotask(() => {
        queued = false;
        observe();
        void scan();
      });
    }
    const click = (event) => {
      if (!event.isTrusted) return;
      const target = event.composedPath().find(
        (node) => node instanceof HTMLElement && node.matches('button,input[type="submit"],[role="button"]')
      );
      if (!target) return;
      const url = currentURL(), scope = submissionScope(target, url);
      if (scope && finalButton(target, linkedIn(url) ? "linkedin" : "external")) prepare(scope);
    };
    const submit = (event) => {
      if (!event.isTrusted) return;
      const target = event.composedPath()[0];
      if (!(target instanceof HTMLElement)) return;
      const scope = submissionScope(target, currentURL());
      const submitter = event.submitter;
      if (scope && (!submitter || finalButton(submitter, linkedIn(currentURL()) ? "linkedin" : "external")))
        prepare(scope);
    };
    root.addEventListener("click", click, true);
    root.addEventListener("submit", submit, true);
    const initial = revision;
    chrome.runtime.sendMessage({ type: "eze-tracking:page-ready" }).then((result2) => {
      if (stopped || revision !== initial || !result2?.ok || !result2.intent) return;
      const intent = result2.intent;
      if (typeof intent.id !== "string" || !["linkedin", "external"].includes(intent.source) || typeof intent.url !== "string")
        return;
      let url;
      try {
        url = new URL(intent.url);
      } catch {
        return;
      }
      if (url.origin !== currentURL().origin) return;
      const created = typeof intent.createdAt === "number" ? intent.createdAt : typeof intent.createdAt === "string" ? Date.parse(intent.createdAt) : Date.now();
      if (!Number.isFinite(created) || Date.now() - created < 0 || Date.now() - created > TTL)
        return;
      pending = intent;
      startedAt = created;
      prepared = true;
      baseline = /* @__PURE__ */ new Map();
      schedule();
    }).catch(() => {
    });
    const lifecycle = setInterval(schedule, 1e3);
    return () => {
      stopped = true;
      revision++;
      observer.disconnect();
      clearInterval(lifecycle);
      if (retry) clearTimeout(retry);
      root.removeEventListener("click", click, true);
      root.removeEventListener("submit", submit, true);
      void preparePromise;
    };
  }

  // src/content.ts
  var SELECTOR = CONTROL_SELECTOR;
  var UNSAFE_TYPES = /* @__PURE__ */ new Set([
    "hidden",
    "password",
    "file",
    "submit",
    "reset",
    "button",
    "image",
    "checkbox",
    "range",
    "color"
  ]);
  var PROTECTED = /\b(password|passcode|verification code|one time code|otp|captcha|social security|ssn|credit card|debit card|card number|cvv|cvc|routing number|bank account|account number|consent|agree|agreement|terms and conditions|signature)\b/i;
  var identities2 = /* @__PURE__ */ new WeakMap();
  var nextIdentity = 0;
  var previousChanges = [];
  var userEdited = /* @__PURE__ */ new WeakMap();
  var widgetChanges = false;
  var widgetFailures = /* @__PURE__ */ new WeakMap();
  function identity2(element) {
    let id2 = identities2.get(element);
    if (!id2) {
      id2 = `question-${++nextIdentity}`;
      identities2.set(element, id2);
    }
    return id2;
  }
  function roots2(root) {
    const result2 = [root];
    for (const element of root.querySelectorAll("*")) {
      if (element.shadowRoot && element.localName !== "ezeapply-ai")
        result2.push(...roots2(element.shadowRoot));
    }
    return result2;
  }
  function parentElement(element) {
    return element.parentElement || element.getRootNode().host || null;
  }
  function activeControl(root) {
    let active = root.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    return active;
  }
  function isVisible(element) {
    if (!element.isConnected) return false;
    for (let ancestor = element; ancestor; ancestor = parentElement(ancestor)) {
      if (ancestor.hasAttribute("hidden") || ancestor.getAttribute("aria-hidden") === "true" || ancestor.hasAttribute("inert"))
        return false;
      const style = element.ownerDocument.defaultView?.getComputedStyle(ancestor);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function text4(element) {
    return element?.textContent?.replace(/\s+/g, " ").trim().slice(0, 500) || "";
  }
  function labelledBy2(element) {
    return ariaLabel(element);
  }
  function ownLabels(control) {
    return fieldMatchingLabels(control, fieldLabels(control)).labels;
  }
  function native(element) {
    return ["INPUT", "SELECT", "TEXTAREA"].includes(element.tagName);
  }
  function editable(element) {
    return element.hasAttribute("contenteditable") && element.getAttribute("contenteditable") !== "false";
  }
  function groupLabels(control) {
    const group = control.closest('fieldset,[role="radiogroup"]');
    if (group) {
      const legend = group.querySelector(":scope > legend");
      const values = [labelledBy2(group), group.getAttribute("aria-label") || "", text4(legend)];
      if (values.some(Boolean)) return [...values.filter(Boolean), control.name];
    }
    const questionId = control.getAttribute("data-question-id");
    const wrapper = control.closest(
      ".form-group,.form-field,.field,.application-question,.fb-dash-form-element"
    );
    const questionLabel = wrapper?.querySelector(
      ":scope > label,:scope > legend,:scope > [class*=label]"
    );
    return [text4(questionLabel || null), questionId || "", control.name].filter(Boolean);
  }
  function editKey(control) {
    const radio = control.tagName === "INPUT" && control.type === "radio";
    return JSON.stringify([
      normalize((radio ? groupLabels(control) : ownLabels(control))[0] || ""),
      autocompleteToken(control),
      control.getAttribute("role"),
      control.getAttribute("type")
    ]);
  }
  function wasEdited(control) {
    return userEdited.get(control) === editKey(control);
  }
  function editingBlocks(target, automatic) {
    return automatic && target.controls.some(wasEdited);
  }
  function collect(root) {
    const result2 = [];
    for (const scope of roots2(root)) {
      const controls = [...scope.querySelectorAll(SELECTOR)].filter((control) => {
        const type = control.tagName === "INPUT" ? control.type : "";
        return !control.closest("ezeapply-ai") && type !== "search" && !control.closest('[role="listbox"]') && !UNSAFE_TYPES.has(type) && !(native(control) && control.disabled) && control.getAttribute("aria-disabled") !== "true" && !(native(control) && "readOnly" in control && control.readOnly && control.getAttribute("role") !== "combobox") && isVisible(control);
      });
      const consumed = /* @__PURE__ */ new Set();
      for (const control of controls) {
        if (consumed.has(control)) continue;
        if (control.closest('[role="combobox"]') !== control && control.closest('[role="combobox"]'))
          continue;
        const radio = control.tagName === "INPUT" && control.type === "radio";
        let members = [control];
        const presentation = fieldMatchingLabels(control, fieldLabels(control));
        let labels = presentation.labels;
        if (control.getAttribute("role") === "searchbox" || control.closest('[role="search"]') || /^search(?: jobs)?$/i.test(labels[0] || ""))
          continue;
        if (radio) {
          const form = control.form;
          const group = control.closest('fieldset,[role="radiogroup"]');
          members = controls.filter(
            (other) => other.tagName === "INPUT" && other.type === "radio" && other.name === control.name && other.form === form && other.closest('fieldset,[role="radiogroup"]') === group
          );
          labels = groupLabels(control);
        }
        members.forEach((member) => consumed.add(member));
        if (labels.some((label) => PROTECTED.test(normalize(label)))) continue;
        const token = autocompleteToken(control);
        if (token?.match(/^(cc-|one-time-code|current-password|new-password)/)) continue;
        const context = normalize(fieldContext(control));
        const blocked = presentation.blocked || (/\b(reference|referee|emergency contact|recruiter|recommender|previous employer|previous employment|employment history|work history|education history)\b/.test(
          context
        ) ? "This field belongs to a separate person or history entry; choose the matching history entry manually" : void 0);
        result2.push({
          id: identity2(control),
          controls: members,
          labels,
          autocomplete: token,
          blocked,
          kind: radio ? "radio" : control.tagName === "SELECT" ? "select" : control.getAttribute("role") === "combobox" ? "combobox" : editable(control) ? "contenteditable" : control.tagName.toLowerCase()
        });
      }
    }
    return result2;
  }
  function placeholderOption(option) {
    if (!option) return true;
    return !option.value.trim() || isDropdownPlaceholder(option.textContent);
  }
  function hasValue(target) {
    if (target.kind === "combobox") return !!comboboxValue(target.controls[0]);
    if (target.kind === "contenteditable") return !!target.controls[0].textContent?.trim();
    if (target.kind === "radio")
      return target.controls.some((control2) => control2.checked);
    const control = target.controls[0];
    if (control.tagName === "SELECT") {
      const select = control;
      if (select.multiple)
        return [...select.selectedOptions].some((option) => !placeholderOption(option));
      return !placeholderOption(select.options[select.selectedIndex]);
    }
    return native(control) && !!control.value.trim();
  }
  function setNative(control, value) {
    const win = control.ownerDocument.defaultView;
    if (editable(control)) {
      control.textContent = String(value);
      control.dispatchEvent(
        new win.InputEvent("input", {
          bubbles: true,
          composed: true,
          inputType: "insertText",
          data: String(value)
        })
      );
      control.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
      return;
    }
    const property = typeof value === "boolean" ? "checked" : "value";
    const prototype = control.tagName === "SELECT" ? win.HTMLSelectElement.prototype : control.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, property)?.set;
    if (!setter) throw new Error("Control has no native value setter");
    setter.call(control, value);
    control.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
    control.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
  }
  function valueOf(control) {
    if (editable(control)) return control.textContent || "";
    if (!native(control)) return control.textContent || "";
    return control.tagName === "INPUT" && control.type === "radio" ? control.checked : control.value;
  }
  function fillTarget(target, answer, changes, valueAliases = []) {
    if (target.kind === "combobox") return "Use Fill this page to select this dropdown option";
    const control = target.controls[0];
    let selected = control;
    let value = answer;
    if (target.kind === "radio") {
      const matches = target.controls.filter(
        (option) => [...ownLabels(option), option.value].some(
          (label) => [answer, ...valueAliases].some(
            (value2) => normalizeOption(label) === normalizeOption(value2)
          )
        )
      );
      if (matches.length !== 1) return "No unique radio option matches the saved answer";
      selected = matches[0];
      value = true;
    } else if (control.tagName === "SELECT") {
      const select = control;
      if (select.multiple) return "Multiple-choice list requires manual selection";
      const options = [...select.options].filter(
        (option) => !option.disabled && !option.closest("optgroup[disabled]") && !placeholderOption(option) && [option.value, option.textContent || ""].some(
          (label) => [answer, ...valueAliases].some(
            (value2) => normalizeOption(label) === normalizeOption(value2)
          )
        )
      );
      if (options.length !== 1) return "No unique dropdown option matches the saved answer";
      value = options[0].value;
    } else if (native(control)) {
      const input = control;
      if (input.type === "number" && !/^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(answer.trim()))
        return "This question needs a numeric answer; save a numeric variant";
      if (input.maxLength > -1 && answer.length > input.maxLength)
        return "Saved answer exceeds the field length limit";
      if (input.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(answer))
        return "Date answer must use YYYY-MM-DD";
    }
    const before = valueOf(selected);
    if (target.kind === "radio") selected.click();
    else setNative(selected, value);
    const after = valueOf(selected);
    if (after !== value) return "The page did not accept the saved answer";
    changes.push({ element: selected, before, after });
    return void 0;
  }
  function question(target, fields, hostname) {
    const match = matchField(target.labels, fields, hostname, target.autocomplete);
    const filled = hasValue(target);
    return {
      id: target.id,
      label: target.labels[0] || target.autocomplete || "Unlabelled question",
      kind: target.kind,
      filled,
      matchedField: match.field?.id,
      ...aiEligible(target) ? { canDraftWithAI: true } : {},
      reason: target.blocked || (target.controls.some(wasEdited) ? filled ? "Your edit was preserved" : "Cleared by you; click Fill this page to refill" : filled ? "Existing answer preserved" : match.reason)
    };
  }
  function scanForm(root, fields, hostname = root.location?.hostname || "") {
    const questions = collect(root).map((target) => question(target, fields, hostname));
    for (const upload of scanResumeInputs(root))
      questions.push({
        id: identity2(upload.element),
        label: upload.label,
        kind: "file",
        filled: !!upload.element.files?.length,
        reason: upload.reason || "Use Attach resume to upload the resume saved in your profile"
      });
    return { filled: 0, skipped: questions.length, questions };
  }
  function fillNativeForm(root, fields, hostname, automatic) {
    const changes = [];
    const attempts = [];
    const report = { filled: 0, skipped: 0, questions: [] };
    for (const target of collect(root)) {
      const item = question(target, fields, hostname);
      const focused = automatic && target.controls.some((control) => control === activeControl(root));
      const application = !automatic || target.controls.some((control) => isApplicationField(control));
      if (application && !focused && !target.blocked && !item.filled && item.matchedField && !editingBlocks(target, automatic)) {
        const field = fields.find((candidate) => candidate.id === item.matchedField);
        try {
          const key = editKey(target.controls[0]);
          const error = fillTarget(target, field.value, changes, field.valueAliases);
          item.reason = error || "Filled from saved field";
          if (!error) {
            item.filled = true;
            report.filled++;
            target.controls.forEach((control) => userEdited.delete(control));
            const change = changes[changes.length - 1];
            attempts.push({ target, change, key });
          }
        } catch {
          item.reason = "The page rejected this answer";
        }
      }
      if (item.reason !== "Filled from saved field") report.skipped++;
      report.questions.push(item);
    }
    if (changes.length) previousChanges.push(...changes);
    return { report, attempts };
  }
  function fillForm(root, fields, hostname = root.location?.hostname || "", automatic = false) {
    return fillNativeForm(root, fields, hostname, automatic).report;
  }
  async function fillFormWithWidgets(root, fields, hostname = root.location?.hostname || "", automatic = false, signal) {
    if (signal?.aborted) return { filled: 0, skipped: 0, questions: [] };
    const { report, attempts } = fillNativeForm(root, fields, hostname, automatic);
    let attempted = 0;
    for (const target of collect(root).filter((target2) => target2.kind === "combobox")) {
      if (signal?.aborted) break;
      if (++attempted > 20) {
        (report.warnings ||= []).push(
          "Additional dropdowns remain. Run Fill again after reviewing this step."
        );
        break;
      }
      const item = report.questions.find((question2) => question2.id === target.id);
      const control = target.controls[0];
      if (automatic && !target.controls.some((control2) => isApplicationField(control2))) continue;
      if (!item || item.filled || !item.matchedField || target.blocked || hasValue(target) || editingBlocks(target, automatic))
        continue;
      if (automatic && (activeControl(root) === control || control.contains(activeControl(root))))
        continue;
      const field = fields.find((field2) => field2.id === item.matchedField);
      const failed = widgetFailures.get(control);
      if (automatic && failed?.value === field.value && failed.until > Date.now()) continue;
      const result2 = await fillCombobox(control, field.value, field.valueAliases, signal);
      item.reason = result2.reason;
      if (result2.filled) {
        item.filled = true;
        report.filled++;
        report.skipped--;
        widgetChanges = true;
        target.controls.forEach((control2) => userEdited.delete(control2));
      } else if (!signal?.aborted)
        widgetFailures.set(control, { value: field.value, until: Date.now() + 3e4 });
    }
    await new Promise((resolve) => root.defaultView.setTimeout(resolve, 0));
    for (const { target, change, key } of attempts) {
      const item = report.questions.find((question2) => question2.id === target.id);
      if (!change.element.isConnected || editKey(change.element) !== key || valueOf(change.element) !== change.after) {
        item.filled = false;
        item.reason = target.controls.some(wasEdited) ? "Your edit was preserved" : !change.element.isConnected || editKey(change.element) !== key ? "The form step changed before this answer could be verified; try again" : hasValue(target) ? "The page changed this answer; review it in the form" : "The page reset this answer; use its own control";
        report.filled--;
        report.skipped++;
      }
    }
    return report;
  }
  function aiEligible(target) {
    if (target.blocked || !["textarea", "input", "contenteditable"].includes(target.kind))
      return false;
    const control = target.controls[0], label = target.labels[0] || "";
    if (!isApplicationField(control)) return false;
    if (!fieldQuestion(control) || !label || control.tagName === "INPUT" && !["text", ""].includes(control.type))
      return false;
    const token = autocompleteToken(control);
    if (token && /^(?:tel(?:-|$)|email$)/.test(token) || /^(?:tel|numeric|decimal)$/.test(control.getAttribute("inputmode") || ""))
      return false;
    const terms = matchingTerms(label);
    const normalized = normalize(label);
    const narrative = /\b(describe|explain|summarize|outline|scenario)\b|\btell (?:us|me) about\b|\b(?:why|how did|how would|what did|hardest problem)\b/i.test(
      label
    );
    if (!narrative && (terms.topic || /\b(email|e mail|phone|telephone|mobile|cell|cellular|whats ?app|address|date|birth|age|gender|ethnicity|disability|veteran)\b|\bcontact (?:number|no)\b|\b(?:first|last|middle|full|legal|given|family|preferred) name\b|^(?:what is your |your )?name$/.test(
      normalized
    )))
      return false;
    return true;
  }
  function aiFields(root = document) {
    return collect(root).filter(aiEligible).map((target) => ({
      element: target.controls[0],
      question: target.labels[0] || "",
      value: String(valueOf(target.controls[0])),
      instructions: fieldInstructions(target.controls[0]),
      maxLength: "maxLength" in target.controls[0] ? target.controls[0].maxLength : 0
    })).filter((field) => !!field.question);
  }
  function applyAIAnswer(field, answer, baseline) {
    const current = aiFields(field.element.ownerDocument).find(
      (item) => item.element === field.element
    );
    if (!current)
      throw new Error("This question is no longer editable. Reopen it on the current form step.");
    if (normalize(current.question) !== normalize(field.question))
      throw new Error(
        "This form question changed while you were drafting. Reopen AI for the current question."
      );
    if (current.value !== baseline)
      throw new Error(
        "This field changed while you were drafting. Close this preview and reopen it to keep your latest edits."
      );
    if (current.maxLength > 0 && answer.length > current.maxLength)
      throw new Error("This answer exceeds the field\u2019s character limit.");
    const before = valueOf(field.element);
    setNative(field.element, answer);
    previousChanges.push({ element: field.element, before, after: answer });
  }
  function undoFill() {
    let filled = 0;
    let skipped = 0;
    for (const change of previousChanges.reverse()) {
      if (change.element.isConnected && valueOf(change.element) === change.after) {
        setNative(change.element, change.before);
        filled++;
      } else skipped++;
    }
    previousChanges = [];
    const warnings = widgetChanges ? [
      "Dropdown selections use the website\u2019s own controls and must be changed there. Resume uploads are not removed by Undo."
    ] : void 0;
    widgetChanges = false;
    return { filled, skipped, questions: [], ...warnings ? { warnings } : {} };
  }
  function isJobContext(root) {
    const actual = new URL(root.location.href);
    const url = !/^https?:$/.test(actual.protocol) && /^https?:/.test(root.referrer || "") ? new URL(root.referrer) : actual;
    if (/(^|\.)(linkedin\.com)$/.test(url.hostname)) {
      return !![...root.querySelectorAll('dialog,[role="dialog"],.jobs-easy-apply-modal')].find(
        (dialog) => /easy apply|apply to|application/i.test(
          `${dialog.getAttribute("aria-label") || ""} ${(dialog.textContent || "").slice(0, 6e3)}`
        ) && isVisible(dialog)
      );
    }
    return /(^|[./_-])(careers?|jobs?|apply|applications?)([./_?=-]|$)/i.test(
      `${url.hostname}${url.pathname}`
    ) || /(^|\.)(myworkdayjobs\.com|greenhouse\.io|lever\.co|ashbyhq\.com|workable\.com|icims\.com|smartrecruiters\.com|successfactors\.com|taleo\.net|breezy\.hr|recruitee\.com|personio\.(com|de)|jobvite\.com|applytojob\.com|bamboohr\.com|teamtailor\.com|pinpointhq\.com|oraclecloud\.com|avature\.net)$/.test(
      url.hostname
    ) || [...root.querySelectorAll("form,dialog,[role=dialog]")].some((form) => {
      if (!isVisible(form)) return false;
      const inputs = form.querySelectorAll("input,textarea,select");
      const description2 = (form.textContent || "").slice(0, 12e3);
      return inputs.length >= 3 && (/apply for|job application|candidate information|submit application|upload (?:(?:your|new) )?(resume|cv)/i.test(
        description2
      ) || /\bapply to\b/i.test(description2) && /\b(resume|cv)\b/i.test(description2));
    });
  }
  function isAIFormContext(root) {
    return aiFields(root).length > 0;
  }
  function startContent(aiUI) {
    const notice = fillNotice(document);
    let timer;
    let busy = false;
    let autoPaused = false;
    let stopped = false;
    let pendingSince = 0;
    let operation = Promise.resolve(void 0);
    let automaticRun;
    let activeProfileId = "local";
    const observed = /* @__PURE__ */ new WeakSet();
    const observer = new MutationObserver(() => schedule());
    function observeRoots() {
      for (const scope of roots2(document)) {
        if (!observed.has(scope)) {
          observer.observe(scope, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: [
              "open",
              "hidden",
              "aria-hidden",
              "disabled",
              "class",
              "style",
              "aria-label",
              "aria-labelledby",
              "aria-describedby",
              "data-unit",
              "data-prefix",
              "data-suffix"
            ]
          });
          observed.add(scope);
        }
      }
    }
    async function execute(type) {
      if (type === `${MESSAGE_PREFIX}undo`) {
        autoPaused = true;
        return undoFill();
      }
      const run = type === "auto" ? new AbortController() : void 0;
      if (run) automaticRun = run;
      const settings = await getAutofillData();
      activeProfileId = settings.profileId || "local";
      if (type === `${MESSAGE_PREFIX}scan`) return scanForm(document, settings.fields);
      if (type === `${MESSAGE_PREFIX}attach-resume`) {
        if (!settings.resume)
          return {
            filled: 0,
            skipped: 0,
            questions: [],
            error: "Save a resume in your profile first."
          };
        return attachResume(document, settings.resume);
      }
      if (type === `${MESSAGE_PREFIX}fill`) {
        autoPaused = false;
        notice.show("Autofill in progress\u2026", true);
        try {
          const report = await fillFormWithWidgets(document, settings.fields);
          notice.show(
            report.filled ? `Autofill complete \xB7 ${report.filled} ${report.filled === 1 ? "field" : "fields"}` : "Autofill complete \xB7 review remaining questions"
          );
          return report;
        } catch (error) {
          notice.dispose();
          throw error;
        }
      }
      if (!settings.autoFill || autoPaused || run?.signal.aborted)
        return { filled: 0, skipped: 0, questions: [] };
      return fillFormWithWidgets(
        document,
        settings.fields,
        document.location.hostname,
        true,
        run?.signal
      );
    }
    function queued(type) {
      const next = operation.catch(() => {
      }).then(() => stopped ? { filled: 0, skipped: 0, questions: [] } : execute(type));
      operation = next;
      return next;
    }
    function schedule() {
      if (stopped || autoPaused) return;
      if (!pendingSince) pendingSince = Date.now();
      clearTimeout(timer);
      timer = setTimeout(
        async () => {
          if (busy) {
            schedule();
            return;
          }
          pendingSince = 0;
          busy = true;
          try {
            observeRoots();
            const report = await queued("auto");
            if (report.filled) {
              notice.show(
                `Autofill complete \xB7 ${report.filled} ${report.filled === 1 ? "field" : "fields"}`
              );
              await chrome.runtime.sendMessage({ type: `${MESSAGE_PREFIX}report`, report });
            }
          } catch {
            if (!chrome.runtime?.id) {
              stopped = true;
              observer.disconnect();
            }
          } finally {
            busy = false;
          }
        },
        Math.max(0, Math.min(400, 1500 - (Date.now() - pendingSince)))
      );
    }
    const onMessage = (message, _sender, sendResponse) => {
      if (!message || typeof message !== "object" || !("type" in message)) return;
      const type = message.type;
      if (type === `${MESSAGE_PREFIX}identify`) {
        chrome.runtime.sendMessage({ type: `${MESSAGE_PREFIX}ready` }).then(
          () => sendResponse({ ready: true }),
          () => sendResponse({ ready: false })
        );
        return true;
      }
      if (type === `${MESSAGE_PREFIX}open-ai`) {
        const request = message;
        const target = collect(document).find((target2) => target2.id === request.questionId);
        if (!target || typeof request.questionLabel !== "string" || normalize(target.labels[0] || "") !== normalize(request.questionLabel) || !aiEligible(target) || !aiUI) {
          sendResponse({
            error: "This question changed or is no longer editable. Find questions again on the current form step."
          });
          return;
        }
        aiUI.open(target.controls[0]).then(
          (opened) => sendResponse(
            opened ? { ok: true } : { error: "This question is no longer available for AI drafting." }
          ),
          (error) => sendResponse({
            error: error instanceof Error ? error.message : "Could not open the AI draft."
          })
        );
        return true;
      }
      if (typeof type !== "string" || !["scan", "fill", "undo", "attach-resume"].some(
        (action) => type === `${MESSAGE_PREFIX}${action}`
      ))
        return;
      automaticRun?.abort();
      queued(type).then((report) => {
        sendResponse(report);
        return chrome.runtime.sendMessage({ type: `${MESSAGE_PREFIX}report`, report });
      }).catch(
        () => sendResponse({
          filled: 0,
          skipped: 0,
          questions: [],
          error: "Custom fields could not be loaded; refresh this page."
        })
      );
      return true;
    };
    chrome.runtime.onMessage.addListener(onMessage);
    const onUserEdit = (event) => {
      const target = event.composedPath()[0];
      if (event.isTrusted && target instanceof Element) {
        const control = target.closest(SELECTOR);
        if (!control) return;
        userEdited.set(control, editKey(control));
        const combobox = control.closest('[role="combobox"]');
        if (combobox) userEdited.set(combobox, editKey(combobox));
      }
    };
    const onStorage = (changes, area) => {
      if (area !== "local") return;
      if (changes[STORAGE_KEY] || changes.profile || changes.lastSyncProfile || changes.autofillEnabled) {
        automaticRun?.abort();
        const before = changes[STORAGE_KEY]?.oldValue;
        const after = changes[STORAGE_KEY]?.newValue;
        if (changes.lastSyncProfile || changes.autofillEnabled?.newValue === true || before?.profiles?.[activeProfileId]?.autoFill === false && after?.profiles?.[activeProfileId]?.autoFill === true)
          autoPaused = false;
      }
      schedule();
    };
    let lastUrl = location.href;
    let lastShadowCount = roots2(document).length;
    const onNavigation = () => {
      autoPaused = false;
      schedule();
    };
    const lifecycle = setInterval(() => {
      if (stopped || document.visibilityState === "hidden") return;
      const nextUrl = location.href;
      const shadowCount = roots2(document).length;
      if (nextUrl !== lastUrl || shadowCount !== lastShadowCount) {
        lastUrl = nextUrl;
        lastShadowCount = shadowCount;
        onNavigation();
      }
    }, 1500);
    document.addEventListener("input", onUserEdit, true);
    document.addEventListener("change", onUserEdit, true);
    chrome.storage.onChanged.addListener(onStorage);
    window.addEventListener("popstate", onNavigation);
    chrome.runtime.sendMessage({ type: `${MESSAGE_PREFIX}ready` }).catch(() => {
    });
    observeRoots();
    schedule();
    return () => {
      stopped = true;
      notice.dispose();
      automaticRun?.abort();
      clearTimeout(timer);
      clearInterval(lifecycle);
      observer.disconnect();
      chrome.runtime.onMessage.removeListener(onMessage);
      chrome.storage.onChanged.removeListener(onStorage);
      document.removeEventListener("input", onUserEdit, true);
      document.removeEventListener("change", onUserEdit, true);
      window.removeEventListener("popstate", onNavigation);
    };
  }
  var contentScope = globalThis;
  if (typeof chrome !== "undefined" && chrome.runtime?.id && typeof document !== "undefined" && !contentScope.__ezeContentStarted) {
    contentScope.__ezeContentStarted = true;
    document.getElementById("ezeapply-overlay")?.remove();
    mountPanelDock();
    mountLinkedInFollow();
    mountSubmissionCapture();
    const aiUI = mountAIFieldUI({
      fields: () => aiFields(),
      enabled: () => isAIFormContext(document),
      apply: applyAIAnswer
    });
    startContent(aiUI);
  }
})();
