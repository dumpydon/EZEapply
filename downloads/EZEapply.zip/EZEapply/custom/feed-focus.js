"use strict";
(() => {
  // src/feed-focus-settings.ts
  var FEED_FOCUS_KEY = "eze.linkedin.feedFocus.v1";
  var FEED_QUOTE_LIMIT = 180;
  var FEED_QUOTES = {
    focus: "Stay focused on what brought you here.",
    progress: "Small steps make real progress.",
    intention: "Give your attention to what matters."
  };
  function readFeedFocusSettings(raw) {
    const saved = raw;
    const customQuote = typeof saved?.customQuote === "string" ? saved.customQuote.trim().slice(0, FEED_QUOTE_LIMIT) : "";
    const choice = saved?.quote;
    return {
      enabled: saved?.enabled === true,
      quote: choice && (Object.hasOwn(FEED_QUOTES, choice) || choice === "custom" && customQuote) ? choice : "focus",
      customQuote
    };
  }
  function feedQuote(settings) {
    return settings.quote === "custom" ? settings.customQuote : FEED_QUOTES[settings.quote];
  }

  // src/linkedin-follow.ts
  function isLinkedInHost(hostname) {
    return hostname === "linkedin.com" || hostname.endsWith(".linkedin.com");
  }

  // src/linkedin-feed-focus.ts
  var HOME_FEED = /^\/feed(?:\/foryou)?\/?$/;
  function isHomeFeed() {
    if (!HOME_FEED.test(location.pathname)) return false;
    const query = new URLSearchParams(location.search);
    return !query.has("shareActive") && !query.get("highlightedUpdateUrn")?.trim();
  }
  function mountLinkedInFeedFocus() {
    if (window.top !== window || !isLinkedInHost(location.hostname) || !chrome.runtime?.id)
      return () => {
      };
    let settings = readFeedFocusSettings(void 0);
    let revision = 0;
    let disposed = false;
    let watching = false;
    const navigation = window.navigation;
    const cover = document.createElement("section");
    cover.id = "eze-linkedin-feed-focus";
    cover.setAttribute("aria-label", "Feed blocked");
    const card = document.createElement("div");
    card.className = "eze-feed-focus-card";
    const title = document.createElement("h1");
    title.textContent = "Feed blocked";
    const quote = document.createElement("p");
    card.append(title, quote);
    cover.append(card);
    const observer = new MutationObserver(render);
    function render() {
      if (disposed || !chrome.runtime?.id || !settings.enabled || !isHomeFeed()) {
        observer.disconnect();
        watching = false;
        cover.remove();
        return;
      }
      if (!watching) {
        observer.observe(document, { childList: true, subtree: true });
        watching = true;
      }
      const workspace = document.querySelector("main#workspace") ?? document.querySelector("main");
      if (!workspace) {
        cover.remove();
        return;
      }
      const message = feedQuote(settings);
      if (quote.textContent !== message) quote.textContent = message;
      if (cover.nextElementSibling !== workspace) workspace.before(cover);
      const top = `${Math.max(0, Math.round(cover.getBoundingClientRect().top + window.scrollY))}px`;
      if (cover.style.getPropertyValue("--eze-feed-offset") !== top)
        cover.style.setProperty("--eze-feed-offset", top);
    }
    const onStorage = (changes, area) => {
      if (disposed || area !== "local" || !changes[FEED_FOCUS_KEY]) return;
      revision++;
      settings = readFeedFocusSettings(changes[FEED_FOCUS_KEY].newValue);
      render();
    };
    function refresh() {
      if (!chrome.runtime?.id) {
        render();
        return;
      }
      const before = revision;
      void chrome.storage.local.get(FEED_FOCUS_KEY).then((data) => {
        if (disposed || before !== revision) return;
        settings = readFeedFocusSettings(data[FEED_FOCUS_KEY]);
        render();
      }).catch(() => {
      });
    }
    chrome.storage.onChanged.addListener(onStorage);
    navigation?.addEventListener("currententrychange", render);
    window.addEventListener("popstate", render);
    window.addEventListener("pageshow", refresh);
    window.addEventListener("resize", render);
    refresh();
    return () => {
      disposed = true;
      render();
      chrome.storage.onChanged.removeListener(onStorage);
      navigation?.removeEventListener("currententrychange", render);
      window.removeEventListener("popstate", render);
      window.removeEventListener("pageshow", refresh);
      window.removeEventListener("resize", render);
    };
  }

  // src/feed-focus-content.ts
  mountLinkedInFeedFocus();
})();
